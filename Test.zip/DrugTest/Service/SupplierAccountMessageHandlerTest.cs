﻿using Drug;
using Drug.Data;
using Drug.Kafka;
using Drug.Services;
using DrugTest.Controller;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NHibernate;
using Swisslog.Base.Api;
using Swisslog.Drug.Api;
using Swisslog.Supplier2.Api;
using System;
using System.Collections.Generic;
using System.Net.Http;

namespace DrugTest.Service
{
    [TestClass]
    public class SupplierAccountMessageHandlerTest
    {
        SupplierAccountMessageHandler? _supplierAccountMessageHandler;
        Mock<SupplierRestClient>? mockSupplierRestClient;
        Mock<DrugCache>? mockCache;
        Mock<DrugService>? mockService;
        Mock<DrugCommand>? mockDrugCommand;
        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            ILogger<SupplierAccountMessageHandler> logSupplierAccountMessageHandler = Mock.Of<ILogger<SupplierAccountMessageHandler>>();
            ILogger<SupplierService> logSupplierService = Mock.Of<ILogger<SupplierService>>();
            ILogger<SupplierRestClient> logSupplierRestClient = Mock.Of<ILogger<SupplierRestClient>>();
            ILogger<DrugService> logDrugService = Mock.Of<ILogger<DrugService>>();
            ILogger<DrugCommand> logDrugCommand = Mock.Of<ILogger<DrugCommand>>();
            ILogger<ProducerService> logProducerService = Mock.Of<ILogger<ProducerService>>();
            ILogger<DrugSyncServiceAdapter> logDrugSyncServiceAdapter = Mock.Of<ILogger<DrugSyncServiceAdapter>>();
            ILogger<DrugQueryProcessor> logDrugQueryProcessor = Mock.Of<ILogger<DrugQueryProcessor>>();
            ILogger<DataChangedService> logDataChangedService = Mock.Of<ILogger<DataChangedService>>();
            ILogger<HazardousTypeQueryProcessor> logHazardousTypeQueryProcessor = Mock.Of<ILogger<HazardousTypeQueryProcessor>>();
            ILogger<DrugIdentifierQueryProcessor> logDrugIdentifierQueryProcessor = Mock.Of<ILogger<DrugIdentifierQueryProcessor>>();
            ILogger<MessageRouter> logMessageRouter = Mock.Of<ILogger<MessageRouter>>();
            HttpClient client = Mock.Of<HttpClient>();
            IWebHostEnvironment _env = Mock.Of<IWebHostEnvironment>();
            Mock<IConfiguration> mockConfig = new();
            Mock<IConfigurationSection> mockConfigurationSection = new();
            mockConfig.Setup(a => a.GetSection("kafka:producer")).Returns(mockConfigurationSection.Object);
            mockSupplierRestClient = new(logSupplierRestClient, client, mockConfig.Object);
            NHibernate.ISession session = Mock.Of<NHibernate.ISession>();
            ProducerService mockProducerService = new(mockConfig.Object, logProducerService);
            ISessionFactory sessionFactory = Mock.Of<ISessionFactory>();
            Mock<ILogger<DrugSyncRestClient>> mockDrugServiceLogger = new();
            Mock<DrugSyncRestClient> mockDrugSyncRestClient = new(client, mockConfig.Object, mockDrugServiceLogger.Object);
            mockCache = new(new Mock<ISessionFactory>().Object, new Mock<ILogger<DrugCache>>().Object);
            mockCache.Setup(x => x.LoadDrugCache()).Verifiable();
            Mock<LocationRestClient> mockLocationRestClient = new(client, mockConfig.Object);

            Mock<MessageRouter> mockMessageRouter = new(logMessageRouter);

            HttpResponseMessage httpResponseMessageForLocation = new()
            {
                StatusCode = System.Net.HttpStatusCode.OK,
                Content = new StringContent(TestData.locationContent, System.Text.Encoding.UTF8, "application/json")
            };
            mockLocationRestClient.Setup(x => x.GetLocations().Result).Returns(httpResponseMessageForLocation);
            Mock<LocationService> mockLocationService = new(new Mock<ILogger<LocationService>>().Object,
                mockLocationRestClient.Object);
            Mock<DrugQueryProcessor> mockDrugQueryProcessor = new(mockCache.Object, logDrugQueryProcessor, mockLocationService.Object);

            Mock<HazardousTypeQueryProcessor> mockHazardousTypeQueryProcessor = new(mockCache.Object, logHazardousTypeQueryProcessor);
            Mock<DrugIdentifierQueryProcessor> mockDrugIdentifierQueryProcessor = new(mockCache.Object, logDrugIdentifierQueryProcessor);
            Mock<DrugSyncServiceAdapter> mockSyncServiceAdapter = new(mockDrugQueryProcessor.Object,
                logDrugSyncServiceAdapter, mockDrugSyncRestClient.Object, sessionFactory, mockCache.Object);

            Mock<DataChangedService> mockDataChangedService = new(logDataChangedService, mockProducerService, mockConfig.Object);
            mockService = new(mockDrugQueryProcessor.Object, mockHazardousTypeQueryProcessor.Object, mockDrugIdentifierQueryProcessor.Object, logDrugService, mockLocationService.Object);
            mockDrugCommand = new(mockCache.Object, sessionFactory, logDrugCommand, mockProducerService, mockSyncServiceAdapter.Object, mockDataChangedService.Object);
            AccountV2 account1 = new()
            {
                SupplierId = "S1",
                AccountId = "A1",
                Name = "Acc Name",
                LocationId = "hospital/SWISSLOG-NA-TC",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };
            AccountV2 account2 = new()
            {
                SupplierId = "S1",
                AccountId = "A2",
                Name = "Acc Name2",
                LocationId = "hospital/SWISSLOG-NA-TC",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };
            AccountV2 account3 = new()
            {
                SupplierId = "S2",
                AccountId = "A3",
                Name = "Acc Name3",
                LocationId = "hospital/SWISSLOG-NA-TC",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };

            AccountV2Page accountV2Page = new()
            {
                Data = new List<AccountV2> { account1, account2 },
                Count = 2,
                Total = 2,
            };

            Dictionary<string, FormularyLocationSettingsModelV2> locations = new()
            {
                ["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active },
                ["locations"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active, PreferredAccount = new PreferredAccountModelV2 { AccountId = "A1", SupplierId = "S1" } }
            };


            FormularyDrugModelV2 formularyDrugModelV2 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };

            DrugCacheDataEntity drugCacheDataEntity = new(formularyDrugModelV2)
            {
                DrugId = "drug",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
            };

            List<DrugCacheDataEntity> listOfDrugCacheEntity = new();
            listOfDrugCacheEntity.Add(drugCacheDataEntity);

            mockSupplierRestClient.Setup(x => x.GetAccounts().Result).Returns(accountV2Page);
            mockSupplierRestClient.Setup(x => x.GetAccount("S1", "A1").Result).Returns(account1);
            mockService.Setup(x => x.GetDrugByPreferredSetting(It.IsAny<string>(), It.IsAny<string>()).Result).Returns(listOfDrugCacheEntity);
            Tuple<bool, object> tupleFormulary = new(true, formularyDrugModelV2);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleFormulary!);
            IHttpContextAccessor httpContextAccessor = Mock.Of<IHttpContextAccessor>();            
            SupplierService _supplierService = new(logSupplierService, mockSupplierRestClient.Object, mockService.Object, mockDrugCommand!.Object, httpContextAccessor);

            _supplierAccountMessageHandler = new SupplierAccountMessageHandler(logSupplierAccountMessageHandler, mockMessageRouter.Object, _supplierService);
        }
        #endregion

        #region Method
        [TestMethod]
        public void HandleAccount1Test()
        {
            DataChangedMessageV2 dataChangedMessageV2 = new()
            {
                MessageId = Guid.NewGuid(),
                Timestamp = DateTime.UtcNow,
                MessageClass = "DataChangedMessageV2",
                Id1 = "S1",
                Id2 = "A1",
                Type = "account2",
                Change = DataChangeV2.CHANGED,
                Contexts = new List<ContextFrameV1> { 
                    new ContextFrameV1 {
                        UserId = "10d93011-2cd2-41eb-a661-d91b8653213a",
                        Timestamp = DateTime.UtcNow,
                        ActivityId = Guid.NewGuid(),
                        Workflow = "DataChangedMessageV2",
                        WorkflowStep = "DataChangedMessageV2",
                        SourceName = "supplier2.DataChangedMessageV2",
                        SpringInstanceId = "supplier2",
                        IncomingTimestamp = DateTime.UtcNow,
                        DiscoveryInstanceId = "''",
                    } 
                },
            };

            //Act
            _supplierAccountMessageHandler?.HandleAccount(dataChangedMessageV2);

            //Verify
            mockSupplierRestClient?.Verify(mock => mock.GetAccounts(), Times.Once);
            mockSupplierRestClient?.Verify(mock => mock.GetAccount("S1", "A1"), Times.Once);
        }

        [TestMethod]
        public void HandleAccount2ForUpdatePreferredAccountTest()
        {
            DataChangedMessageV2 dataChangedMessageV2 = new()
            {
                MessageId = Guid.NewGuid(),
                Timestamp = DateTime.UtcNow,
                MessageClass = "DataChangedMessageV2",
                Id1 = "S1",
                Id2 = "A1",
                Type = "account2",
                Change = DataChangeV2.CHANGED,
                Contexts = new List<ContextFrameV1> {
                    new ContextFrameV1 {
                        UserId = "10d93011-2cd2-41eb-a661-d91b8653213a",
                        Timestamp = DateTime.UtcNow,
                        ActivityId = Guid.NewGuid(),
                        Workflow = "DataChangedMessageV2",
                        WorkflowStep = "DataChangedMessageV2",
                        SourceName = "supplier2.DataChangedMessageV2",
                        SpringInstanceId = "supplier2",
                        IncomingTimestamp = DateTime.UtcNow,
                        DiscoveryInstanceId = "''",
                    }
                },
            };

            AccountV2 account1 = new()
            {
                SupplierId = "S1",
                AccountId = "A1",
                Name = "Acc Name",
                LocationId = "hospital/SWISSLOG-NA-HQ",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };

            //Mock
            mockSupplierRestClient?.Setup(x => x.GetAccount("S1", "A1").Result).Returns(account1);

            //Act
            _supplierAccountMessageHandler?.HandleAccount(dataChangedMessageV2);

            //Verify
            mockSupplierRestClient?.Verify(mock => mock.GetAccount("S1", "A1"), Times.Once);
            mockService?.Verify(mock => mock.GetDrugByPreferredSetting(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            mockDrugCommand?.Verify(mock => mock.HandleAsync(It.IsAny<DrugSaveCommand>()), Times.Once);
        }

        [TestMethod]
        public void HandleAccount3ForUpdateAccountTest()
        {
            DataChangedMessageV2 dataChangedMessageV2 = new()
            {
                MessageId = Guid.NewGuid(),
                Timestamp = DateTime.UtcNow,
                MessageClass = "DataChangedMessageV2",
                Id1 = "S2",
                Id2 = "A2",
                Type = "account2",
                Change = DataChangeV2.CHANGED,
                Contexts = new List<ContextFrameV1> {
                    new ContextFrameV1 {
                        UserId = "10d93011-2cd2-41eb-a661-d91b8653213a",
                        Timestamp = DateTime.UtcNow,
                        ActivityId = Guid.NewGuid(),
                        Workflow = "DataChangedMessageV2",
                        WorkflowStep = "DataChangedMessageV2",
                        SourceName = "supplier2.DataChangedMessageV2",
                        SpringInstanceId = "supplier2",
                        IncomingTimestamp = DateTime.UtcNow,
                        DiscoveryInstanceId = "''",
                    }
                },
            };

            AccountV2 account2 = new()
            {
                SupplierId = "S2",
                AccountId = "A2",
                Name = "Acc Name",
                LocationId = "hospital/SWISSLOG-NA-HQ",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };

            //Mock
            mockSupplierRestClient?.Setup(x => x.GetAccount("S2", "A2").Result).Returns(account2);

            //Act
            _supplierAccountMessageHandler?.HandleAccount(dataChangedMessageV2);

            //Verify
            mockSupplierRestClient?.Verify(mock => mock.GetAccount("S2", "A2"), Times.Once);
        }
        #endregion
    }
}
