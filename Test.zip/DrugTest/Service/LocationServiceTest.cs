﻿using Drug.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

namespace DrugTest.Service
{
    [TestClass]
    public class LocationServiceTest
    {
        LocationService? locationService;
        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            ILogger<LocationService> logLocationService = Mock.Of<ILogger<LocationService>>();
            HttpClient client = Mock.Of<HttpClient>();
            IWebHostEnvironment _env = Mock.Of<IWebHostEnvironment>();
            Mock<IConfiguration> mockConfig = new();
            Mock<IConfigurationSection> mockConfigurationSection = new();
            Mock<LocationRestClient> mockLocationRestClient = new(client, mockConfig.Object);
            HttpResponseMessage httpResponseMessageForLocation = new()
            {
                StatusCode = System.Net.HttpStatusCode.OK,
                Content = new StringContent(Controller.TestData.locationContent, System.Text.Encoding.UTF8, "application/json")
            };

            mockLocationRestClient.Setup(x => x.GetLocations().Result).Returns(httpResponseMessageForLocation);
            HttpResponseMessage httpResponseMessageForQuantities = new()
            {
                StatusCode = System.Net.HttpStatusCode.OK,
                Content = new StringContent(Controller.TestData.drugQuantityInfo, System.Text.Encoding.UTF8, "application/json")
            };

            mockLocationRestClient.Setup(x => x.GetQuantities(It.IsAny<LocationQuantitiesRequest>()).Result).Returns(httpResponseMessageForQuantities);

            //Act
            locationService = new LocationService(logLocationService, mockLocationRestClient.Object);
            
        }
        #endregion

        [TestMethod]
        public void GetLocationTest()
        {
            List< Swisslog.Base.Api.Location.Location >? result = locationService?.GetLocation("root");

            Assert.IsNotNull(result);
            Assert.AreEqual(result.Count, 2);
            List<Swisslog.Base.Api.Location.Location> locationsByOrder = result.OrderBy(x => x.LocationId).ToList();
            Assert.AreEqual(locationsByOrder[0].LocationId, "hospital/SWISSLOG-NA-HQ");
            Assert.AreEqual(locationsByOrder[0].Name, "HQ Hospital");
            Assert.AreEqual(locationsByOrder[0].ParentId, "root");

            Assert.AreEqual(locationsByOrder[1].LocationId, "hospital/SWISSLOG-NA-TC");
            Assert.AreEqual(locationsByOrder[1].Name, "TC Hospital");
            Assert.AreEqual(locationsByOrder[1].ParentId, "root");
        }

        [TestMethod]
        public void GetQuantitiesTest()
        {
            Dictionary<string, QuantityDetails>? result = locationService?.GetQuantities(new string[] { "drug/drug1" }, "location1").Result;

            Assert.IsNotNull(result);
            Assert.AreEqual(result.Count, 2);
            Assert.AreEqual(result["drug/drug1"].QuantityOnHand, 50);
            Assert.AreEqual(result["drug/drug1"].QuantityAvailable, 50);

            Assert.AreEqual(result["drug/drug2"].QuantityOnHand, 60);
            Assert.AreEqual(result["drug/drug2"].QuantityAvailable, 60);
        }

        #region CleanUp
        [TestCleanup]
        public void TestCleanUp()
        {
            locationService = null;
        }
        #endregion
    }
}
