﻿using Drug;
using Drug.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Swisslog.Base.Api;

namespace DrugTest.Service
{
    [TestClass]
    public class DataChangedServiceTest
    {
        DataChangedService? dataChangedService;
        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            ILogger<DataChangedService> logDataChangedService = Mock.Of<ILogger<DataChangedService>>();
            ILogger<ProducerService> logProducerService = Mock.Of<ILogger<ProducerService>>();
            Mock<IConfiguration> mockConfig = new();
            Mock<IConfigurationSection> mockConfigurationSection = new();
            mockConfig.Setup(a => a.GetSection("kafka:producer")).Returns(mockConfigurationSection.Object);            
            mockConfig.Setup(a => a.GetSection("eureka:instance:instanceId")).Returns(mockConfigurationSection.Object);
            mockConfig.SetupGet(a => a["eureka:instance:instanceId"]).Returns("drug2-eureka-1");
            mockConfig.Setup(a => a.GetSection("consul:discovery:instanceId")).Returns(mockConfigurationSection.Object);
            mockConfig.SetupGet(a => a["consul:discovery:instanceId"]).Returns("drug2-consul-1");
            ProducerService mockProducerService = new(mockConfig.Object, logProducerService);

            dataChangedService = new DataChangedService(logDataChangedService, mockProducerService, mockConfig.Object);

        }
        #endregion

        #region Methods
        [TestMethod]
        public void SendDataChangedMessageTest()
        {
            dataChangedService?.SendDataChangedMessage("drugId", DataChangeV1.ADDED);
        }
        #endregion

        #region CleanUp
        public void TestCleanUp()
        {
            dataChangedService = null;
        }
        #endregion

    }
}
