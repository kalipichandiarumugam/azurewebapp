﻿using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Moq;
using Drug.Services;
using NHibernate;
using Swisslog.Drug.Api;
using System.Linq;
using Drug;
using Drug.Data;
using Drug.Models;
using System;
using Swisslog.Base.Api;
using NPOI.SS.Formula.Functions;

namespace DrugTest.Service
{
    [TestClass]
    public class DrugValidatorTest
    {
        DrugValidator? drugValidator;
        FormularyDrugModelV2? formularyDrugModelV2;
        ManufacturedDrugModelV2? manufacturedDrugModelV2;
        PackagedDrugModelV2? packagedDrugModelV2;
        Dictionary<string, string[]>? qryParams;
        readonly Dictionary<string, FormularyLocationSettingsModelV2> locations = new();

        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            ILogger<DrugValidator> logDrugValidator = Mock.Of<ILogger<DrugValidator>>();
            qryParams = new()
            {
                { "locations", new string[] { "locations" } },
                { "status", new string[] { "Active" } },
                { "enablesecondcheck", new string[] { "false" } },
                { "requirelotcode", new string[] { "true" } },
                { "requireexpirydate", new string[] { "true" } },
                { "requireserialnumber", new string[] { "true" } },
                { "preferlocaldispense", new string[] { "true" } }
            };

            locations["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active };
            locations["locations"] = new FormularyLocationSettingsModelV2
            {
                Formulary = true,
                Status = LocationSettingsStatus.Active,
                RequireExpiryDate = true,
                RequireLotCode = true,
                PreferLocalDispense = true,
                RequireSerialNumber = true,
                PreferredAccount = new PreferredAccountModelV2 { AccountId = "accountId", SupplierId = "supplierId" }
            };

            formularyDrugModelV2 = new FormularyDrugModelV2
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };
            manufacturedDrugModelV2 = new ManufacturedDrugModelV2
            {
                DrugId = "formularyId/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "formularyId",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            packagedDrugModelV2 = new PackagedDrugModelV2
            {
                DrugId = "formularyId/123456789/Each",
                ManufacturedDrugId = "formularyId/123456789",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "987654321", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            DrugEntity entityFData = new() { Id = Guid.NewGuid(), DrugId = "drug", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityMData = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789", DrugInfo = DrugUtility<string>.DrugToString(manufacturedDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityPData = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789/Each", DrugInfo = DrugUtility<string>.DrugToString(packagedDrugModelV2), IsDeleted = false, Version = 0 };
            List<DrugEntity> drugList = new() { entityFData, entityMData, entityPData };

            FormularyDrugModelV2 formularyDrugModel1 = new()
            {
                DrugId = "drug1",
                Name = "drug1 name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };

            FormularyDrugModelV2 formularyDrugModel2 = new()
            {
                DrugId = "drug2",
                Name = "drug2 name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };

            ManufacturedDrugModelV2 manufacturedDrugModel1 = new()
            {
                DrugId = "drug1/NDC1",
                ManufacturerId = "NDC1",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug1",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC1"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 manufacturedDrugModel2 = new()
            {
                DrugId = "drug2/NDC2",
                ManufacturerId = "NDC2",
                ManufacturerName = "ManufacturerName2",
                Name = "BrandName2",
                FormularyDrugId = "drug2",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC2"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            PackagedDrugModelV2 packagedDrugModel1 = new()
            {
                DrugId = "drug2/NDC2/Each",
                ManufacturedDrugId = "drug2/NDC2",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "987654321", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            DrugCacheDataEntity drugCacheDataEntity = new()
            {
                DrugId = "drug",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
            };

            DrugCacheDataEntity drugCacheDataEntityForManufacturer1 = new(manufacturedDrugModel1, "")
            {
                DrugId = "drug1/NDC1",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Manufactured,
                HasDrugInfo = true,
                Id = "drug1/NDC1",
                IsActive = true,
                Origin = "UI",
            };

            DrugCacheDataEntity drugCacheDataEntityForManufacturer4 = new()
            {
                DrugId = "drug4/NDC4",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Manufactured,
                HasDrugInfo = true,
                Id = "drug4/NDC4",
                IsActive = true,
                Origin = "UI",
            };

            DrugCacheDataEntity drugCacheDataEntityForPackage2 = new(packagedDrugModel1, "")
            {
                DrugId = "drug2/NDC2/Each",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Packaged,
                HasDrugInfo = true,
                Id = "drug2/NDC2/Each",
                IsActive = true,
                Origin = "UI",
            };

            DrugCacheDataEntity drugCacheDataEntityForPackage4 = new()
            {
                DrugId = "drug4/NDC4/Each",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Packaged,
                HasDrugInfo = true,
                Id = "drug4/NDC4/Each",
                IsActive = true,
                Origin = "UI",
            };

            DrugCacheDataEntity drugCacheDataEntityForManufacturer2 = new(manufacturedDrugModel2, "")
            {
                DrugId = "drug2/NDC2",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Manufactured,
                HasDrugInfo = true,
                Id = "drug2/NDC2",
                IsActive = true,
                Origin = "UI",
                Children = new List<DrugCacheDataEntity>() { drugCacheDataEntityForPackage2 }
            };



            DrugCacheDataEntity drugCacheDataEntity1 = new(formularyDrugModel1, "")
            {
                DrugId = "drug1",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug1",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                Children = new List<DrugCacheDataEntity>() { drugCacheDataEntityForManufacturer1 },
            };

            DrugCacheDataEntity drugCacheDataEntity2 = new(formularyDrugModel2, "")
            {
                DrugId = "drug2",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug2",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                Children = new List<DrugCacheDataEntity>() { drugCacheDataEntityForManufacturer2 },
            };

            List<DrugCacheDataEntity> drugCacheDataEntities = new() {  
                drugCacheDataEntityForManufacturer1, drugCacheDataEntityForManufacturer2,
                drugCacheDataEntityForPackage2
            };


            Mock<ISessionFactory> mockSessionFactory = new();
            Mock<ISession> mockSession = new();
            Mock<IQuery> queryMock = new();
            Mock<ITransaction> mockTransaction = new();
            Mock<IStatelessSession> mockStateSession = new();
            Mock<DrugCache> mockCache = new(new Mock<ISessionFactory>().Object, new Mock<ILogger<DrugCache>>().Object);
            mockSessionFactory.Setup(x => x.OpenStatelessSession()).Returns(mockStateSession.Object);
            mockSession.Setup(x => x.BeginTransaction()).Returns(mockTransaction.Object);
            mockStateSession.Setup(x => x.BeginTransaction()).Returns(mockTransaction.Object);
            mockSession.Setup(x => x.Dispose());
            mockSessionFactory.Setup(x => x.Dispose());
            mockTransaction.Setup(x => x.Commit());
            mockTransaction.Setup(x => x.Dispose());
            mockStateSession.Setup(x => x.Dispose());

            mockTransaction.Setup(x => x.Commit()).Verifiable();
#pragma warning disable CS0618 // Type or member is obsolete
            mockSession.SetupGet(x => x.Transaction).Returns(mockTransaction.Object);
            mockStateSession.SetupGet(x => x.Transaction).Returns(mockTransaction.Object);
#pragma warning restore CS0618 // Type or member is obsolete
            mockSession.Setup(session => session.CreateQuery("from drugs")).Returns(queryMock.Object);
            mockSession.Setup(session => session.Query<DrugEntity>()).Returns(new TestingQueryable<DrugEntity>(drugList.AsQueryable()));
            mockStateSession.Setup(session => session.Query<DrugEntity>()).Returns(new TestingQueryable<DrugEntity>(drugList.AsQueryable()));
            queryMock.Setup(x => x.List<DrugEntity>()).Returns(drugList);

            OriginData.OriginAsChangeset = new List<string>() { "mfn" };
            OriginData.OriginsToUpdateWM6 = new List<string>() { "ui", "import" };
            OriginData.AllowedOriginTypes = new List<string>() { "ui", "import", "wm6", "mfn" };
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug", false).Result).Returns(drugCacheDataEntity);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1", false).Result).Returns(drugCacheDataEntity1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2", false).Result).Returns(drugCacheDataEntity2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1/NDC1", false).Result).Returns(drugCacheDataEntityForManufacturer1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2/NDC2", false).Result).Returns(drugCacheDataEntityForManufacturer2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug4/NDC4", false).Result).Returns(drugCacheDataEntityForManufacturer4);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2/NDC2/Each", false).Result).Returns(drugCacheDataEntityForPackage2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug4/NDC4/Each", false).Result).Returns(drugCacheDataEntityForPackage4);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1/ndc1", false).Result).Returns(drugCacheDataEntityForManufacturer1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2/ndc1", false).Result).Returns(drugCacheDataEntityForManufacturer2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug4/ndc4", false).Result).Returns(drugCacheDataEntityForManufacturer4);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2/ndc2/each", false).Result).Returns(drugCacheDataEntityForPackage2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug4/ndc4/each", false).Result).Returns(drugCacheDataEntityForPackage4);
            mockCache.Setup(x => x.FindInCacheIdentifierAsync(null).Result).Returns(drugCacheDataEntities.AsEnumerable());

            drugValidator = new DrugValidator(mockCache.Object, logDrugValidator);
        }
        #endregion
        #region Method
        [TestMethod]
        public void ValidateDeleteDrugRequestAsyncTest()
        {
            //Act
            ValidationResult? result = drugValidator?.ValidateDeleteDrugRequestAsync("drug").Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.IsNull(result.Error);
            Assert.IsFalse(result.IsError);
        }

        [TestMethod]
        public void ValidateDeleteDrugRequestAsyncDrugDoestNotExistTest()
        {
            //Act
            ValidationResult? result = drugValidator?.ValidateDeleteDrugRequestAsync("drug3").Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsError);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual(result.Error.Status, 404);
            Assert.AreEqual(result.Error.Title, "Drug does not exist");
            Assert.AreEqual(result.Error.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());
        }

        [TestMethod]
        public void ValidateFormularyDrugRequestAsyncTest()
        {
            FormularyDrugModelV2 localFormularyDrugModelV2 = new()
            {
                DrugId = "drug-local",
                Name = "drug name local",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };
            //Act
            ValidationResult? result = drugValidator?.ValidateFormularyDrugRequestAsync(localFormularyDrugModelV2).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.IsNull(result.Error);
            Assert.IsFalse(result.IsError);
        }

        [TestMethod]
        public void ValidateFormularyDrugRequestAsyncAllErrorsTest()
        {
            FormularyDrugModelV2 localFormularyDrugModel1 = new()
            {
                DrugId = "",
                Name = "drug name local",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0,
                Status = DrugStatus.Approved
            };

            FormularyDrugModelV2 localFormularyDrugModel2 = new()
            {
                DrugId = "drug3",
                Name = "",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() {  },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };

            FormularyDrugModelV2 localFormularyDrugModel6 = new()
            {
                DrugId = "drug3",
                Name = "drug name local",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0,
                Status = DrugStatus.Approved
            };

            FormularyDrugModelV2 localFormularyDrugModel3 = new()
            {
                DrugId = "drug3",
                Name = "drug3",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = new(),
                Version = 0,
                Status = DrugStatus.Active
            };

            FormularyDrugModelV2 localFormularyDrugModel4 = new()
            {
                DrugId = "drug3",
                Name = "drug3",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0,
                Status = DrugStatus.Active
            };

            //DRUG_ID_IS_MANDATORY
            //Act
            ValidationResult? resultDrugIdIsMandatory = drugValidator?.ValidateFormularyDrugRequestAsync(localFormularyDrugModel1).Result;
            //Assert
            Assert.IsNotNull(resultDrugIdIsMandatory);
            Assert.IsTrue(resultDrugIdIsMandatory.IsError);
            Assert.IsNotNull(resultDrugIdIsMandatory.Error);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Status, 400);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Title, "Drug Id is mandatory");
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Type, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());

            //DRUG_STATUS_IS_INVALID
            //Act
            ValidationResult? resultDrugStatusIsInvalid = drugValidator?.ValidateFormularyDrugRequestAsync(localFormularyDrugModel6).Result;
            //Assert
            Assert.IsNotNull(resultDrugStatusIsInvalid);
            Assert.IsTrue(resultDrugStatusIsInvalid.IsError);
            Assert.IsNotNull(resultDrugStatusIsInvalid.Error);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Status, 400);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Title, "Invalid status");
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Type, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString());

            //DRUG_NAME_IDENTIFIERS_HAZARDOUSTYPE_ARE_MANDATORY
            //Act
            ValidationResult? resultNameHazardousMandatory = drugValidator?.ValidateFormularyDrugRequestAsync(localFormularyDrugModel2).Result;
            //Assert
            Assert.IsNotNull(resultNameHazardousMandatory);
            Assert.IsTrue(resultNameHazardousMandatory.IsError);
            Assert.IsNotNull(resultNameHazardousMandatory.Error);
            Assert.AreEqual(resultNameHazardousMandatory.Error.Status, 400);
            Assert.AreEqual(resultNameHazardousMandatory.Error.Title, "Name, identifier(s), hazardoustypes are mandatory");
            Assert.AreEqual(resultNameHazardousMandatory.Error.Type, ProblemErrorCode.DRUG_NAME_IDENTIFIERS_HAZARDOUSTYPE_ARE_MANDATORY.ToString());

            //DRUG_ROOTLOCATIONID_IS_MANDATORY
            //Act
            ValidationResult? resultRootLocationIdMandatory = drugValidator?.ValidateFormularyDrugRequestAsync(localFormularyDrugModel3).Result;
            //Assert
            Assert.IsNotNull(resultRootLocationIdMandatory);
            Assert.IsTrue(resultRootLocationIdMandatory.IsError);
            Assert.IsNotNull(resultRootLocationIdMandatory.Error);
            Assert.AreEqual(resultRootLocationIdMandatory.Error.Status, 400);
            Assert.AreEqual(resultRootLocationIdMandatory.Error.Title, "Root location Id is mandatory");
            Assert.AreEqual(resultRootLocationIdMandatory.Error.Type, ProblemErrorCode.DRUG_ROOTLOCATIONID_IS_MANDATORY.ToString());

            //DRUG_ORIGIN_IS_INVALID
            //Act
            ValidationResult? resultOriginIsInvalid = drugValidator?.ValidateFormularyDrugRequestAsync(localFormularyDrugModel4).Result;
            //Assert
            Assert.IsNotNull(resultOriginIsInvalid);
            Assert.IsTrue(resultOriginIsInvalid.IsError);
            Assert.IsNotNull(resultOriginIsInvalid.Error);
            Assert.AreEqual(resultOriginIsInvalid.Error.Status, 400);
            Assert.AreEqual(resultOriginIsInvalid.Error.Title, "Origin is invalid");
            Assert.AreEqual(resultOriginIsInvalid.Error.Type, ProblemErrorCode.DRUG_ORIGIN_IS_INVALID.ToString());

            //DRUG_ID_ALREADY_EXIST
            //Act
            ValidationResult? resultDrugIdAlreadyExist = drugValidator?.ValidateFormularyDrugRequestAsync(formularyDrugModelV2).Result;
            //Assert
            Assert.IsNotNull(resultDrugIdAlreadyExist);
            Assert.IsTrue(resultDrugIdAlreadyExist.IsError);
            Assert.IsNotNull(resultDrugIdAlreadyExist.Error);
            Assert.AreEqual(resultDrugIdAlreadyExist.Error.Status, 409);
            Assert.AreEqual(resultDrugIdAlreadyExist.Error.Title, "Drug Id already exist");
            Assert.AreEqual(resultDrugIdAlreadyExist.Error.Type, ProblemErrorCode.DRUG_ID_ALREADY_EXIST.ToString());

            //DRUG_ID_IS_MANDATORY FOR UPDATE CALL
            //Act
            ValidationResult? resultIdMandatoryForUpdateCall = drugValidator?.ValidateFormularyDrugRequestAsync(formularyDrugModelV2, "").Result;
            //Assert
            Assert.IsNotNull(resultIdMandatoryForUpdateCall);
            Assert.IsTrue(resultIdMandatoryForUpdateCall.IsError);
            Assert.IsNotNull(resultIdMandatoryForUpdateCall.Error);
            Assert.AreEqual(resultIdMandatoryForUpdateCall.Error.Status, 400);
            Assert.AreEqual(resultIdMandatoryForUpdateCall.Error.Title, "Drug Id is mandatory");
            Assert.AreEqual(resultIdMandatoryForUpdateCall.Error.Type, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());

            //DRUG_DOES_NOT_EXIST FOR UPDATE CALL
            //Act
            ValidationResult? resultDoestNotExistForUpdateCall = drugValidator?.ValidateFormularyDrugRequestAsync(formularyDrugModelV2, "drug5").Result;
            //Assert
            Assert.IsNotNull(resultDoestNotExistForUpdateCall);
            Assert.IsTrue(resultDoestNotExistForUpdateCall.IsError);
            Assert.IsNotNull(resultDoestNotExistForUpdateCall.Error);
            Assert.AreEqual(resultDoestNotExistForUpdateCall.Error.Status, 404);
            Assert.AreEqual(resultDoestNotExistForUpdateCall.Error.Title, "Drug does not exist");
            Assert.AreEqual(resultDoestNotExistForUpdateCall.Error.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());

            //DRUG_ID_DOES_NOT_MATCH FOR UPDATE CALL
            //Act
            ValidationResult? resultDoestNotMatchForUpdateCall = drugValidator?.ValidateFormularyDrugRequestAsync(formularyDrugModelV2, "drug1").Result;
            //Assert
            Assert.IsNotNull(resultDoestNotMatchForUpdateCall);
            Assert.IsTrue(resultDoestNotMatchForUpdateCall.IsError);
            Assert.IsNotNull(resultDoestNotMatchForUpdateCall.Error);
            Assert.AreEqual(resultDoestNotMatchForUpdateCall.Error.Status, 409);
            Assert.AreEqual(resultDoestNotMatchForUpdateCall.Error.Title, "Drug Id does not match");
            Assert.AreEqual(resultDoestNotMatchForUpdateCall.Error.Type, ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString());
        }

        [TestMethod]
        public void ValidateMfgDrugRequestAsyncTest()
        {
            ManufacturedDrugModelV2 localManufacturedDrugModel1 = new()
            {
                DrugId = "drug/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            //Act
            ValidationResult? result = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel1).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.IsNull(result.Error);
            Assert.IsFalse(result.IsError);
        }

        [TestMethod]
        public void ValidateMfgDrugRequestAsyncAllErrorTest()
        {
            ManufacturedDrugModelV2 localManufacturedDrugModel1 = new()
            {
                DrugId = "",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel2 = new()
            {
                DrugId = "drug/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI",
                Status = DrugStatus.Approved
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel3 = new()
            {
                DrugId = "drug1/NDC1",
                ManufacturerId = "NDC1",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC1"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            ManufacturedDrugModelV2 localManufacturedDrugModel4Dup = new()
            {
                DrugId = "drug1/NDC1/12345B/1111B",
                ManufacturerId = "NDC1Dup",
                ManufacturerName = "ManufacturerNameDup",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC1"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            ManufacturedDrugModelV2 localManufacturedDrugModel4 = new()
            {
                DrugId = "drug1/NDC1/12345/1111",
                ManufacturerId = "NDC1",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC1A"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel5 = new()
            {
                DrugId = "drug1/NDC2",
                ManufacturerId = "NDC2",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = ""
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel6 = new()
            {
                DrugId = "drug1/NDC1",
                ManufacturerId = "NDC1",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC1"
                    }
                },
                Version = 0,
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel7 = new()
            {
                DrugId = "drug1/NDC1",
                ManufacturerId = "NDC1",
                ManufacturerName = "ManufacturerName1",
                Name = "BrandName1",
                FormularyDrugId = "drug1",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC2"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel8 = new()
            {
                DrugId = "drug1/NDC1",
                ManufacturerId = "NDC1",
                ManufacturerName = "ManufacturerName1",
                Name = "BrandName1",
                FormularyDrugId = "drug1",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC2"
                    },
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC2"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel9 = new()
            {
                DrugId = "drug1/NDC3",
                ManufacturerId = "NDC3",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug3",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC3"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel10 = new()
            {
                DrugId = "drug3/NDC3",
                ManufacturerId = "NDC3",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug1",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC3"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            //drug1/NDC1

            //DRUG_ID_IS_MANDATORY
            //Act
            ValidationResult? resultDrugIdIsMandatory = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel1).Result;
            //Assert
            Assert.IsNotNull(resultDrugIdIsMandatory);
            Assert.IsTrue(resultDrugIdIsMandatory.IsError);
            Assert.IsNotNull(resultDrugIdIsMandatory.Error);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Status, 400);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Title, "Drug Id is mandatory");
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Type, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());

            //DRUG_STATUS_IS_INVALID
            //Act
            ValidationResult? resultDrugStatusIsInvalid = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel2).Result;
            //Assert
            Assert.IsNotNull(resultDrugStatusIsInvalid);
            Assert.IsTrue(resultDrugStatusIsInvalid.IsError);
            Assert.IsNotNull(resultDrugStatusIsInvalid.Error);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Status, 400);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Title, "Status is invalid");
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Type, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString());

            //DRUG_ID_ALREADY_EXIST
            //Act
            ValidationResult? resultDrugIdAlreadyExist = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel3).Result;
            //Assert
            Assert.IsNotNull(resultDrugIdAlreadyExist);
            Assert.IsTrue(resultDrugIdAlreadyExist.IsError);
            Assert.IsNotNull(resultDrugIdAlreadyExist.Error);
            Assert.AreEqual(resultDrugIdAlreadyExist.Error.Status, 409);
            Assert.AreEqual(resultDrugIdAlreadyExist.Error.Title, "Drug Id already exist");
            Assert.AreEqual(resultDrugIdAlreadyExist.Error.Type, ProblemErrorCode.DRUG_ID_ALREADY_EXIST.ToString());

            //DRUG_NDC_ALREADY_EXIST
            //Act

            ValidationResult? resultNDCAlreadyExist = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel4Dup).Result;
            //Assert
            Assert.IsNotNull(resultNDCAlreadyExist);
            Assert.IsTrue(resultNDCAlreadyExist.IsError);
            Assert.IsNotNull(resultNDCAlreadyExist.Error);
            Assert.AreEqual(409, resultNDCAlreadyExist.Error.Status );
            Assert.AreEqual(resultNDCAlreadyExist.Error.Title, "Drug Identifier already exist");
            Assert.AreEqual(resultNDCAlreadyExist.Error.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());

            //DRUG_MANUFACTURER_DRUG_ID_IS_INVALID
            //Act
            ValidationResult? resultMfgDrugIdInvalid = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel4).Result;
            //Assert
            Assert.IsNotNull(resultMfgDrugIdInvalid);
            Assert.IsTrue(resultMfgDrugIdInvalid.IsError);
            Assert.IsNotNull(resultMfgDrugIdInvalid.Error);
            Assert.AreEqual(resultMfgDrugIdInvalid.Error.Status, 400);
            Assert.AreEqual(resultMfgDrugIdInvalid.Error.Title, "Manufactured drug Id is invalid");
            Assert.AreEqual(resultMfgDrugIdInvalid.Error.Type, ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID.ToString());

            //DRUG_CODE_IS_REQUIRED_ALONG_WITH_CODING_SYSTEM_VALUE
            //Act
            ValidationResult? resultDrugCodeRequired = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel5).Result;
            //Assert
            Assert.IsNotNull(resultDrugCodeRequired);
            Assert.IsTrue(resultDrugCodeRequired.IsError);
            Assert.IsNotNull(resultDrugCodeRequired.Error);
            Assert.AreEqual(resultDrugCodeRequired.Error.Status, 400);
            Assert.AreEqual(resultDrugCodeRequired.Error.Title, "Drug identifier is required along with type value");
            Assert.AreEqual(resultDrugCodeRequired.Error.Type, ProblemErrorCode.DRUG_CODE_IS_REQUIRED_ALONG_WITH_CODING_SYSTEM_VALUE.ToString());

            //DRUG_FORMULARY_DRUG_ID_IS_INVALID
            //Act
            ValidationResult? resultFormularyDrugIdInvalid = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel9).Result;
            //Assert
            Assert.IsNotNull(resultFormularyDrugIdInvalid);
            Assert.IsTrue(resultFormularyDrugIdInvalid.IsError);
            Assert.IsNotNull(resultFormularyDrugIdInvalid.Error);
            Assert.AreEqual(resultFormularyDrugIdInvalid.Error.Status, 409);
            Assert.AreEqual(resultFormularyDrugIdInvalid.Error.Title, "Formulary drug Id is invalid");
            Assert.AreEqual(resultFormularyDrugIdInvalid.Error.Type, ProblemErrorCode.DRUG_FORMULARY_DRUG_ID_IS_INVALID.ToString());

            //DRUG_DOES_NOT_EXIST
            //Act
            ValidationResult? resultFormularyDrugNotExist = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel10).Result;
            //Assert
            Assert.IsNotNull(resultFormularyDrugNotExist);
            Assert.IsTrue(resultFormularyDrugNotExist.IsError);
            Assert.IsNotNull(resultFormularyDrugNotExist.Error);
            Assert.AreEqual(resultFormularyDrugNotExist.Error.Status, 404);
            Assert.AreEqual(resultFormularyDrugNotExist.Error.Title, "Drug does not exist");
            Assert.AreEqual(resultFormularyDrugNotExist.Error.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());

            //DRUG_ID_IS_MANDATORY
            //Act
            ValidationResult? resultDrugIdIsMandatory2 = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel3, "").Result;
            //Assert
            Assert.IsNotNull(resultDrugIdIsMandatory2);
            Assert.IsTrue(resultDrugIdIsMandatory2.IsError);
            Assert.IsNotNull(resultDrugIdIsMandatory2.Error);
            Assert.AreEqual(resultDrugIdIsMandatory2.Error.Status, 400);
            Assert.AreEqual(resultDrugIdIsMandatory2.Error.Title, "Drug Id is mandatory");
            Assert.AreEqual(resultDrugIdIsMandatory2.Error.Type, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());

            //DRUG_DOES_NOT_EXIST
            //Act
            ValidationResult? resultDrugDoesNotExist = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel3, "drug1/NDC2").Result;
            //Assert
            Assert.IsNotNull(resultDrugDoesNotExist);
            Assert.IsTrue(resultDrugDoesNotExist.IsError);
            Assert.IsNotNull(resultDrugDoesNotExist.Error);
            Assert.AreEqual(resultDrugDoesNotExist.Error.Status, 404);
            Assert.AreEqual(resultDrugDoesNotExist.Error.Title, "Drug does not exist");
            Assert.AreEqual(resultDrugDoesNotExist.Error.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());

            //DRUG_ID_DOES_NOT_MATCH
            //Act
            ValidationResult? resultDrugIdNotMatched = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel3, "drug2/NDC2").Result;
            //Assert
            Assert.IsNotNull(resultDrugIdNotMatched);
            Assert.IsTrue(resultDrugIdNotMatched.IsError);
            Assert.IsNotNull(resultDrugIdNotMatched.Error);
            Assert.AreEqual(resultDrugIdNotMatched.Error.Status, 409);
            Assert.AreEqual(resultDrugIdNotMatched.Error.Title, "Drug Id does not match");
            Assert.AreEqual(resultDrugIdNotMatched.Error.Type, ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString());

            //DRUG_ORIGIN_IS_INVALID
            //Act
            ValidationResult? resultOriginNotMatch = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel6, "drug2/NDC2").Result;
            //Assert
            Assert.IsNotNull(resultOriginNotMatch);
            Assert.IsTrue(resultOriginNotMatch.IsError);
            Assert.IsNotNull(resultOriginNotMatch.Error);
            Assert.AreEqual(resultOriginNotMatch.Error.Status, 409);
            Assert.AreEqual(resultOriginNotMatch.Error.Title, "Origin is invalid");
            Assert.AreEqual(resultOriginNotMatch.Error.Type, ProblemErrorCode.DRUG_ORIGIN_IS_INVALID.ToString());            

            //DRUG_CODE_ALREADY_EXIST
            //Act
            ValidationResult? resultDrugCodeExist = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel7, "drug1/NDC1").Result;
            //Assert
            Assert.IsNotNull(resultDrugCodeExist);
            Assert.IsTrue(resultDrugCodeExist.IsError);
            Assert.IsNotNull(resultDrugCodeExist.Error);
            Assert.AreEqual(resultDrugCodeExist.Error.Status, 409);
            Assert.AreEqual(resultDrugCodeExist.Error.Title, "Drug Identifier already exist");
            Assert.AreEqual(resultDrugCodeExist.Error.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());

            //DRUG_INPUT_DATA_DUPLICATE_IDENTIFIER
            //Act
            ValidationResult? resultDuplicateIdentifier = drugValidator?.ValidateMfgDrugRequestAsync(localManufacturedDrugModel8, "drug1/NDC1").Result;
            //Assert
            Assert.IsNotNull(resultDuplicateIdentifier);
            Assert.IsTrue(resultDuplicateIdentifier.IsError);
            Assert.IsNotNull(resultDuplicateIdentifier.Error);
            Assert.AreEqual(resultDuplicateIdentifier.Error.Status, 409);
            Assert.AreEqual(resultDuplicateIdentifier.Error.Title, "Input data has duplicate identifier");
            Assert.AreEqual(resultDuplicateIdentifier.Error.Type, ProblemErrorCode.DRUG_INPUT_DATA_DUPLICATE_IDENTIFIER.ToString());
        }

        [TestMethod]
        public void ValidatePutMfgDrugRequestAsyncTest()
        {
            ManufacturedDrugModelV2 localManufacturedDrugModel1 = new()
            {
                DrugId = "drug/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            //Act
            ValidationResult? result = drugValidator?.ValidatePutMfgDrugRequestAsync(localManufacturedDrugModel1).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.IsNull(result.Error);
            Assert.IsFalse(result.IsError);
        }

        [TestMethod]
        public void ValidatePutMfgDrugRequestAsyncAllErrorTest()
        {
            ManufacturedDrugModelV2 localManufacturedDrugModel1 = new()
            {
                DrugId = "",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel2 = new()
            {
                DrugId = "drug/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI",
                Status = DrugStatus.Approved
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel3 = new()
            {
                DrugId = "drug1/NDC1",
                ManufacturerId = "NDC1",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug1",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC1"
                    },
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC2"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel4 = new()
            {
                DrugId = "drug1/NDC1",
                ManufacturerId = "NDC1",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug1",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC3"
                    },
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC3"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel9 = new()
            {
                DrugId = "drug1/NDC3",
                ManufacturerId = "NDC3",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug3",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC3"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            ManufacturedDrugModelV2 localManufacturedDrugModel10 = new()
            {
                DrugId = "drug3/NDC3",
                ManufacturerId = "NDC3",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug1",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "NDC3"
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            //drug1/NDC1

            //DRUG_ID_IS_MANDATORY
            //Act
            ValidationResult? resultDrugIdIsMandatory = drugValidator?.ValidatePutMfgDrugRequestAsync(localManufacturedDrugModel1).Result;
            //Assert
            Assert.IsNotNull(resultDrugIdIsMandatory);
            Assert.IsTrue(resultDrugIdIsMandatory.IsError);
            Assert.IsNotNull(resultDrugIdIsMandatory.Error);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Status, 400);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Title, "Drug Id is mandatory");
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Type, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());

            //DRUG_STATUS_IS_INVALID
            //Act
            ValidationResult? resultDrugStatusIsInvalid = drugValidator?.ValidatePutMfgDrugRequestAsync(localManufacturedDrugModel2).Result;
            //Assert
            Assert.IsNotNull(resultDrugStatusIsInvalid);
            Assert.IsTrue(resultDrugStatusIsInvalid.IsError);
            Assert.IsNotNull(resultDrugStatusIsInvalid.Error);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Status, 400);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Title, "Status is invalid");
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Type, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString()); 

            //DRUG_FORMULARY_DRUG_ID_IS_INVALID
            //Act
            ValidationResult? resultFormularyDrugIdInvalid = drugValidator?.ValidatePutMfgDrugRequestAsync(localManufacturedDrugModel9).Result;
            //Assert
            Assert.IsNotNull(resultFormularyDrugIdInvalid);
            Assert.IsTrue(resultFormularyDrugIdInvalid.IsError);
            Assert.IsNotNull(resultFormularyDrugIdInvalid.Error);
            Assert.AreEqual(resultFormularyDrugIdInvalid.Error.Status, 409);
            Assert.AreEqual(resultFormularyDrugIdInvalid.Error.Title, "Formulary drug Id is invalid");
            Assert.AreEqual(resultFormularyDrugIdInvalid.Error.Type, ProblemErrorCode.DRUG_FORMULARY_DRUG_ID_IS_INVALID.ToString());

            //DRUG_DOES_NOT_EXIST
            //Act
            ValidationResult? resultFormularyDrugNotExist = drugValidator?.ValidatePutMfgDrugRequestAsync(localManufacturedDrugModel10).Result;
            //Assert
            Assert.IsNotNull(resultFormularyDrugNotExist);
            Assert.IsTrue(resultFormularyDrugNotExist.IsError);
            Assert.IsNotNull(resultFormularyDrugNotExist.Error);
            Assert.AreEqual(resultFormularyDrugNotExist.Error.Status, 404);
            Assert.AreEqual(resultFormularyDrugNotExist.Error.Title, "Drug does not exist");
            Assert.AreEqual(resultFormularyDrugNotExist.Error.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());

            //DRUG_INPUT_DATA_DUPLICATE_IDENTIFIER
            //Act
            ValidationResult? resultDuplicateIdentifier = drugValidator?.ValidatePutMfgDrugRequestAsync(localManufacturedDrugModel4).Result;
            //Assert
            Assert.IsNotNull(resultDuplicateIdentifier);
            Assert.IsTrue(resultDuplicateIdentifier.IsError);
            Assert.IsNotNull(resultDuplicateIdentifier.Error);
            Assert.AreEqual(resultDuplicateIdentifier.Error.Status, 409);
            Assert.AreEqual(resultDuplicateIdentifier.Error.Title, "Input data has duplicate identifier");
            Assert.AreEqual(resultDuplicateIdentifier.Error.Type, ProblemErrorCode.DRUG_INPUT_DATA_DUPLICATE_IDENTIFIER.ToString());

            //DRUG_CODE_ALREADY_EXIST
            //Act
            ValidationResult? resultDrugCodeAlreadyExist = drugValidator?.ValidatePutMfgDrugRequestAsync(localManufacturedDrugModel3).Result;
            //Assert
            Assert.IsNotNull(resultDrugCodeAlreadyExist);
            Assert.IsTrue(resultDrugCodeAlreadyExist.IsError);
            Assert.IsNotNull(resultDrugCodeAlreadyExist.Error);
            Assert.AreEqual(resultDrugCodeAlreadyExist.Error.Status, 409);
            Assert.AreEqual(resultDrugCodeAlreadyExist.Error.Title, "Drug Identifier already exist");
            Assert.AreEqual(resultDrugCodeAlreadyExist.Error.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
        }

        [TestMethod]
        public void ValidatePackagedDrugRequestAsyncTest()
        {
            PackagedDrugModelV2 packagedDrugModel1 = new()
            {
                DrugId = "drug1/NDC1/Pack",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            //Act
            ValidationResult? result = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel1).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.IsNull(result.Error);
            Assert.IsFalse(result.IsError);
        }

        [TestMethod]
        public void ValidatePackagedDrugRequestAsyncAllErrorTest()
        {
            PackagedDrugModelV2 packagedDrugModel1 = new()
            {
                DrugId = "",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            PackagedDrugModelV2 packagedDrugModel2 = new()
            {
                DrugId = "drug1/NDC1/Pack",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Pack",
                PackageId = "",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
                Status = DrugStatus.Active
            };

            PackagedDrugModelV2 packagedDrugModel3 = new()
            {
                DrugId = "drug1/NDC1/Pack",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
                Status = DrugStatus.Approved
            };
            PackagedDrugModelV2 packagedDrugModel4 = new()
            {
                DrugId = "drug1/NDC1/Pack",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0
            };
            PackagedDrugModelV2 packagedDrugModel5 = new()
            {
                DrugId = "drug2/NDC2/Each",
                ManufacturedDrugId = "drug2/NDC2",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel6 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC2",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel7 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel8 = new()
            {
                DrugId = "drug1//Each",
                ManufacturedDrugId = "drug2/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel9 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug2/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel10 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "BARCODE1", Status = IdentifierStatus.APPROVED
                    },
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "BARCODE1", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel11 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "987654321", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel12 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "333-000-111", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel13 = new()
            {
                DrugId = "drug5/NDC1/Each",
                ManufacturedDrugId = "drug5/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel14 = new()
            {
                DrugId = "drug4/NDC4/Pack",
                ManufacturedDrugId = "drug4/NDC4",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "122-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            //DRUG_ID_IS_MANDATORY
            //Act
            ValidationResult? resultDrugIdIsMandatory = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel1).Result;
            //Assert
            Assert.IsNotNull(resultDrugIdIsMandatory);
            Assert.IsTrue(resultDrugIdIsMandatory.IsError);
            Assert.IsNotNull(resultDrugIdIsMandatory.Error);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Status, 400);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Title, "Drug Id is mandatory");
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Type, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());

            //DRUG_PACKAGE_ID_IS_MANDATORY
            //Act
            ValidationResult? resultPackageIsMandatory = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel2).Result;
            //Assert
            Assert.IsNotNull(resultPackageIsMandatory);
            Assert.IsTrue(resultPackageIsMandatory.IsError);
            Assert.IsNotNull(resultPackageIsMandatory.Error);
            Assert.AreEqual(resultPackageIsMandatory.Error.Status, 400);
            Assert.AreEqual(resultPackageIsMandatory.Error.Title, "Package Id is mandatory");
            Assert.AreEqual(resultPackageIsMandatory.Error.Type, ProblemErrorCode.DRUG_PACKAGE_ID_IS_MANDATORY.ToString());

            //DRUG_STATUS_IS_INVALID
            //Act
            ValidationResult? resultDrugStatusIsInvalid = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel3).Result;
            //Assert
            Assert.IsNotNull(resultDrugStatusIsInvalid);
            Assert.IsTrue(resultDrugStatusIsInvalid.IsError);
            Assert.IsNotNull(resultDrugStatusIsInvalid.Error);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Status, 400);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Title, "Status is invalid");
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Type, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString());

            //DRUG_ORIGIN_IS_INVALID
            //Act
            ValidationResult? resultOriginInvalid = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel4).Result;
            //Assert
            Assert.IsNotNull(resultOriginInvalid);
            Assert.IsTrue(resultOriginInvalid.IsError);
            Assert.IsNotNull(resultOriginInvalid.Error);
            Assert.AreEqual(resultOriginInvalid.Error.Status, 409);
            Assert.AreEqual(resultOriginInvalid.Error.Title, "Origin is invalid");
            Assert.AreEqual(resultOriginInvalid.Error.Type, ProblemErrorCode.DRUG_ORIGIN_IS_INVALID.ToString());

            //DRUG_ID_ALREADY_EXIST
            //Act
            ValidationResult? resultDrugIdAlreadyExist = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel5).Result;
            //Assert
            Assert.IsNotNull(resultDrugIdAlreadyExist);
            Assert.IsTrue(resultDrugIdAlreadyExist.IsError);
            Assert.IsNotNull(resultDrugIdAlreadyExist.Error);
            Assert.AreEqual(resultDrugIdAlreadyExist.Error.Status, 409);
            Assert.AreEqual(resultDrugIdAlreadyExist.Error.Title, "Drug Id already exist");
            Assert.AreEqual(resultDrugIdAlreadyExist.Error.Type, ProblemErrorCode.DRUG_ID_ALREADY_EXIST.ToString());

            //DRUG_MANUFACTURER_DRUG_ID_IS_INVALID
            //Act
            ValidationResult? resultMfgDrugIdInvalid = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel6).Result;
            //Assert
            Assert.IsNotNull(resultMfgDrugIdInvalid);
            Assert.IsTrue(resultMfgDrugIdInvalid.IsError);
            Assert.IsNotNull(resultMfgDrugIdInvalid.Error);
            Assert.AreEqual(resultMfgDrugIdInvalid.Error.Status, 400);
            Assert.AreEqual(resultMfgDrugIdInvalid.Error.Title, "Manufactured drug Id is invalid");
            Assert.AreEqual(resultMfgDrugIdInvalid.Error.Type, ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID.ToString());
            

            //DRUG_CODE_IS_REQUIRED_ALONG_WITH_CODING_SYSTEM_VALUE
            //Act
            ValidationResult? resultIdentifierRequired = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel7).Result;
            //Assert
            Assert.IsNotNull(resultIdentifierRequired);
            Assert.IsTrue(resultIdentifierRequired.IsError);
            Assert.IsNotNull(resultIdentifierRequired.Error);
            Assert.AreEqual(resultIdentifierRequired.Error.Status, 400);
            Assert.AreEqual(resultIdentifierRequired.Error.Title, "Drug identifier is required along with type value");
            Assert.AreEqual(resultIdentifierRequired.Error.Type, ProblemErrorCode.DRUG_CODE_IS_REQUIRED_ALONG_WITH_CODING_SYSTEM_VALUE.ToString());

            //DRUG_ID_IS_INVALID
            //Act
            ValidationResult? resultDrugIdInvalid = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel8).Result;
            //Assert
            Assert.IsNotNull(resultDrugIdInvalid);
            Assert.IsTrue(resultDrugIdInvalid.IsError);
            Assert.IsNotNull(resultDrugIdInvalid.Error);
            Assert.AreEqual(resultDrugIdInvalid.Error.Status, 409);
            Assert.AreEqual(resultDrugIdInvalid.Error.Title, "Drug Id is invalid");
            Assert.AreEqual(resultDrugIdInvalid.Error.Type, ProblemErrorCode.DRUG_ID_IS_INVALID.ToString());

            //DRUG_MANUFACTURER_DRUG_ID_IS_INVALID
            //Act
            ValidationResult? result9 = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel9).Result;
            //Assert
            Assert.IsNotNull(result9);
            Assert.IsTrue(result9.IsError);
            Assert.IsNotNull(result9.Error);
            Assert.AreEqual(result9.Error.Status, 400);
            Assert.AreEqual(result9.Error.Title, "Manufactured drug Id is invalid");
            Assert.AreEqual(result9.Error.Type, ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID.ToString());

            //DRUG_INPUT_DATA_DUPLICATE_IDENTIFIER
            //Act
            ValidationResult? resultDuplicateIdentifier = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel10).Result;
            //Assert
            Assert.IsNotNull(resultDuplicateIdentifier);
            Assert.IsTrue(resultDuplicateIdentifier.IsError);
            Assert.IsNotNull(resultDuplicateIdentifier.Error);
            Assert.AreEqual(resultDuplicateIdentifier.Error.Status, 409);
            Assert.AreEqual(resultDuplicateIdentifier.Error.Title, "Input data has duplicate identifier");
            Assert.AreEqual(resultDuplicateIdentifier.Error.Type, ProblemErrorCode.DRUG_INPUT_DATA_DUPLICATE_IDENTIFIER.ToString());

            //DRUG_CODE_ALREADY_EXIST
            //Act
            ValidationResult? resultIdentifierExist = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel11).Result;
            //Assert
            Assert.IsNotNull(resultIdentifierExist);
            Assert.IsTrue(resultIdentifierExist.IsError);
            Assert.IsNotNull(resultIdentifierExist.Error);
            Assert.AreEqual(resultIdentifierExist.Error.Status, 409);
            Assert.AreEqual(resultIdentifierExist.Error.Title, "Drug Identifier already exist");
            Assert.AreEqual(resultIdentifierExist.Error.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());

            //DRUG_DOES_NOT_EXIST - MANUFACTURE NOT FOUND
            //Act
            ValidationResult? result13 = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel13).Result;
            //Assert
            Assert.IsNotNull(result13);
            Assert.IsTrue(result13.IsError);
            Assert.IsNotNull(result13.Error);
            Assert.AreEqual(result13.Error.Status, 404);
            Assert.AreEqual(result13.Error.Title, "Drug does not exist");
            Assert.AreEqual(result13.Error.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());

            //DRUG_DOES_NOT_EXIST - FORMULARY NOT FOUND
            //Act
            ValidationResult? result14 = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel14).Result;
            //Assert
            Assert.IsNotNull(result14);
            Assert.IsTrue(result14.IsError);
            Assert.IsNotNull(result14.Error);
            Assert.AreEqual(result14.Error.Status, 404);
            Assert.AreEqual(result14.Error.Title, "Drug does not exist");
            Assert.AreEqual(result14.Error.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());

            //DRUG_ID_IS_MANDATORY FOR UPDATE
            //Act
            ValidationResult? resultDrugIdInvalidForUpdate = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel12, "").Result;
            //Assert
            Assert.IsNotNull(resultDrugIdInvalidForUpdate);
            Assert.IsTrue(resultDrugIdInvalidForUpdate.IsError);
            Assert.IsNotNull(resultDrugIdInvalidForUpdate.Error);
            Assert.AreEqual(resultDrugIdInvalidForUpdate.Error.Status, 400);
            Assert.AreEqual(resultDrugIdInvalidForUpdate.Error.Title, "Drug Id is mandatory");
            Assert.AreEqual(resultDrugIdInvalidForUpdate.Error.Type, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());

            //DRUG_DOES_NOT_EXIST FOR UPDATE
            //Act
            ValidationResult? resultDrugNotExistForUpdate = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel12, "drug3/NDC3/Each").Result;
            //Assert
            Assert.IsNotNull(resultDrugNotExistForUpdate);
            Assert.IsTrue(resultDrugNotExistForUpdate.IsError);
            Assert.IsNotNull(resultDrugNotExistForUpdate.Error);
            Assert.AreEqual(resultDrugNotExistForUpdate.Error.Status, 404);
            Assert.AreEqual(resultDrugNotExistForUpdate.Error.Title, "Drug does not exist");
            Assert.AreEqual(resultDrugNotExistForUpdate.Error.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());

            //DRUG_ID_DOES_NOT_MATCH FOR UPDATE
            //Act
            ValidationResult? resultDrugNotMatchForUpdate = drugValidator?.ValidatePackagedDrugRequestAsync(packagedDrugModel12, "drug4/NDC4/Each").Result;
            //Assert
            Assert.IsNotNull(resultDrugNotMatchForUpdate);
            Assert.IsTrue(resultDrugNotMatchForUpdate.IsError);
            Assert.IsNotNull(resultDrugNotMatchForUpdate.Error);
            Assert.AreEqual(resultDrugNotMatchForUpdate.Error.Status, 409);
            Assert.AreEqual(resultDrugNotMatchForUpdate.Error.Title, "Drug Id does not match");
            Assert.AreEqual(resultDrugNotMatchForUpdate.Error.Type, ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString());
        }

        [TestMethod]
        public void ValidatePutPackagedDrugRequestAsyncTest()
        {
            PackagedDrugModelV2 packagedDrugModel1 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            //Act
            ValidationResult? result = drugValidator?.ValidatePutPackagedDrugRequestAsync("drug1/NDC1", packagedDrugModel1).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.IsNull(result.Error);
            Assert.IsFalse(result.IsError);
        }

        [TestMethod]
        public void ValidatePutPackagedDrugRequestAsyncAllErrorTest()
        {
            PackagedDrugModelV2 packagedDrugModel1 = new()
            {
                DrugId = "",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };

            PackagedDrugModelV2 packagedDrugModel2 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Pack",
                PackageId = "",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
                Status = DrugStatus.Active
            };

            PackagedDrugModelV2 packagedDrugModel3 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
                Status = DrugStatus.Approved
            };
            PackagedDrugModelV2 packagedDrugModel4 = new()
            {
                DrugId = "drug1/NDC1/Pack",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0
            };
            PackagedDrugModelV2 packagedDrugModel5 = new()
            {
                DrugId = "drug6/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            PackagedDrugModelV2 packagedDrugModel6 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "121-001-1234", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
            };
            //DRUG_ID_IS_MANDATORY
            //Act
            ValidationResult? resultDrugIdIsMandatory = drugValidator?.ValidatePutPackagedDrugRequestAsync("drug1/NDC1", packagedDrugModel1).Result;
            //Assert
            Assert.IsNotNull(resultDrugIdIsMandatory);
            Assert.IsTrue(resultDrugIdIsMandatory.IsError);
            Assert.IsNotNull(resultDrugIdIsMandatory.Error);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Status, 400);
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Title, "Drug Id is mandatory");
            Assert.AreEqual(resultDrugIdIsMandatory.Error.Type, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());

            //DRUG_PACKAGE_ID_IS_MANDATORY
            //Act
            ValidationResult? resultPackageIsMandatory = drugValidator?.ValidatePutPackagedDrugRequestAsync("drug1/NDC1", packagedDrugModel2).Result;
            //Assert
            Assert.IsNotNull(resultPackageIsMandatory);
            Assert.IsTrue(resultPackageIsMandatory.IsError);
            Assert.IsNotNull(resultPackageIsMandatory.Error);
            Assert.AreEqual(resultPackageIsMandatory.Error.Status, 400);
            Assert.AreEqual(resultPackageIsMandatory.Error.Title, "Package Id is mandatory");
            Assert.AreEqual(resultPackageIsMandatory.Error.Type, ProblemErrorCode.DRUG_PACKAGE_ID_IS_MANDATORY.ToString());

            //DRUG_STATUS_IS_INVALID
            //Act
            ValidationResult? resultDrugStatusIsInvalid = drugValidator?.ValidatePutPackagedDrugRequestAsync("drug1/NDC1", packagedDrugModel3).Result;
            //Assert
            Assert.IsNotNull(resultDrugStatusIsInvalid);
            Assert.IsTrue(resultDrugStatusIsInvalid.IsError);
            Assert.IsNotNull(resultDrugStatusIsInvalid.Error);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Status, 400);
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Title, "Status is invalid");
            Assert.AreEqual(resultDrugStatusIsInvalid.Error.Type, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString());

            //DRUG_ORIGIN_IS_INVALID
            //Act
            ValidationResult? resultOriginInvalid = drugValidator?.ValidatePutPackagedDrugRequestAsync("drug1/NDC1", packagedDrugModel4).Result;
            //Assert
            Assert.IsNotNull(resultOriginInvalid);
            Assert.IsTrue(resultOriginInvalid.IsError);
            Assert.IsNotNull(resultOriginInvalid.Error);
            Assert.AreEqual(resultOriginInvalid.Error.Status, 409);
            Assert.AreEqual(resultOriginInvalid.Error.Title, "Origin is invalid");
            Assert.AreEqual(resultOriginInvalid.Error.Type, ProblemErrorCode.DRUG_ORIGIN_IS_INVALID.ToString());

            //DRUG_DOES_NOT_EXIST FOR FORMULARY DRUG ID
            //Act
            ValidationResult? resultFormularyIdInvalid = drugValidator?.ValidatePutPackagedDrugRequestAsync("drug1/NDC1", packagedDrugModel5).Result;
            //Assert
            Assert.IsNotNull(resultFormularyIdInvalid);
            Assert.IsTrue(resultFormularyIdInvalid.IsError);
            Assert.IsNotNull(resultFormularyIdInvalid.Error);
            Assert.AreEqual(resultFormularyIdInvalid.Error.Status, 404);
            Assert.AreEqual(resultFormularyIdInvalid.Error.Title, "Drug does not exist");
            Assert.AreEqual(resultFormularyIdInvalid.Error.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());

            //DRUG_MANUFACTURER_DRUG_ID_IS_INVALID FOR MANUFACTURER DRUG ID
            //Act
            ValidationResult? resultManufactureDrugIdInvalid = drugValidator?.ValidatePutPackagedDrugRequestAsync("drug2/NDC2", packagedDrugModel6).Result;
            //Assert
            Assert.IsNotNull(resultManufactureDrugIdInvalid);
            Assert.IsTrue(resultManufactureDrugIdInvalid.IsError);
            Assert.IsNotNull(resultManufactureDrugIdInvalid.Error);
            Assert.AreEqual(resultManufactureDrugIdInvalid.Error.Status, 409);
            Assert.AreEqual(resultManufactureDrugIdInvalid.Error.Title, "Manufactured drug Id is invalid");
            Assert.AreEqual(resultManufactureDrugIdInvalid.Error.Type, ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID.ToString());

        }

        [TestMethod]
        public void ValidateBarcodeTest()
        {
            //Act
            ProblemDetail? result = drugValidator?.ValidateBarcode("12345690").Result;
            //Assert
            Assert.IsNull(result);
        }

        [TestMethod]
        public void ValidateBarcodeErrorTest()
        {
            //Act
            ProblemDetail? result = drugValidator?.ValidateBarcode("987654321").Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Status, 409);
            Assert.AreEqual(result.Title, "Drug Code already exist");
            Assert.AreEqual(result.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
        }
        #endregion

        #region Clean
        [TestCleanup]
        public void TestCleanUp()
        {
            drugValidator = null;
        }
        #endregion
    }
}
