﻿using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Moq;
using Drug.Services;
using NHibernate;
using Swisslog.Drug.Api;
using System.Linq;
using Drug;
using Drug.Data;
using Drug.Models;
using System;
using Swisslog.Base.Api;

namespace DrugTest.Service
{
    [TestClass]
    public class DrugCacheTest
    {
        DrugCache? drugCache;
        FormularyDrugModelV2? formularyDrugModelV2;
        ManufacturedDrugModelV2? manufacturedDrugModelV2;
        PackagedDrugModelV2? packagedDrugModelV2;
        Dictionary<string, string[]>? qryParams;
        readonly Dictionary<string, FormularyLocationSettingsModelV2> locations = new();
        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            ILogger<DrugCache> logDrugCache = Mock.Of<ILogger<DrugCache>>();
            qryParams = new()
            {
                { "locations", new string[] { "locations" } },
                { "status", new string[] { "Active" } },
                { "enablesecondcheck", new string[] { "false" } },
                { "requirelotcode", new string[] { "true" } },
                { "requireexpirydate", new string[] { "true" } },
                { "requireserialnumber", new string[] { "true" } },
                { "preferlocaldispense", new string[] { "true" } }
            };

            locations["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active };
            locations["locations"] = new FormularyLocationSettingsModelV2 {
                Formulary = true,
                Status = LocationSettingsStatus.Active,
                RequireExpiryDate = true,
                RequireLotCode = true,
                PreferLocalDispense = true,
                RequireSerialNumber = true,
                PreferredAccount = new PreferredAccountModelV2 { AccountId = "accountId", SupplierId = "supplierId" }
            };

            formularyDrugModelV2 = new FormularyDrugModelV2
            {
                DrugId = "formularyId",
                Name = "formulary name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                FormNormalized = new List<string> { "TABLET", "PILL" },
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0,
                LastModified = DateTime.UtcNow
            };
            manufacturedDrugModelV2 = new ManufacturedDrugModelV2
            {
                DrugId = "formularyId/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "formularyId",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI",
                LastModified = DateTime.UtcNow
            };
            packagedDrugModelV2 = new PackagedDrugModelV2
            {
                DrugId = "formularyId/123456789/Each",
                ManufacturedDrugId = "formularyId/123456789",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "987654321", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
                LastModified = DateTime.UtcNow
            };

            string corruptedData = "{   \"origin\": \"wm6\",   \"drugId\": \"someFormularyId/SomeManufacturer\",   \"identifiers\": [     {       \"type\": \"NDC\",       \"identifier\": \"2323r32\",       \"status\": \"APPROVED\"     }   ],   \"name\": \"Digoxin\",   \"manufacturerName\": Digoxin\",   \"manufacturerId\": \"SomeManufacturer\",   \"isBrand\": false,   \"color\": \"white\",   \"shape\": \"round\",   \"imprint1\": \"10\",   \"imprint2\": \"1\",   \"imageFile\": \"testimgf78034\",   \"status\": \"Active\",   \"created\": \"2022-05-19T20:12:13.2745879Z\",   \"lastModified\": \"2022-05-19T20:12:13.2745879Z\",   \"formularyDrugId\": \"someFormularyId\",   \"version\": 1 }";
            DrugEntity faultyEntityMData = new() { Id = Guid.NewGuid(), DrugId = "someFormularyId/SomeManufacturer", DrugInfo = corruptedData, IsDeleted = false, Version = 0, LastModificationDateUtc = DateTime.UtcNow };
            DrugEntity entityFData = new() { Id = Guid.NewGuid(), DrugId = "formularyId", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2), IsDeleted = false, Version = 0, LastModificationDateUtc = DateTime.UtcNow };
            DrugEntity entityMData = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789", DrugInfo = DrugUtility<string>.DrugToString(manufacturedDrugModelV2), IsDeleted = false, Version = 0, LastModificationDateUtc = DateTime.UtcNow };
            DrugEntity entityPData = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789/Each", DrugInfo = DrugUtility<string>.DrugToString(packagedDrugModelV2), IsDeleted = false, Version = 0, LastModificationDateUtc = DateTime.UtcNow };
            List<DrugEntity> drugList = new() { entityFData, entityMData, entityPData, faultyEntityMData };

            Mock<ISessionFactory> mockSessionFactory = new();
            Mock<ISession> mockSession = new();
            Mock<IQuery> queryMock = new();
            Mock<ITransaction> mockTransaction = new();
            Mock<IStatelessSession> mockStateSession = new();
            mockSessionFactory.Setup(x => x.OpenStatelessSession()).Returns(mockStateSession.Object);
            mockSession.Setup(x => x.BeginTransaction()).Returns(mockTransaction.Object);
            mockStateSession.Setup(x => x.BeginTransaction()).Returns(mockTransaction.Object);
            mockSession.Setup(x => x.Dispose());
            mockSessionFactory.Setup(x => x.Dispose());
            mockTransaction.Setup(x => x.Commit());
            mockTransaction.Setup(x => x.Dispose());
            mockStateSession.Setup(x => x.Dispose());

            mockTransaction.Setup(x => x.Commit()).Verifiable();
#pragma warning disable CS0618 // Type or member is obsolete
            mockSession.SetupGet(x => x.Transaction).Returns(mockTransaction.Object);
            mockStateSession.SetupGet(x => x.Transaction).Returns(mockTransaction.Object);
#pragma warning restore CS0618 // Type or member is obsolete
            mockSession.Setup(session => session.CreateQuery("from drugs")).Returns(queryMock.Object);
            mockSession.Setup(session => session.Query<DrugEntity>()).Returns(new TestingQueryable<DrugEntity>(drugList.AsQueryable()));
            mockStateSession.Setup(session => session.Query<DrugEntity>()).Returns(new TestingQueryable<DrugEntity>(drugList.AsQueryable()));
            queryMock.Setup(x => x.List<DrugEntity>()).Returns(drugList);

            OriginData.OriginAsChangeset = new List<string>() { "mfn" };
            OriginData.OriginsToUpdateWM6 = new List<string>() { "ui", "import" };
            OriginData.AllowedOriginTypes = new List<string>() { "ui", "import", "wm6", "mfn" };

            drugCache = new DrugCache(mockSessionFactory.Object, logDrugCache);
        }
        #endregion

        #region Method
        [TestMethod]
        public void GetDrugCacheDataEntityByLastUpdatedDateAsyncWithNULLTest()
        {
            //Act
            var result = drugCache?.GetDrugCacheDataEntityByLastUpdatedDateAsync(null);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result;
            List <DrugCacheDataEntity> orderedDCDE = drugCacheDataEntities.OrderBy(o => o.DrugEntityType).ToList();
            Assert.AreEqual(orderedDCDE.Count, 3);
            Assert.AreEqual(orderedDCDE[0].DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.FormNormalized?.Count, 2);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.FormNormalized?[0], formularyDrugModelV2?.FormNormalized?[0]);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.FormNormalized?[1], formularyDrugModelV2?.FormNormalized?[1]);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Route, formularyDrugModelV2?.Route);
            Assert.AreEqual(orderedDCDE[0]?.Children?.Count, 1);

            Assert.AreEqual(orderedDCDE[1].DrugEntityType, DrugType.Manufactured);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.DrugId, manufacturedDrugModelV2?.DrugId);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.Name, manufacturedDrugModelV2?.Name);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.ManufacturerName, manufacturedDrugModelV2?.ManufacturerName);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.FormularyDrugId, manufacturedDrugModelV2?.FormularyDrugId);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.Identifiers[0].Type, manufacturedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.Identifiers[0].Identifier, manufacturedDrugModelV2?.Identifiers[0].Identifier);
            Assert.AreEqual(orderedDCDE[1]?.Children?.Count, 1);

            Assert.AreEqual(orderedDCDE[2].DrugEntityType, DrugType.Packaged);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.DrugId, packagedDrugModelV2?.DrugId);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.Name, packagedDrugModelV2?.Name);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.PackageId, packagedDrugModelV2?.PackageId);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.PackageQty, packagedDrugModelV2?.PackageQty);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.Identifiers[0].Type, packagedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.Identifiers[0].Identifier, packagedDrugModelV2?.Identifiers[0].Identifier);
        }
        [TestMethod]
        public void GetDrugCacheDataEntityByLastUpdatedDateAsyncWithDTTest()
        {
            //Act
            var result = drugCache?.GetDrugCacheDataEntityByLastUpdatedDateAsync(DateTime.UtcNow.Date);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result;
            List<DrugCacheDataEntity> orderedDCDE = drugCacheDataEntities.OrderBy(o => o.DrugEntityType).ToList();
            Assert.AreEqual(orderedDCDE.Count, 3);
            Assert.AreEqual(orderedDCDE[0].DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.FormNormalized?.Count, 2);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.FormNormalized?[0], formularyDrugModelV2?.FormNormalized?[0]);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.FormNormalized?[1], formularyDrugModelV2?.FormNormalized?[1]);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Route, formularyDrugModelV2?.Route);
            Assert.AreEqual(orderedDCDE[0]?.Children?.Count, 1);            

            Assert.AreEqual(orderedDCDE[1].DrugEntityType, DrugType.Manufactured);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.DrugId, manufacturedDrugModelV2?.DrugId);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.Name, manufacturedDrugModelV2?.Name);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.ManufacturerName, manufacturedDrugModelV2?.ManufacturerName);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.FormularyDrugId, manufacturedDrugModelV2?.FormularyDrugId);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.Identifiers[0].Type, manufacturedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.Identifiers[0].Identifier, manufacturedDrugModelV2?.Identifiers[0].Identifier);
            Assert.AreEqual(orderedDCDE[1]?.Children?.Count, 1);

            Assert.AreEqual(orderedDCDE[2].DrugEntityType, DrugType.Packaged);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.DrugId, packagedDrugModelV2?.DrugId);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.Name, packagedDrugModelV2?.Name);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.PackageId, packagedDrugModelV2?.PackageId);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.PackageQty, packagedDrugModelV2?.PackageQty);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.Identifiers[0].Type, packagedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.Identifiers[0].Identifier, packagedDrugModelV2?.Identifiers[0].Identifier);
        }
        [TestMethod]
        public void GetDrugCacheDataEntityAsyncTest()
        {
            //Act
            var result = drugCache?.GetDrugCacheDataEntityAsync(formularyDrugModelV2?.DrugId!, false);
            //Assert
            Assert.IsNotNull(result);
            _ = result.Result;
        }
        [TestMethod]
        public void FindInCacheByLocationAsyncForSubscribeTRUETest()
        {
            List<string> locations = new()
            {
                "locations"
            };
            //Act
            var result = drugCache?.FindInCacheByLocationAsync(locations, qryParams!, false, true);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.OrderBy(x => x.DrugId).ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 1);

            Assert.AreEqual(drugCacheDataEntities[0].DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?.Count, 2);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[0], formularyDrugModelV2?.FormNormalized?[0]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[1], formularyDrugModelV2?.FormNormalized?[1]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Route, formularyDrugModelV2?.Route);
            Assert.AreEqual(drugCacheDataEntities[0]?.Children?.Count, 1);
        }
        [TestMethod]
        public void FindInCacheByLocationAsyncForSubscribeFALSETest()
        {
            List<string> locations = new()
            {
                "locations"
            };
            //Act
            var result = drugCache?.FindInCacheByLocationAsync(locations, qryParams!, false, false);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 0);
        }
        [TestMethod]
        public void FindInCacheByLocationAsyncForStatusANDSubscribeTRUETest()
        {
            List<string> locations = new()
            {
                "locations"
            };
            //Act
            var result = drugCache?.FindInCacheByLocationAsync(locations, qryParams!, true, true);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.OrderBy(x => x.DrugId).ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 1);
            Assert.AreEqual(drugCacheDataEntities[0].DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?.Count, 2);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[0], formularyDrugModelV2?.FormNormalized?[0]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[1], formularyDrugModelV2?.FormNormalized?[1]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Route, formularyDrugModelV2?.Route);
            Assert.AreEqual(drugCacheDataEntities[0]?.Children?.Count, 1);
        }
        [TestMethod]
        public void FindInCacheByLocationAsyncForStatusTRUETest()
        {
            List<string> locations = new()
            {
                "locations"
            };
            //Act
            var result = drugCache?.FindInCacheByLocationAsync(locations, qryParams!, true, false);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 0);
        }
        [TestMethod]
        public void FindInCacheByLocationAsyncForLocationNULLTest()
        {
            //Act
            var result = drugCache?.FindInCacheByLocationAsync(null!, qryParams!, true, false);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 0);
        }
        [TestMethod]
        public void FindInCacheByHazardousTypeAsyncTest()
        {
            List<string> hazardousTypes = new()
            {
                "GROUP_1"
            };
            //Act
            var result = drugCache?.FindInCacheByHazardousTypeAsync(hazardousTypes);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 1);
            Assert.AreEqual(drugCacheDataEntities[0].DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?.Count, 2);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[0], formularyDrugModelV2?.FormNormalized?[0]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[1], formularyDrugModelV2?.FormNormalized?[1]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Route, formularyDrugModelV2?.Route);
            Assert.AreEqual(drugCacheDataEntities[0]?.Children?.Count, 1);
        }
        [TestMethod]
        public void FindInCacheByHazardousTypeAsyncWithNULLTest()
        {
            //Act
            var result = drugCache?.FindInCacheByHazardousTypeAsync(null!);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 0);
        }
        [TestMethod]
        public void FindInCacheByFormsAsyncTest()
        {
            List<string> forms = new()
            {
                "TABLET"
            };
            //Act
            var result = drugCache?.FindInCacheByFormsAsync(forms);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 1);
            Assert.AreEqual(drugCacheDataEntities[0].DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?.Count, 2);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[0], formularyDrugModelV2?.FormNormalized?[0]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[1], formularyDrugModelV2?.FormNormalized?[1]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Route, formularyDrugModelV2?.Route);
            Assert.AreEqual(drugCacheDataEntities[0]?.Children?.Count, 1);
        }
        [TestMethod]
        public void FindInCacheByFormsAsyncWithNULLTest()
        {
            //Act
            var result = drugCache?.FindInCacheByFormsAsync(null!);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 0);
        }
        [TestMethod]
        public void FindInCacheByDrugIdsAsyncTest()
        {
            List<string> drugIds = new()
            {
                formularyDrugModelV2?.DrugId!
            };
            //Act
            var result = drugCache?.FindInCacheByDrugIdsAsync(drugIds);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 3);
            DrugCacheDataEntity formulary = new();

            if (drugCacheDataEntities[0].DrugEntityType == DrugType.Formulary)
            {
                formulary = drugCacheDataEntities[0];
            }
            else if (drugCacheDataEntities[1].DrugEntityType == DrugType.Formulary)
            {
                formulary = drugCacheDataEntities[1];
            }
            else
            {
                formulary = drugCacheDataEntities[2];
            }
            Assert.AreEqual(formulary.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(formulary.FormularyDrug?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(formulary.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(formulary.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(formulary.FormularyDrug?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(formulary.FormularyDrug?.FormNormalized?.Count, 2);
            Assert.AreEqual(formulary.FormularyDrug?.FormNormalized?[0], formularyDrugModelV2?.FormNormalized?[0]);
            Assert.AreEqual(formulary.FormularyDrug?.FormNormalized?[1], formularyDrugModelV2?.FormNormalized?[1]);
            Assert.AreEqual(formulary.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(formulary.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(formulary.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(formulary.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(formulary.FormularyDrug?.Route, formularyDrugModelV2?.Route);
            Assert.AreEqual(formulary.Children?.Count, 1);
        }
        [TestMethod]
        public void FindInCacheByDrugIdsAsyncWithNULL()
        {
            //Act
            var result = drugCache?.FindInCacheByDrugIdsAsync(null!);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 0);
        }
        [TestMethod]
        public void FindInDrugCacheAsyncTest()
        {
            Dictionary<DrugSearchParams, string>? searchParams = new();
            _ = Enum.TryParse("name", out DrugSearchParams searchParam);
            searchParams.TryAdd(searchParam, "formulary name");
            Specification<DrugCacheDataEntity>? paramExpr = new DrugCacheQrySpec(searchParams);
            //Act
            var result = drugCache?.FindInDrugCacheAsync(paramExpr);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 1);
            Assert.AreEqual(drugCacheDataEntities[0].DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?.Count, 2);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[0], formularyDrugModelV2?.FormNormalized?[0]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.FormNormalized?[1], formularyDrugModelV2?.FormNormalized?[1]);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Route, formularyDrugModelV2?.Route);
            Assert.AreEqual(drugCacheDataEntities[0]?.Children?.Count, 1);
        }
        [TestMethod]
        public void FindInDrugCacheAsyncWithNULLTest()
        {
            //Act
            var result = drugCache?.FindInDrugCacheAsync(null!);
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            List<DrugCacheDataEntity> orderedDCDE = drugCacheDataEntities.OrderBy(o => o.DrugEntityType).ToList();
            Assert.AreEqual(orderedDCDE.Count, 3);
            if (orderedDCDE[0]?.FormularyDrug?.DrugId == formularyDrugModelV2?.DrugId)
            {
                Assert.AreEqual(orderedDCDE[0].DrugEntityType, DrugType.Formulary);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Name, formularyDrugModelV2?.Name);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Form, formularyDrugModelV2?.Form);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.FormNormalized?.Count, 2);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.FormNormalized?[0], formularyDrugModelV2?.FormNormalized?[0]);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.FormNormalized?[1], formularyDrugModelV2?.FormNormalized?[1]);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
                Assert.AreEqual(orderedDCDE[0]?.FormularyDrug?.Route, formularyDrugModelV2?.Route);
                Assert.AreEqual(orderedDCDE[0]?.Children?.Count, 1);
            }
            if(orderedDCDE[1]?.ManufacturedDrug?.DrugId == manufacturedDrugModelV2?.DrugId)
            {
                Assert.AreEqual(orderedDCDE[1].DrugEntityType, DrugType.Manufactured);
                Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.DrugId, manufacturedDrugModelV2?.DrugId);
                Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.Name, manufacturedDrugModelV2?.Name);
                Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.ManufacturerName, manufacturedDrugModelV2?.ManufacturerName);
                Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.FormularyDrugId, manufacturedDrugModelV2?.FormularyDrugId);
                Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.Identifiers[0].Type, manufacturedDrugModelV2?.Identifiers[0].Type);
                Assert.AreEqual(orderedDCDE[1]?.ManufacturedDrug?.Identifiers[0].Identifier, manufacturedDrugModelV2?.Identifiers[0].Identifier);
                Assert.AreEqual(orderedDCDE[1]?.Children?.Count, 1);
            }
            if (orderedDCDE[2]?.PackagedDrug?.DrugId == packagedDrugModelV2?.DrugId)
            {
                Assert.AreEqual(orderedDCDE[2].DrugEntityType, DrugType.Packaged);
                Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.DrugId, packagedDrugModelV2?.DrugId);
                Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.Name, packagedDrugModelV2?.Name);
                Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.PackageId, packagedDrugModelV2?.PackageId);
                Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.PackageQty, packagedDrugModelV2?.PackageQty);
                Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.Identifiers[0].Type, packagedDrugModelV2?.Identifiers[0].Type);
                Assert.AreEqual(orderedDCDE[2]?.PackagedDrug?.Identifiers[0].Identifier, packagedDrugModelV2?.Identifiers[0].Identifier);
            }

            
        }
        [TestMethod]
        public void FormularyAddOrUpdateCacheAsyncTest()
        {
            FormularyDrugModelV2 formularyDrugModelV22 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_2" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };

            DrugCacheDataEntity drugCacheDataEntity2 = new(formularyDrugModelV22)
            {
                DrugId = "drug",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_2" },
            };
            //Act
            var result = drugCache?.AddOrUpdateCacheAsync(drugCacheDataEntity2);
            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsCompleted);
        }
        [TestMethod]
        public void ManufacturerAddOrUpdateCacheAsyncTest()
        {
            ManufacturedDrugModelV2 manufacturedDrugModelV22 = new()
            {
                DrugId = "drug/1234567891",
                ManufacturerId = "1234567891",
                ManufacturerName = "ManufacturerName1",
                Name = "BrandName",
                FormularyDrugId = "drug",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "1234567891"
                    }
                },
                Version = 0,
                Origin = "UI",
                LastModified = DateTime.UtcNow
            };

            DrugCacheDataEntity drugCacheDataEntity2 = new(manufacturedDrugModelV22)
            {
                DrugId = "drug",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Manufactured,
                HasDrugInfo = true,
                Id = "drug/1234567891",
                IsActive = true,
                Origin = "UI"
            };
            //Act
            var result = drugCache?.AddOrUpdateCacheAsync(drugCacheDataEntity2);
            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsCompleted);
        }
        [TestMethod]
        public void FormularyUpdateInAddOrUpdateCacheAsyncTest()
        {
            FormularyDrugModelV2 formularyDrugModelV22 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "100",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_2" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };

            DrugCacheDataEntity drugCacheDataEntity2 = new(formularyDrugModelV22)
            {
                DrugId = "drug",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_2" },
            };
            //Act
            var result = drugCache?.AddOrUpdateCacheAsync(drugCacheDataEntity2);
            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsCompleted);
        }
        [TestMethod]
        public void FormularyUpdateInRemoveFromCacheAsyncTest()
        {
            FormularyDrugModelV2 formularyDrugModelV22 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "100",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_2" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };

            DrugCacheDataEntity drugCacheDataEntity2 = new(formularyDrugModelV22)
            {
                DrugId = "drug",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_2" },
            };
            //Act
            var result = drugCache?.RemoveFromCacheAsync(drugCacheDataEntity2);
            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsCompleted);
        }
        [TestMethod]
        public void CheckFormularyOfLocationSettingsTest()
        {
            List<string> listOfLocations = new()
            {
                "locations"
            };
            //Act
            bool? result = drugCache?.CheckFormularyOfLocationSettings(listOfLocations, locations, true);
            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result);
        }
        [TestMethod]
        public void FindInPreferredSettingsAsyncTest()
        {
            List<string> listOfLocations = new()
            {
                "locations"
            };
            //Act
            var result = drugCache?.FindInPreferredSettingsAsync("accountId", "supplierId");
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.Result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 1);
            Assert.AreEqual(drugCacheDataEntities[0].DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(drugCacheDataEntities[0]?.FormularyDrug?.Route, formularyDrugModelV2?.Route);
            Assert.AreEqual(drugCacheDataEntities[0]?.Children?.Count, 1);
        }
        [TestMethod]
        public void FindInCacheIdentifierTest()
        {            
            //Act
            var result = drugCache?.FindInCacheIdentifier("");
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 3);
            //FORMULARY
            FormularyDrugModelV2? localFormularyDrugModelV2 = drugCacheDataEntities.Where(x => x.FormularyDrug != null).Select(x => x).FirstOrDefault()?.FormularyDrug;
            Assert.IsNotNull(localFormularyDrugModelV2);
            Assert.AreEqual(localFormularyDrugModelV2.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(localFormularyDrugModelV2?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(localFormularyDrugModelV2?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(localFormularyDrugModelV2?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(localFormularyDrugModelV2?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(localFormularyDrugModelV2?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(localFormularyDrugModelV2?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(localFormularyDrugModelV2?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(localFormularyDrugModelV2?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(localFormularyDrugModelV2?.Route, formularyDrugModelV2?.Route);

            //MANUFACTURER
            ManufacturedDrugModelV2? localManufacturedDrugModelV2 = drugCacheDataEntities.Where(x => x.ManufacturedDrug != null).Select(x => x).FirstOrDefault()?.ManufacturedDrug;
            Assert.IsNotNull(localManufacturedDrugModelV2);
            Assert.AreEqual(localManufacturedDrugModelV2.DrugId, manufacturedDrugModelV2?.DrugId);
            Assert.AreEqual(localManufacturedDrugModelV2?.Name, manufacturedDrugModelV2?.Name);
            Assert.AreEqual(localManufacturedDrugModelV2?.ManufacturerName, manufacturedDrugModelV2?.ManufacturerName);
            Assert.AreEqual(localManufacturedDrugModelV2?.FormularyDrugId, manufacturedDrugModelV2?.FormularyDrugId);
            Assert.AreEqual(localManufacturedDrugModelV2?.Identifiers[0].Type, manufacturedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(localManufacturedDrugModelV2?.Identifiers[0].Identifier, manufacturedDrugModelV2?.Identifiers[0].Identifier);
            
            

            //PACKAGED
            PackagedDrugModelV2? localPackagedDrugModelV2 = drugCacheDataEntities.Where(x => x.PackagedDrug != null).Select(x => x).FirstOrDefault()?.PackagedDrug;
            Assert.IsNotNull(localPackagedDrugModelV2);
            Assert.AreEqual(localPackagedDrugModelV2?.DrugId, packagedDrugModelV2?.DrugId);
            Assert.AreEqual(localPackagedDrugModelV2?.Name, packagedDrugModelV2?.Name);
            Assert.AreEqual(localPackagedDrugModelV2?.PackageId, packagedDrugModelV2?.PackageId);
            Assert.AreEqual(localPackagedDrugModelV2?.PackageQty, packagedDrugModelV2?.PackageQty);
            Assert.AreEqual(localPackagedDrugModelV2?.Identifiers[0].Type, packagedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(localPackagedDrugModelV2?.Identifiers[0].Identifier, packagedDrugModelV2?.Identifiers[0].Identifier);
        }
        [TestMethod]
        public void FindInCacheIdentifierWithItemIdTest()
        {
            //Act
            var result = drugCache?.FindInCacheIdentifier("formularyId");
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 2);            

            //MANUFACTURER
            ManufacturedDrugModelV2? localManufacturedDrugModelV2 = drugCacheDataEntities.Where(x => x.ManufacturedDrug != null).Select(x => x).FirstOrDefault()?.ManufacturedDrug;
            Assert.IsNotNull(localManufacturedDrugModelV2);
            Assert.AreEqual(localManufacturedDrugModelV2.DrugId, manufacturedDrugModelV2?.DrugId);
            Assert.AreEqual(localManufacturedDrugModelV2?.Name, manufacturedDrugModelV2?.Name);
            Assert.AreEqual(localManufacturedDrugModelV2?.ManufacturerName, manufacturedDrugModelV2?.ManufacturerName);
            Assert.AreEqual(localManufacturedDrugModelV2?.FormularyDrugId, manufacturedDrugModelV2?.FormularyDrugId);
            Assert.AreEqual(localManufacturedDrugModelV2?.Identifiers[0].Type, manufacturedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(localManufacturedDrugModelV2?.Identifiers[0].Identifier, manufacturedDrugModelV2?.Identifiers[0].Identifier);

            //PACKAGED
            PackagedDrugModelV2? localPackagedDrugModelV2 = drugCacheDataEntities.Where(x => x.PackagedDrug != null).Select(x => x).FirstOrDefault()?.PackagedDrug;
            Assert.IsNotNull(localPackagedDrugModelV2);
            Assert.AreEqual(localPackagedDrugModelV2?.DrugId, packagedDrugModelV2?.DrugId);
            Assert.AreEqual(localPackagedDrugModelV2?.Name, packagedDrugModelV2?.Name);
            Assert.AreEqual(localPackagedDrugModelV2?.PackageId, packagedDrugModelV2?.PackageId);
            Assert.AreEqual(localPackagedDrugModelV2?.PackageQty, packagedDrugModelV2?.PackageQty);
            Assert.AreEqual(localPackagedDrugModelV2?.Identifiers[0].Type, packagedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(localPackagedDrugModelV2?.Identifiers[0].Identifier, packagedDrugModelV2?.Identifiers[0].Identifier);
        }
        [TestMethod]
        public void FindInCacheIdentifierAsyncTest()
        {
            //Act
            var result = drugCache?.FindInCacheIdentifierAsync("").Result;
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 3);
            //FORMULARY
            FormularyDrugModelV2? localFormularyDrugModelV2 = drugCacheDataEntities.Where(x => x.FormularyDrug != null).Select(x => x).FirstOrDefault()?.FormularyDrug;
            Assert.IsNotNull(localFormularyDrugModelV2);
            Assert.AreEqual(localFormularyDrugModelV2.DrugId, formularyDrugModelV2?.DrugId);
            Assert.AreEqual(localFormularyDrugModelV2?.Name, formularyDrugModelV2?.Name);
            Assert.AreEqual(localFormularyDrugModelV2?.Strength, formularyDrugModelV2?.Strength);
            Assert.AreEqual(localFormularyDrugModelV2?.Volume, formularyDrugModelV2?.Volume);
            Assert.AreEqual(localFormularyDrugModelV2?.Form, formularyDrugModelV2?.Form);
            Assert.AreEqual(localFormularyDrugModelV2?.TemperatureClass, formularyDrugModelV2?.TemperatureClass);
            Assert.AreEqual(localFormularyDrugModelV2?.ControlSchedule, formularyDrugModelV2?.ControlSchedule);
            Assert.AreEqual(localFormularyDrugModelV2?.ControlSubstance, formularyDrugModelV2?.ControlSubstance);
            Assert.AreEqual(localFormularyDrugModelV2?.BasePackaged, formularyDrugModelV2?.BasePackaged);
            Assert.AreEqual(localFormularyDrugModelV2?.Route, formularyDrugModelV2?.Route);

            //MANUFACTURER
            ManufacturedDrugModelV2? localManufacturedDrugModelV2 = drugCacheDataEntities.Where(x => x.ManufacturedDrug != null).Select(x => x).FirstOrDefault()?.ManufacturedDrug;
            Assert.IsNotNull(localManufacturedDrugModelV2);
            Assert.AreEqual(localManufacturedDrugModelV2.DrugId, manufacturedDrugModelV2?.DrugId);
            Assert.AreEqual(localManufacturedDrugModelV2?.Name, manufacturedDrugModelV2?.Name);
            Assert.AreEqual(localManufacturedDrugModelV2?.ManufacturerName, manufacturedDrugModelV2?.ManufacturerName);
            Assert.AreEqual(localManufacturedDrugModelV2?.FormularyDrugId, manufacturedDrugModelV2?.FormularyDrugId);
            Assert.AreEqual(localManufacturedDrugModelV2?.Identifiers[0].Type, manufacturedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(localManufacturedDrugModelV2?.Identifiers[0].Identifier, manufacturedDrugModelV2?.Identifiers[0].Identifier);

            //PACKAGED
            PackagedDrugModelV2? localPackagedDrugModelV2 = drugCacheDataEntities.Where(x => x.PackagedDrug != null).Select(x => x).FirstOrDefault()?.PackagedDrug;
            Assert.IsNotNull(localPackagedDrugModelV2);
            Assert.AreEqual(localPackagedDrugModelV2?.DrugId, packagedDrugModelV2?.DrugId);
            Assert.AreEqual(localPackagedDrugModelV2?.Name, packagedDrugModelV2?.Name);
            Assert.AreEqual(localPackagedDrugModelV2?.PackageId, packagedDrugModelV2?.PackageId);
            Assert.AreEqual(localPackagedDrugModelV2?.PackageQty, packagedDrugModelV2?.PackageQty);
            Assert.AreEqual(localPackagedDrugModelV2?.Identifiers[0].Type, packagedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(localPackagedDrugModelV2?.Identifiers[0].Identifier, packagedDrugModelV2?.Identifiers[0].Identifier);
        }
        [TestMethod]
        public void FindInCacheIdentifierAsyncWithItemIdTest()
        {
            //Act
            var result = drugCache?.FindInCacheIdentifierAsync("formularyId").Result;
            //Assert
            Assert.IsNotNull(result);
            List<DrugCacheDataEntity> drugCacheDataEntities = result.ToList();
            Assert.AreEqual(drugCacheDataEntities.Count, 2);

            //MANUFACTURER
            ManufacturedDrugModelV2? localManufacturedDrugModelV2 = drugCacheDataEntities.Where(x => x.ManufacturedDrug != null).Select(x => x).FirstOrDefault()?.ManufacturedDrug;
            Assert.IsNotNull(localManufacturedDrugModelV2);
            Assert.AreEqual(localManufacturedDrugModelV2.DrugId, manufacturedDrugModelV2?.DrugId);
            Assert.AreEqual(localManufacturedDrugModelV2?.Name, manufacturedDrugModelV2?.Name);
            Assert.AreEqual(localManufacturedDrugModelV2?.ManufacturerName, manufacturedDrugModelV2?.ManufacturerName);
            Assert.AreEqual(localManufacturedDrugModelV2?.FormularyDrugId, manufacturedDrugModelV2?.FormularyDrugId);
            Assert.AreEqual(localManufacturedDrugModelV2?.Identifiers[0].Type, manufacturedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(localManufacturedDrugModelV2?.Identifiers[0].Identifier, manufacturedDrugModelV2?.Identifiers[0].Identifier);

            //PACKAGED
            PackagedDrugModelV2? localPackagedDrugModelV2 = drugCacheDataEntities.Where(x => x.PackagedDrug != null).Select(x => x).FirstOrDefault()?.PackagedDrug;
            Assert.IsNotNull(localPackagedDrugModelV2);
            Assert.AreEqual(localPackagedDrugModelV2?.DrugId, packagedDrugModelV2?.DrugId);
            Assert.AreEqual(localPackagedDrugModelV2?.Name, packagedDrugModelV2?.Name);
            Assert.AreEqual(localPackagedDrugModelV2?.PackageId, packagedDrugModelV2?.PackageId);
            Assert.AreEqual(localPackagedDrugModelV2?.PackageQty, packagedDrugModelV2?.PackageQty);
            Assert.AreEqual(localPackagedDrugModelV2?.Identifiers[0].Type, packagedDrugModelV2?.Identifiers[0].Type);
            Assert.AreEqual(localPackagedDrugModelV2?.Identifiers[0].Identifier, packagedDrugModelV2?.Identifiers[0].Identifier);
        }

        [TestMethod]
        public void LoadCacheWithFaultyRecords()
        {
            Assert.IsFalse(drugCache?.IsValid);
        }
        #endregion

        #region CleanUp
        [TestCleanup]
        public void TestCleanUp()
        {
            drugCache = null;
        }
        #endregion
    }
}
