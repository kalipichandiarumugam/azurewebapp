﻿using AutoMapper;
using Drug;
using Drug.Data;
using Drug.Models;
using Drug.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NHibernate;
using Swisslog.Drug.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

namespace DrugTest.Service
{
    [TestClass]
    public class DrugQueryProcessorTest
    {
        DrugQueryProcessor? drugQueryProcessor;
        DrugIdentifierQueryProcessor? drugIdentifierQueryProcessor;
        Dictionary<string, string[]>? qryParams;
        FormularyDrugModelV2? formularyDrugModelV2;
        ManufacturedDrugModelV2? manufacturedDrugModelV2;
        PackagedDrugModelV2? packagedDrugModelV2;
        Mock<DrugCache>? mockCache;
        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            //Arrange
            ILogger<DrugQueryProcessor> logDrugQueryProcessor = Mock.Of<ILogger<DrugQueryProcessor>>();
            ILogger<DrugIdentifierQueryProcessor> logDrugIdentifierQueryProcessor = Mock.Of<ILogger<DrugIdentifierQueryProcessor>>();
            ILogger<DrugService> logDrugService = Mock.Of<ILogger<DrugService>>();
            ILogger<DrugCommand> logDrugCommand = Mock.Of<ILogger<DrugCommand>>();
            ILogger<ProducerService> logProducerService = Mock.Of<ILogger<ProducerService>>();
            ILogger<DrugSyncServiceAdapter> logDrugSyncServiceAdapter = Mock.Of<ILogger<DrugSyncServiceAdapter>>();
            ILogger<DataChangedService> logDataChangedService = Mock.Of<ILogger<DataChangedService>>();
            ILogger<DrugValidator> logDrugValidator = Mock.Of<ILogger<DrugValidator>>();
            HttpClient client = Mock.Of<HttpClient>();
            IMapper mapper = Mock.Of<IMapper>();
            IWebHostEnvironment _env = Mock.Of<IWebHostEnvironment>();
            Mock<IConfiguration> mockConfig = new();
            Mock<IConfigurationSection> mockConfigurationSection = new();
            mockConfig.Setup(a => a.GetSection("kafka:producer")).Returns(mockConfigurationSection.Object);
            ILogger<HazardousTypeQueryProcessor> logHazardousTypeQueryProcessor = Mock.Of<ILogger<HazardousTypeQueryProcessor>>();
            Mock<LocationRestClient> mockLocationRestClient = new(client, mockConfig.Object);
            HttpResponseMessage httpResponseMessageForLocation = new()
            {
                StatusCode = System.Net.HttpStatusCode.OK,
                Content = new StringContent(Controller.TestData.locationContent, System.Text.Encoding.UTF8, "application/json")
            };

            mockLocationRestClient.Setup(x => x.GetLocations().Result).Returns(httpResponseMessageForLocation);
            Mock<LocationService> mockLocationService = new(new Mock<ILogger<LocationService>>().Object,
                mockLocationRestClient.Object);
            mockCache = new(new Mock<ISessionFactory>().Object, new Mock<ILogger<DrugCache>>().Object);
            mockCache.Setup(x => x.LoadDrugCache()).Verifiable();
            Mock<DrugQueryProcessor> mockDrugQueryProcessor = new(mockCache.Object, logDrugQueryProcessor, mockLocationService.Object);
            Mock<HazardousTypeQueryProcessor> mockHazardousTypeQueryProcessor = new(mockCache.Object, logHazardousTypeQueryProcessor);
            Mock<DrugIdentifierQueryProcessor> mockDrugIdentifierQueryProcessor = new(mockCache.Object, logDrugIdentifierQueryProcessor);
            qryParams = new()
            {
                { "locations", new string[] { "locations" } },
                { "name", new string[] { "drug1 name" } },
                { "status", new string[] { "active" } },
                { "drugids", new string[] { "drug1" } },
                { "hazardoustypes", new string[] { "GROUP_1" } },
                { "form", new string[] { "TABLET" } },
                { "formulary", new string[] { "true" } },
                { "sortby", new string[] { "name" } },
                { "sortorder", new string[] { "asc" } }
            };
            //formulary

            Dictionary<string, FormularyLocationSettingsModelV2> locations = new()
            {
                ["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active },
                ["locations"] = new FormularyLocationSettingsModelV2
                {
                    Formulary = true,
                    Status = LocationSettingsStatus.Active,
                    PreferredAccount = new PreferredAccountModelV2 { AccountId = "acc1", SupplierId = "sup1" }
                }
            };
            FormularyDrugQryModelV2 formularyDrugQryModelV2 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Locations = locations
            };
            List<FormularyDrugQryModelV2> formularyDrugQryModelV2s1 = new()
            {
                formularyDrugQryModelV2,
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
                null //add explicitly null to prove every handle async does not fail null checks anymore
            };
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            IEnumerable<FormularyDrugQryModelV2> formularyDrugQryModelV2s = formularyDrugQryModelV2s1.AsEnumerable();
            PagingInfo? pageInfo = new(0, 20);
            Swisslog.Base.Api.Page<FormularyDrugQryModelV2> pageData = DrugPage<FormularyDrugQryModelV2>.ApplyPaging(formularyDrugQryModelV2s, pageInfo);

            Mock<DrugService> mockService = new(mockDrugQueryProcessor.Object, mockHazardousTypeQueryProcessor.Object, mockDrugIdentifierQueryProcessor.Object, logDrugService, mockLocationService.Object);
            List<string> drugIds = new()
            {
                "drug"
            };
            mockService.Setup(x => x.QueryDrugIds(qryParams).Result).Returns(drugIds);
            mockService.Setup(x => x.QueryDrugs(qryParams).Result).Returns(pageData);

            Mock<ILogger<DrugSyncRestClient>> mockDrugServiceLogger = new();
            Mock<DrugSyncRestClient> mockDrugSyncRestClient = new(client, mockConfig.Object, mockDrugServiceLogger.Object);
            ISessionFactory sessionFactory = Mock.Of<ISessionFactory>();
            IHttpContextAccessor httpContextAccessor = Mock.Of<IHttpContextAccessor>();
            formularyDrugModelV2 = new FormularyDrugModelV2
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };
            FormularyDrugModelV2 formularyDrugModel2 = new()
            {
                DrugId = "drug1",
                Name = "drug1 name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };
            manufacturedDrugModelV2 = new ManufacturedDrugModelV2
            {
                DrugId = "formularyId/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "formularyId",
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            packagedDrugModelV2 = new PackagedDrugModelV2
            {
                DrugId = "formularyId/123456789/Each",
                ManufacturedDrugId = "formularyId/123456789",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "BARCODE", Identifier = "987654321", Status = Swisslog.Base.Api.IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            ManufacturedDrugModelV2 manufacturedDrugModel1 = new()
            {
                DrugId = "drug1/NDC1",
                ManufacturerId = "NDC1",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug1",
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "NDC", Identifier = "NDC1"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            PackagedDrugModelV2 packagedDrugModel1 = new()
            {
                DrugId = "drug1/NDC1/Each",
                ManufacturedDrugId = "drug1/NDC1",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "BARCODE", Identifier = "BARCODE", Status = Swisslog.Base.Api.IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            PackagedDrugModelV2 packagedDrugModelV22 = new()
            {
                DrugId = "formularyId/123456789/Pack",
                ManufacturedDrugId = "formularyId/123456789",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 10,
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "BARCODE", Identifier = "Pack987654321", Status = Swisslog.Base.Api.IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            DrugEntity entityFData = new() { Id = Guid.NewGuid(), DrugId = "drug", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityMData = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789", DrugInfo = DrugUtility<string>.DrugToString(manufacturedDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityPData = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789/Each", DrugInfo = DrugUtility<string>.DrugToString(packagedDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityP2Data = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789/Pack", DrugInfo = DrugUtility<string>.DrugToString(packagedDrugModelV22), IsDeleted = false, Version = 0 };
            DrugEntity entityF2Data = new() { Id = Guid.NewGuid(), DrugId = "drug1", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityM2Data = new() { Id = Guid.NewGuid(), DrugId = "drug1/NDC1", DrugInfo = DrugUtility<string>.DrugToString(manufacturedDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityF3Data = new() { Id = Guid.NewGuid(), DrugId = "drug2", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityM3Data = new() { Id = Guid.NewGuid(), DrugId = "drug2/NDC2", DrugInfo = DrugUtility<string>.DrugToString(manufacturedDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityP3Data = new() { Id = Guid.NewGuid(), DrugId = "drug2/NDC2/BARCODE", DrugInfo = DrugUtility<string>.DrugToString(packagedDrugModelV2), IsDeleted = false, Version = 0 };
            List<DrugEntity> drugList = new() { entityFData, entityMData, entityPData, entityP2Data, entityF2Data, entityM2Data, entityF3Data, entityM3Data, entityP3Data };

            DrugCacheDataEntity drugCacheDataEntity = new(formularyDrugModelV2, "")
            {
                DrugId = "drug",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
            };


            DrugCacheDataEntity drugCacheDataEntity1 = new(formularyDrugModel2, "")
            {
                DrugId = "drug1",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug1",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
            };

            DrugCacheDataEntity drugCacheDataEntityForPackage1 = new(packagedDrugModel1, "")
            {
                DrugId = "drug1/NDC1/BARCODE",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Packaged,
                HasDrugInfo = true,
                Id = "drug1/NDC1/BARCODE",
                IsActive = true,
                Origin = "UI"
            };

            DrugCacheDataEntity drugCacheDataEntityForManufacturer1 = new(manufacturedDrugModel1, "")
            {
                DrugId = "drug1/NDC1",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Manufactured,
                HasDrugInfo = true,
                Id = "drug1/NDC1",
                IsActive = true,
                Origin = "UI",
                Parent = drugCacheDataEntity1,
                Children = new List<DrugCacheDataEntity> { drugCacheDataEntityForPackage1 },
            };

            drugCacheDataEntity1.Children = new List<DrugCacheDataEntity> { drugCacheDataEntityForManufacturer1 };
            drugCacheDataEntityForPackage1.Parent = drugCacheDataEntityForManufacturer1;


            DrugCacheDataEntity drugCacheDataEntityForPackage2 = new()
            {
                DrugId = "drug2/NDC2/BARCODE",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Packaged,
                HasDrugInfo = true,
                Id = "drug2/NDC2/BARCODE",
                IsActive = true,
                Origin = "UI",
                Parent= drugCacheDataEntity,
            };

            DrugCacheDataEntity drugCacheDataEntityForManufacturer2 = new()
            {
                DrugId = "drug2/NDC2",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Manufactured,
                HasDrugInfo = true,
                Id = "drug2/NDC2",
                IsActive = true,
                Origin = "UI",
                Children = new List<DrugCacheDataEntity>() { drugCacheDataEntityForPackage2 }
            };

            DrugCacheDataEntity drugCacheDataEntity2 = new()
            {
                DrugId = "drug2",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug2",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                Children = new List<DrugCacheDataEntity>() { drugCacheDataEntityForManufacturer2 },
            };


            Mock<NHibernate.ISession> mockSession = new();
            Mock<IQuery> queryMock = new();
            Mock<ITransaction> mockTransaction = new();
            mockSession.Setup(x => x.BeginTransaction()).Returns(mockTransaction.Object);
            mockSession.Setup(x => x.Dispose());
            mockTransaction.Setup(x => x.Commit());
            mockTransaction.Setup(x => x.Dispose());

            mockTransaction.Setup(x => x.Commit()).Verifiable();
#pragma warning disable CS0618 // Type or member is obsolete
            mockSession.SetupGet(x => x.Transaction).Returns(mockTransaction.Object);
#pragma warning restore CS0618 // Type or member is obsolete
            mockSession.Setup(session => session.CreateQuery("from drugs")).Returns(queryMock.Object);
            //mockSession.Setup(x => x.SaveOrUpdateAsync(It.IsAny<DrugEntity>())).Returns(new object()); ;
            mockSession.Setup(session => session.Query<DrugEntity>()).Returns(new TestingQueryable<DrugEntity>(drugList.AsQueryable()));
            queryMock.Setup(x => x.List<DrugEntity>()).Returns(drugList);

            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug", false).Result).Returns(drugCacheDataEntity);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1", false).Result).Returns(drugCacheDataEntity1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2", false).Result).Returns(drugCacheDataEntity2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1/NDC1", false).Result).Returns(drugCacheDataEntityForManufacturer1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1/NDC1/Each", false).Result).Returns(drugCacheDataEntityForPackage1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2/NDC2/BARCODE", false).Result).Returns(drugCacheDataEntityForPackage2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1/ndc1", false).Result).Returns(drugCacheDataEntityForManufacturer1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2/ndc2/barcode", false).Result).Returns(drugCacheDataEntityForPackage2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1/ndc1/each", false).Result).Returns(drugCacheDataEntityForPackage1);
            List<DrugCacheDataEntity> drugCacheDataEntities = new() { drugCacheDataEntity1 };
            List<DrugCacheDataEntity> drugCacheDataEntities2 = new() { drugCacheDataEntityForManufacturer1, drugCacheDataEntityForPackage1 };
            mockCache.Setup(x => x.FindInCacheByLocationAsync(It.IsAny<List<string>>(), It.IsAny<Dictionary<string, string[]>>(), false, It.IsAny<bool>()).Result).Returns(drugCacheDataEntities.AsEnumerable());
            mockCache.Setup(x => x.FindInDrugCacheAsync(It.IsAny<Specification<DrugCacheDataEntity>>()).Result).Returns(drugCacheDataEntities);
            mockCache.Setup(x => x.FindInCacheByDrugIdsAsync(It.IsAny<List<string>>()).Result).Returns(drugCacheDataEntities);
            mockCache.Setup(x => x.FindInCacheByHazardousTypeAsync(It.IsAny<List<string>>()).Result).Returns(drugCacheDataEntities);
            mockCache.Setup(x => x.FindInCacheByFormsAsync(It.IsAny<List<string>>()).Result).Returns(drugCacheDataEntities);
            mockCache.Setup(x => x.CheckStatusOfLocationSettings(It.IsAny<List<string>>(), It.IsAny<Dictionary<string, FormularyLocationSettingsModelV2>>(), It.IsAny<string>())).Returns(true);
            mockCache.Setup(x => x.CheckFormularyOfLocationSettings(It.IsAny<List<string>>(), It.IsAny<Dictionary<string, FormularyLocationSettingsModelV2>>(), It.IsAny<bool>())).Returns(true);
            mockCache.Setup(x => x.GetMatchedLocationsByParams(It.IsAny<Dictionary<string, FormularyLocationSettingsModelV2>>(), It.IsAny<Dictionary<string, string[]>>())).Returns(locations);
            mockCache.Setup(x => x.FindInPreferredSettingsAsync("acc1", "sup1").Result).Returns(drugCacheDataEntities);
            mockCache.Setup(x => x.FindInCacheIdentifierAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntities2);
            //
            OriginData.OriginAsChangeset = new List<string>() { "mfn" };
            OriginData.OriginsToUpdateWM6 = new List<string>() { "ui", "import" };
            OriginData.AllowedOriginTypes = new List<string>() { "ui", "import", "wm6", "mfn" };

            Mock<DrugSyncServiceAdapter> mockSyncServiceAdapter = new(mockDrugQueryProcessor.Object,
                logDrugSyncServiceAdapter, mockDrugSyncRestClient.Object, sessionFactory, mockCache.Object);
            mockSyncServiceAdapter.Setup(x => x.PushFormularyDrug(It.IsAny<string>(), It.IsAny<DateTime>()).Result).Returns(true);
            mockSyncServiceAdapter.Setup(x => x.PushDrugsToWM6Async().Result).Returns(new List<string>() { "drug" });
            ProducerService mockProducerService = new(mockConfig.Object, logProducerService);
            Mock<DataChangedService> mockDataChangedService = new(logDataChangedService, mockProducerService, mockConfig.Object);
            drugQueryProcessor = new(mockCache.Object, logDrugQueryProcessor, mockLocationService.Object);
            drugIdentifierQueryProcessor = new(mockCache.Object, logDrugIdentifierQueryProcessor);

        }
        #endregion

        #region Methods
        [TestMethod]
        public void HandleAsyncFormularyTest()
        {
            //Act
            FormularyDrugQryModelV2? formularyDrug = drugQueryProcessor?.HandleAsync("drug1").Result;
            //Assert
            Assert.IsNotNull(formularyDrug);
            Assert.AreEqual(formularyDrug.DrugId, "drug1");
            Assert.AreEqual(formularyDrug.Name, "drug1 name");
            Assert.AreEqual(formularyDrug.Strength, "10");
            Assert.AreEqual(formularyDrug.Volume, "mg");
            Assert.AreEqual(formularyDrug.Form, "TABLET");
            Assert.AreEqual(formularyDrug.TemperatureClass, TemperatureClass.COLD);
            Assert.AreEqual(formularyDrug.ScanValidation, false);
            Assert.AreEqual(formularyDrug.ControlSchedule, false);
            Assert.AreEqual(formularyDrug.ControlSubstance, false);
            Assert.AreEqual(formularyDrug.PackAlone, true);
            Assert.AreEqual(formularyDrug.BasePackaged, DrugBaseUnitOfMeasurement.EACH);
            Assert.AreEqual(formularyDrug.Route, "Oral");
            Assert.AreEqual(formularyDrug.HazardousTypes?[0], "GROUP_1");
            Assert.AreEqual(formularyDrug.Locations.Count, 2);
            Assert.AreEqual(formularyDrug.Locations["root"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["root"].Status, LocationSettingsStatus.Active);
            Assert.AreEqual(formularyDrug.Locations["locations"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["locations"].Status, LocationSettingsStatus.Active);

            ManufacturedDrugQryModelV2? manufacturerDrug = formularyDrug?.ManufacturedDrugs?[0];
            Assert.AreEqual(manufacturerDrug?.DrugId, "drug1/NDC1");
            Assert.AreEqual(manufacturerDrug?.Name, "BrandName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerName, "ManufacturerName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerId, "NDC1");
            Assert.AreEqual(manufacturerDrug?.FormularyDrugId, "drug1");
            Assert.AreEqual(manufacturerDrug?.Origin, "UI");
            Assert.AreEqual(manufacturerDrug?.Identifiers.Count, 1);
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Type, "NDC");
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Identifier, "NDC1");

            PackagedDrugQryModelV2? packagedDrug = manufacturerDrug?.PackagedDrugs?[0];

            Assert.AreEqual(packagedDrug?.DrugId, "drug1/NDC1/Each");
            Assert.AreEqual(packagedDrug?.Name, "Each");
            Assert.AreEqual(packagedDrug?.PackageId, "Each");
            Assert.AreEqual(packagedDrug?.ManufacturedDrugId, "drug1/NDC1");
            Assert.AreEqual(packagedDrug?.Origin, "UI");
            Assert.AreEqual(packagedDrug?.Identifiers.Count, 1);
            Assert.AreEqual(packagedDrug?.Identifiers[0].Type, "BARCODE");
            Assert.AreEqual(packagedDrug?.Identifiers[0].Identifier, "BARCODE");
        }

        [TestMethod]
        public void HandleAsyncManufacturerTest()
        {
            //Act
            FormularyDrugQryModelV2? formularyDrug = drugQueryProcessor?.HandleAsync("drug1/NDC1").Result;
            //Assert
            Assert.IsNotNull(formularyDrug);
            Assert.AreEqual(formularyDrug.DrugId, "drug1");
            Assert.AreEqual(formularyDrug.Name, "drug1 name");
            Assert.AreEqual(formularyDrug.Strength, "10");
            Assert.AreEqual(formularyDrug.Volume, "mg");
            Assert.AreEqual(formularyDrug.Form, "TABLET");
            Assert.AreEqual(formularyDrug.TemperatureClass, TemperatureClass.COLD);
            Assert.AreEqual(formularyDrug.ScanValidation, false);
            Assert.AreEqual(formularyDrug.ControlSchedule, false);
            Assert.AreEqual(formularyDrug.ControlSubstance, false);
            Assert.AreEqual(formularyDrug.PackAlone, true);
            Assert.AreEqual(formularyDrug.BasePackaged, DrugBaseUnitOfMeasurement.EACH);
            Assert.AreEqual(formularyDrug.Route, "Oral");
            Assert.AreEqual(formularyDrug.HazardousTypes?[0], "GROUP_1");
            Assert.AreEqual(formularyDrug.Locations.Count, 2);
            Assert.AreEqual(formularyDrug.Locations["root"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["root"].Status, LocationSettingsStatus.Active);
            Assert.AreEqual(formularyDrug.Locations["locations"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["locations"].Status, LocationSettingsStatus.Active);

            ManufacturedDrugQryModelV2? manufacturerDrug = formularyDrug?.ManufacturedDrugs?[0];
            Assert.AreEqual(manufacturerDrug?.DrugId, "drug1/NDC1");
            Assert.AreEqual(manufacturerDrug?.Name, "BrandName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerName, "ManufacturerName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerId, "NDC1");
            Assert.AreEqual(manufacturerDrug?.FormularyDrugId, "drug1");
            Assert.AreEqual(manufacturerDrug?.Origin, "UI");
            Assert.AreEqual(manufacturerDrug?.Identifiers.Count, 1);
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Type, "NDC");
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Identifier, "NDC1");

            PackagedDrugQryModelV2? packagedDrug = manufacturerDrug?.PackagedDrugs?[0];

            Assert.AreEqual(packagedDrug?.DrugId, "drug1/NDC1/Each");
            Assert.AreEqual(packagedDrug?.Name, "Each");
            Assert.AreEqual(packagedDrug?.PackageId, "Each");
            Assert.AreEqual(packagedDrug?.ManufacturedDrugId, "drug1/NDC1");
            Assert.AreEqual(packagedDrug?.Origin, "UI");
            Assert.AreEqual(packagedDrug?.Identifiers.Count, 1);
            Assert.AreEqual(packagedDrug?.Identifiers[0].Type, "BARCODE");
            Assert.AreEqual(packagedDrug?.Identifiers[0].Identifier, "BARCODE");
        }

        [TestMethod]
        public void HandleAsyncPackageTest()
        {
            //Act
            FormularyDrugQryModelV2? formularyDrug = drugQueryProcessor?.HandleAsync("drug1/NDC1/Each").Result;
            //Assert
            Assert.IsNotNull(formularyDrug);
            Assert.AreEqual(formularyDrug.DrugId, "drug1");
            Assert.AreEqual(formularyDrug.Name, "drug1 name");
            Assert.AreEqual(formularyDrug.Strength, "10");
            Assert.AreEqual(formularyDrug.Volume, "mg");
            Assert.AreEqual(formularyDrug.Form, "TABLET");
            Assert.AreEqual(formularyDrug.TemperatureClass, TemperatureClass.COLD);
            Assert.AreEqual(formularyDrug.ScanValidation, false);
            Assert.AreEqual(formularyDrug.ControlSchedule, false);
            Assert.AreEqual(formularyDrug.ControlSubstance, false);
            Assert.AreEqual(formularyDrug.PackAlone, true);
            Assert.AreEqual(formularyDrug.BasePackaged, DrugBaseUnitOfMeasurement.EACH);
            Assert.AreEqual(formularyDrug.Route, "Oral");
            Assert.AreEqual(formularyDrug.HazardousTypes?[0], "GROUP_1");
            Assert.AreEqual(formularyDrug.Locations.Count, 2);
            Assert.AreEqual(formularyDrug.Locations["root"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["root"].Status, LocationSettingsStatus.Active);
            Assert.AreEqual(formularyDrug.Locations["locations"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["locations"].Status, LocationSettingsStatus.Active);

            ManufacturedDrugQryModelV2? manufacturerDrug = formularyDrug?.ManufacturedDrugs?[0];
            Assert.AreEqual(manufacturerDrug?.DrugId, "drug1/NDC1");
            Assert.AreEqual(manufacturerDrug?.Name, "BrandName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerName, "ManufacturerName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerId, "NDC1");
            Assert.AreEqual(manufacturerDrug?.FormularyDrugId, "drug1");
            Assert.AreEqual(manufacturerDrug?.Origin, "UI");
            Assert.AreEqual(manufacturerDrug?.Identifiers.Count, 1);
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Type, "NDC");
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Identifier, "NDC1");

            PackagedDrugQryModelV2? packagedDrug = manufacturerDrug?.PackagedDrugs?[0];

            Assert.AreEqual(packagedDrug?.DrugId, "drug1/NDC1/Each");
            Assert.AreEqual(packagedDrug?.Name, "Each");
            Assert.AreEqual(packagedDrug?.PackageId, "Each");
            Assert.AreEqual(packagedDrug?.ManufacturedDrugId, "drug1/NDC1");
            Assert.AreEqual(packagedDrug?.Origin, "UI");
            Assert.AreEqual(packagedDrug?.Identifiers.Count, 1);
            Assert.AreEqual(packagedDrug?.Identifiers[0].Type, "BARCODE");
            Assert.AreEqual(packagedDrug?.Identifiers[0].Identifier, "BARCODE");
        }

        [TestMethod]
        public void HandleAsyncWithDrugIdParamsTest()//string drugId, string locationId, bool subscribed
        {
            //Act
            List<DrugLocationSettingsModelV2>? drugLocationSettingsModels = drugQueryProcessor?.HandleAsync("drug1", "locations", true).Result;
            //Assert
            Assert.IsNotNull(drugLocationSettingsModels);
            Assert.AreEqual(drugLocationSettingsModels[0]?.DrugId, "drug1");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Name, "drug1 name");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Strength, "10");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Volume, "mg");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Form, "TABLET");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Locations?["locations"].Formulary, true);
            Assert.AreEqual(drugLocationSettingsModels[0]?.Locations?["locations"].Status, LocationSettingsStatus.Active);
        }

        [TestMethod]
        public void HandleAsyncWithLocationIdParamsTest()//string drugId, string locationId, bool subscribed
        {
            //Act
            List<DrugLocationSettingsModelV2>? drugLocationSettingsModels = drugQueryProcessor?.HandleAsync("", "locations", true).Result;
            //Assert
            Assert.IsNotNull(drugLocationSettingsModels);
            Assert.AreEqual(drugLocationSettingsModels[0]?.DrugId, "drug1");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Name, "drug1 name");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Strength, "10");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Volume, "mg");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Form, "TABLET");
            Assert.AreEqual(drugLocationSettingsModels[0]?.Locations?["locations"].Formulary, true);
            Assert.AreEqual(drugLocationSettingsModels[0]?.Locations?["locations"].Status, LocationSettingsStatus.Active);
        }

        [TestMethod]
        public void HandleAsyncQueryParamsTest()
        {
            qryParams?.Remove("preferredaccount");
            //Act
            List<FormularyDrugQryModelV2>? formularyDrugs = drugQueryProcessor?.HandleAsync(qryParams!).Result.ToList();
            //Assert
            Assert.IsNotNull(formularyDrugs);
            FormularyDrugQryModelV2 formularyDrug = formularyDrugs[0];
            Assert.AreEqual(formularyDrug.DrugId, "drug1");
            Assert.AreEqual(formularyDrug.Name, "drug1 name");
            Assert.AreEqual(formularyDrug.Strength, "10");
            Assert.AreEqual(formularyDrug.Volume, "mg");
            Assert.AreEqual(formularyDrug.Form, "TABLET");
            Assert.AreEqual(formularyDrug.TemperatureClass, TemperatureClass.COLD);
            Assert.AreEqual(formularyDrug.ScanValidation, false);
            Assert.AreEqual(formularyDrug.ControlSchedule, false);
            Assert.AreEqual(formularyDrug.ControlSubstance, false);
            Assert.AreEqual(formularyDrug.PackAlone, true);
            Assert.AreEqual(formularyDrug.BasePackaged, DrugBaseUnitOfMeasurement.EACH);
            Assert.AreEqual(formularyDrug.Route, "Oral");
            Assert.AreEqual(formularyDrug.HazardousTypes?[0], "GROUP_1");
            Assert.AreEqual(formularyDrug.Locations.Count, 2);
            Assert.AreEqual(formularyDrug.Locations["root"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["root"].Status, LocationSettingsStatus.Active);
            Assert.AreEqual(formularyDrug.Locations["locations"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["locations"].Status, LocationSettingsStatus.Active);

            ManufacturedDrugQryModelV2? manufacturerDrug = formularyDrug?.ManufacturedDrugs?[0];
            Assert.AreEqual(manufacturerDrug?.DrugId, "drug1/NDC1");
            Assert.AreEqual(manufacturerDrug?.Name, "BrandName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerName, "ManufacturerName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerId, "NDC1");
            Assert.AreEqual(manufacturerDrug?.FormularyDrugId, "drug1");
            Assert.AreEqual(manufacturerDrug?.Origin, "UI");
            Assert.AreEqual(manufacturerDrug?.Identifiers.Count, 1);
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Type, "NDC");
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Identifier, "NDC1");

            PackagedDrugQryModelV2? packagedDrug = manufacturerDrug?.PackagedDrugs?[0];

            Assert.AreEqual(packagedDrug?.DrugId, "drug1/NDC1/Each");
            Assert.AreEqual(packagedDrug?.Name, "Each");
            Assert.AreEqual(packagedDrug?.PackageId, "Each");
            Assert.AreEqual(packagedDrug?.ManufacturedDrugId, "drug1/NDC1");
            Assert.AreEqual(packagedDrug?.Origin, "UI");
            Assert.AreEqual(packagedDrug?.Identifiers.Count, 1);
            Assert.AreEqual(packagedDrug?.Identifiers[0].Type, "BARCODE");
            Assert.AreEqual(packagedDrug?.Identifiers[0].Identifier, "BARCODE");
        }

        [TestMethod]
        public void HandleBarcodeIdentifierAsyncTest()
        {
            qryParams?.Remove("preferredaccount");
            BarcodeIdentifierSearchParam barcodeIdentifierSearchParam = new()
            {
                DrugId = "drug1/NDC1/Each",
                Type = "BARCODE",
                Identifier = "BARCODE",
                Status = Swisslog.Base.Api.IdentifierStatus.APPROVED,
                Facility = "locations",
            };
            //Act
            List<BarcodeIdentifierModelV2>? result = drugQueryProcessor?.HandleBarcodeIdentifierAsync(barcodeIdentifierSearchParam, qryParams!).Result.ToList();
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual("BARCODE", result[0].Identifier);
            Assert.AreEqual("BARCODE", result[0].Type);
            Assert.AreEqual("drug/drug1/NDC1/Each", result[0].DrugId);
            Assert.AreEqual(Swisslog.Base.Api.IdentifierStatus.APPROVED, result[0].Status);
            Assert.IsNull(result[0].LastModifiedBy);

        }

        [TestMethod]
        public void GetFormularyPreferredSettingsTest()
        {
            //Act
            List<DrugCacheDataEntity>? drugCacheDataEntities = drugQueryProcessor?.GetFormularyPreferredSettings("acc1", "sup1").Result;
            //Assert
            Assert.IsNotNull(drugCacheDataEntities);
            Assert.AreEqual(1, drugCacheDataEntities.Count);
            FormularyDrugModelV2? formularyDrug = drugCacheDataEntities[0].FormularyDrug;
            Assert.AreEqual(formularyDrug?.DrugId, "drug1");
            Assert.AreEqual(formularyDrug?.Name, "drug1 name");
            Assert.AreEqual(formularyDrug?.Strength, "10");
            Assert.AreEqual(formularyDrug?.Volume, "mg");
            Assert.AreEqual(formularyDrug?.Form, "TABLET");
            Assert.AreEqual(formularyDrug?.TemperatureClass, TemperatureClass.COLD);
            Assert.AreEqual(formularyDrug?.ScanValidation, false);
            Assert.AreEqual(formularyDrug?.ControlSchedule, false);
            Assert.AreEqual(formularyDrug?.ControlSubstance, false);
            Assert.AreEqual(formularyDrug?.PackAlone, true);
            Assert.AreEqual(formularyDrug?.BasePackaged, DrugBaseUnitOfMeasurement.EACH);
            Assert.AreEqual(formularyDrug?.Route, "Oral");
            Assert.AreEqual(formularyDrug?.HazardousTypes?[0], "GROUP_1");
            Assert.AreEqual(formularyDrug?.Locations.Count, 2);
            Assert.AreEqual(formularyDrug?.Locations["root"].Formulary, true);
            Assert.AreEqual(formularyDrug?.Locations["root"].Status, LocationSettingsStatus.Active);
            Assert.AreEqual(formularyDrug?.Locations["locations"].Formulary, true);
            Assert.AreEqual(formularyDrug?.Locations["locations"].Status, LocationSettingsStatus.Active);
            Assert.AreEqual(formularyDrug?.Locations["locations"]?.PreferredAccount?.AccountId, "acc1");
            Assert.AreEqual(formularyDrug?.Locations["locations"]?.PreferredAccount?.SupplierId, "sup1");
        }

        [TestMethod]
        public void HandleAsyncIdentifierTest()
        {
            qryParams?.Remove("preferredaccount");
            //Act
            List<IdentifierDrugModelV2>? identifierDrugModels = drugIdentifierQueryProcessor?.HandleAsync("drug1/NDC1/Each", qryParams!).Result.ToList();

            //Assert
            Assert.IsNotNull(identifierDrugModels);
            Assert.AreEqual(identifierDrugModels[0]?.ItemId, "drug/drug1/NDC1/Each");
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers.Count, 2);
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[0].Type, "BARCODE");
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[0].Identifier, "BARCODE");
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[0].Status, Swisslog.Base.Api.IdentifierStatus.APPROVED);
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[1].Type, "NDC");
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[1].Identifier, "NDC1");
        }

        [TestMethod]
        public void HandleAsyncIdentifierWithDrugPrefixTest()
        {
            qryParams?.Remove("preferredaccount");
            //Act
            List<IdentifierDrugModelV2>? identifierDrugModels = drugIdentifierQueryProcessor?.HandleAsync("drug/drug1/NDC1/Each", qryParams!).Result.ToList();

            //Assert
            Assert.IsNotNull(identifierDrugModels);
            Assert.AreEqual(identifierDrugModels[0]?.ItemId, "drug/drug1/NDC1/Each");
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers.Count, 2);
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[0].Type, "BARCODE");
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[0].Identifier, "BARCODE");
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[0].Status, Swisslog.Base.Api.IdentifierStatus.APPROVED);
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[1].Type, "NDC");
            Assert.AreEqual(identifierDrugModels[0]?.Identifiers[1].Identifier, "NDC1");
        }

        [TestMethod]
        public void HandleAsyncQueryParamsWithPreferredAccountTRUETest()
        {
            if (!qryParams?.ContainsKey("locations") ?? true)
            {
                qryParams?.Add("locations", new string[] { "locations" });
            }
            qryParams?.Add("preferredaccount", new string[] { "true" });
            Dictionary<string, FormularyLocationSettingsModelV2> locations = new()
            {
                ["locations"] = new FormularyLocationSettingsModelV2
                {
                    Formulary = true,
                    Status = LocationSettingsStatus.Active,
                    PreferredAccount = new PreferredAccountModelV2 { AccountId = "acc1", SupplierId = "sup1" }
                }
            };
            mockCache?.Setup(x => x.CheckPreferredAccountOfLocationSettings(It.IsAny<Dictionary<string, FormularyLocationSettingsModelV2>>(), It.IsAny<bool>())).Returns(true);
            mockCache?.Setup(x => x.GetMatchedLocationsByParams(It.IsAny<Dictionary<string, FormularyLocationSettingsModelV2>>(), It.IsAny<Dictionary<string, string[]>>())).Returns(locations);

            //Act
            List<FormularyDrugQryModelV2>? formularyDrugs = drugQueryProcessor?.HandleAsync(qryParams!).Result.ToList();
            //Assert
            Assert.IsNotNull(formularyDrugs);
            FormularyDrugQryModelV2 formularyDrug = formularyDrugs[0];
            Assert.AreEqual(formularyDrug.DrugId, "drug1");
            Assert.AreEqual(formularyDrug.Name, "drug1 name");
            Assert.AreEqual(formularyDrug.Strength, "10");
            Assert.AreEqual(formularyDrug.Volume, "mg");
            Assert.AreEqual(formularyDrug.Form, "TABLET");
            Assert.AreEqual(formularyDrug.TemperatureClass, TemperatureClass.COLD);
            Assert.AreEqual(formularyDrug.ScanValidation, false);
            Assert.AreEqual(formularyDrug.ControlSchedule, false);
            Assert.AreEqual(formularyDrug.ControlSubstance, false);
            Assert.AreEqual(formularyDrug.PackAlone, true);
            Assert.AreEqual(formularyDrug.BasePackaged, DrugBaseUnitOfMeasurement.EACH);
            Assert.AreEqual(formularyDrug.Route, "Oral");
            Assert.AreEqual(formularyDrug.HazardousTypes?[0], "GROUP_1");
            Assert.AreEqual(formularyDrug.Locations.Count, 1);
            Assert.AreEqual(formularyDrug.Locations["locations"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["locations"].Status, LocationSettingsStatus.Active);
            Assert.IsNotNull(formularyDrug.Locations["locations"].PreferredAccount);
            Assert.AreEqual(formularyDrug.Locations["locations"].PreferredAccount?.AccountId, "acc1");
            Assert.AreEqual(formularyDrug.Locations["locations"].PreferredAccount?.SupplierId, "sup1");

            ManufacturedDrugQryModelV2? manufacturerDrug = formularyDrug?.ManufacturedDrugs?[0];
            Assert.AreEqual(manufacturerDrug?.DrugId, "drug1/NDC1");
            Assert.AreEqual(manufacturerDrug?.Name, "BrandName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerName, "ManufacturerName");
            Assert.AreEqual(manufacturerDrug?.ManufacturerId, "NDC1");
            Assert.AreEqual(manufacturerDrug?.FormularyDrugId, "drug1");
            Assert.AreEqual(manufacturerDrug?.Origin, "UI");
            Assert.AreEqual(manufacturerDrug?.Identifiers.Count, 1);
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Type, "NDC");
            Assert.AreEqual(manufacturerDrug?.Identifiers[0].Identifier, "NDC1");

            PackagedDrugQryModelV2? packagedDrug = manufacturerDrug?.PackagedDrugs?[0];

            Assert.AreEqual(packagedDrug?.DrugId, "drug1/NDC1/Each");
            Assert.AreEqual(packagedDrug?.Name, "Each");
            Assert.AreEqual(packagedDrug?.PackageId, "Each");
            Assert.AreEqual(packagedDrug?.ManufacturedDrugId, "drug1/NDC1");
            Assert.AreEqual(packagedDrug?.Origin, "UI");
            Assert.AreEqual(packagedDrug?.Identifiers.Count, 1);
            Assert.AreEqual(packagedDrug?.Identifiers[0].Type, "BARCODE");
            Assert.AreEqual(packagedDrug?.Identifiers[0].Identifier, "BARCODE");
        }

        [TestMethod]
        public void HandleAsyncQueryParamsWithPreferredAccountFALSETest()
        {
            if (!qryParams?.ContainsKey("locations") ?? true)
            {
                qryParams?.Add("locations", new string[] { "locations" });
            }
            qryParams?.Add("preferredaccount", new string[] { "false" });
            Dictionary<string, FormularyLocationSettingsModelV2> locations = new()
            {
                ["locations"] = new FormularyLocationSettingsModelV2
                {
                    Formulary = true,
                    Status = LocationSettingsStatus.Active,
                    PreferredAccount = new PreferredAccountModelV2 { AccountId = "acc1", SupplierId = "sup1" }
                }
            };
            mockCache?.Setup(x => x.CheckPreferredAccountOfLocationSettings(It.IsAny<Dictionary<string, FormularyLocationSettingsModelV2>>(), It.IsAny<bool>())).Returns(false);
            mockCache?.Setup(x => x.GetMatchedLocationsByParams(It.IsAny<Dictionary<string, FormularyLocationSettingsModelV2>>(), It.IsAny<Dictionary<string, string[]>>())).Returns(locations);

            //Act
            List<FormularyDrugQryModelV2>? formularyDrugs = drugQueryProcessor?.HandleAsync(qryParams!).Result.ToList();
            //Assert
            Assert.IsNotNull(formularyDrugs);
            Assert.AreEqual(formularyDrugs.Count, 0);
        }
        #endregion

        #region CleanUp
        public void TestCleanUp()
        {
            drugQueryProcessor = null;
            drugIdentifierQueryProcessor = null;
        }
        #endregion
    }
}
