﻿using Drug;
using Drug.Data;
using Drug.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NHibernate;
using Swisslog.Data.Api.V1;
using Swisslog.Drug.Api;
using Swisslog.Base.Api.Location;
using System.Collections.Generic;
using System.Net.Http;

namespace DrugTest.Service
{
    [TestClass]
    public class DataServiceTest
    {
        Data1Service? data1;
        Dictionary<string, string[]>? qryParams;
        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            ILogger<Data1Service> logData1Service = Mock.Of<ILogger<Data1Service>>();
            //Arrange
            ILogger<DrugService> logDrugService = Mock.Of<ILogger<DrugService>>();
            ILogger<DrugCommand> logDrugCommand = Mock.Of<ILogger<DrugCommand>>();
            ILogger<ProducerService> logProducerService = Mock.Of<ILogger<ProducerService>>();
            ILogger<DrugSyncServiceAdapter> logDrugSyncServiceAdapter = Mock.Of<ILogger<DrugSyncServiceAdapter>>();
            ILogger<DataChangedService> logDataChangedService = Mock.Of<ILogger<DataChangedService>>();
            ILogger<DrugValidator> logDrugValidator = Mock.Of<ILogger<DrugValidator>>();
            ILogger<Data1ServiceRestClient> logData1ServiceRestClient = Mock.Of<ILogger<Data1ServiceRestClient>>();
            HttpClient client = Mock.Of<HttpClient>();
            IWebHostEnvironment _env = Mock.Of<IWebHostEnvironment>();
            Mock<IConfiguration> mockConfig = new();
            Mock<IConfigurationSection> mockConfigurationSection = new();
            mockConfig.Setup(a => a.GetSection("kafka:producer")).Returns(mockConfigurationSection.Object);
            ILogger<DrugQueryProcessor> logDrugQueryProcessor = Mock.Of<ILogger<DrugQueryProcessor>>();
            ILogger<HazardousTypeQueryProcessor> logHazardousTypeQueryProcessor = Mock.Of<ILogger<HazardousTypeQueryProcessor>>();
            ILogger<DrugIdentifierQueryProcessor> logDrugIdentifierQueryProcessor = Mock.Of<ILogger<DrugIdentifierQueryProcessor>>();
            Mock<LocationRestClient> mockLocationRestClient = new(client, mockConfig.Object);            
            HttpResponseMessage httpResponseMessageForLocation = new()
            {
                StatusCode = System.Net.HttpStatusCode.OK,
                Content = new StringContent(Controller.TestData.locationContent, System.Text.Encoding.UTF8, "application/json")
            };
            mockLocationRestClient.Setup(x => x.GetLocations().Result).Returns(httpResponseMessageForLocation);
            Mock<LocationService> mockLocationService = new(new Mock<ILogger<LocationService>>().Object,
                mockLocationRestClient.Object);
            Mock<DrugCache> mockCache = new(new Mock<ISessionFactory>().Object, new Mock<ILogger<DrugCache>>().Object);
            mockCache.Setup(x => x.LoadDrugCache()).Verifiable();

            List<Location> listOfLocation = new()
            {
                new Location { LocationId = "root", Name = "root", ParentId = null },
                new Location { LocationId = "hospital/SWISSLOG-NA-TC", Name = "SWISSLOG-NA-TC", ParentId = "root" },
                new Location { LocationId = "hospital/SWISSLOG-NA-HQ", Name = "SWISSLOG-NA-HQ", ParentId = "root" },
                new Location { LocationId = "facility/SWISSLOG-NA-TC/PHARMACY-SOUTH", Name = "PHARMACY-SOUTH", ParentId = "hospital/SWISSLOG-NA-TC" },
                new Location { LocationId = "facility/SWISSLOG-NA-TC/PHARMACY-NORTH", Name = "PHARMACY-NORTH", ParentId = "hospital/SWISSLOG-NA-TC" },
                new Location { LocationId = "facility/SWISSLOG-NA-HQ/PHARMACY-EAST", Name = "PHARMACY-EAST", ParentId = "hospital/SWISSLOG-NA-HQ" },
                new Location { LocationId = "facility/SWISSLOG-NA-HQ/PHARMACY-WEST", Name = "PHARMACY-WEST", ParentId = "hospital/SWISSLOG-NA-HQ" }
            };

            mockLocationService.Setup(x => x.GetLocation(It.IsAny<string>())).Returns(listOfLocation);
            Mock<DrugQueryProcessor> mockDrugQueryProcessor = new(mockCache.Object, logDrugQueryProcessor, mockLocationService.Object);
            Mock<HazardousTypeQueryProcessor> mockHazardousTypeQueryProcessor = new(mockCache.Object, logHazardousTypeQueryProcessor);
            Mock<DrugIdentifierQueryProcessor> mockDrugIdentifierQueryProcessor = new(mockCache.Object, logDrugIdentifierQueryProcessor);
            Mock<Data1ServiceRestClient> mockData1ServiceRestClient = new(logData1ServiceRestClient, client, mockConfig.Object);

            qryParams = new()
            {
                { "locations", new string[] { "locations" } },
                { "status", new string[] { "Active" } },
                { "enablesecondcheck", new string[] { "false" } }
            };

            Mock<ILogger<DrugSyncRestClient>> mockDrugServiceLogger = new();
            Mock<DrugSyncRestClient> mockDrugSyncRestClient = new(client, mockConfig.Object, mockDrugServiceLogger.Object);

            ISessionFactory sessionFactory = Mock.Of<ISessionFactory>();
            NHibernate.ISession session = Mock.Of<NHibernate.ISession>();
            IHttpContextAccessor httpContextAccessor = Mock.Of<IHttpContextAccessor>();

            Mock<DrugSyncServiceAdapter> mockSyncServiceAdapter = new(mockDrugQueryProcessor.Object,
                logDrugSyncServiceAdapter, mockDrugSyncRestClient.Object, sessionFactory, mockCache.Object);

            ProducerService mockProducerService = new(mockConfig.Object, logProducerService);
            Mock<DataChangedService> mockDataChangedService = new(logDataChangedService, mockProducerService, mockConfig.Object);

            Mock<DrugCommand>? mockDrugCommand = new(mockCache.Object, sessionFactory, logDrugCommand, mockProducerService, 
                mockSyncServiceAdapter.Object, mockDataChangedService.Object);
            List<string> _selectedColumns = new() {
                "drugEntity.id", "drugEntity.drugId", "drugEntity.drugInfo", "drugEntity.changeSet",
                "drugEntity.createdBy", "drugEntity.lastModifiedBy", "drugEntity.creationDateUtc",
                "drugEntity.lastModificationDateUtc", "drugEntity.isDeleted", "drugEntity.version",
                "timestamp", "@timestamp"
            };
            Dictionary<string, FormularyLocationSettingsModelV2> locations = new()
            {
                ["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active },
                ["locations"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active }
            };
            FormularyDrugModelV2 formularyDrugModelV2 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };
            DataRequestV1 dataRequest = new()
            {
                Name = "drug2DbRestore",
                From = 0,
                Count = 100,
                Timezone = "-07:00",
                ReturnSource = true,
                SelectedColumns = _selectedColumns
            };
            DataPageV1 dataPageV1 = new()
            {
                Count = 100,
                Total = 1
            };
            DataRecordV1 dataRecordV1 = new();
            object dataRecords = "{\"internalResponse\":{\"numReducePhases\":1,\"fragment\":true},\"scrollId\":null,\"totalShards\":1,\"successfulShards\":1,\"skippedShards\":0,\"shardFailures\":[],\"clusters\":{\"total\":0,\"successful\":0,\"skipped\":0,\"fragment\":true},\"suggest\":null,\"profileResults\":{},\"took\":{\"millis\":16,\"days\":0,\"hours\":0,\"minutes\":0,\"seconds\":0,\"nanos\":16000000,\"micros\":16000,\"microsFrac\":16000,\"millisFrac\":16,\"secondsFrac\":0.016,\"minutesFrac\":0.0002666666666666667,\"hoursFrac\":0.000004444444444444444,\"daysFrac\":1.8518518518518519e-7,\"stringRep\":\"16ms\"},\"numReducePhases\":1,\"timedOut\":false,\"terminatedEarly\":null,\"failedShards\":0,\"hits\":{\"hits\":[{\"score\":\"NaN\",\"id\":\"1f69061b-5d73-451b-af2d-1df157fe3b9c\",\"type\":\"_doc\",\"nestedIdentity\":null,\"version\":-1,\"seqNo\":-2,\"primaryTerm\":0,\"highlightFields\":{},\"sortValues\":[1652941337474],\"matchedQueries\":[],\"explanation\":null,\"shard\":null,\"index\":\"drug2_latest_v1\",\"clusterAlias\":null,\"sourceAsMap\":{\"@timestamp\":\"2022-05-19T06:22:17.474Z\",\"drugEntity\":{\"isDeleted\":false,\"createdBy\":\"anonymous\",\"lastModifiedBy\":\"anonymous\",\"drugId\":\"drug-for-din-1\",\"id\":\"1f69061b-5d73-451b-af2d-1df157fe3b9c\",\"creationDateUtc\":\"2022-05-19T06:22:15.7304228Z\",\"lastModificationDateUtc\":\"2022-05-19T06:22:15.7304228Z\",\"version\":1,\"drugInfo\":\"{\\r\\n\\\"origin\\\":\\\"UI\\\",\\r\\n\\\"drugId\\\":\\\"drug-for-din-1\\\",\\r\\n\\\"identifiers\\\":[],\\r\\n\\\"name\\\":\\\"drug-for-din-1\\\",\\r\\n\\\"strength\\\":\\\"10\\\",\\r\\n\\\"volume\\\":\\\"mg\\\",\\r\\n\\\"form\\\":\\\"INJECTION\\\",\\r\\n\\\"route\\\":\\\"string\\\",\\r\\n\\\"controlSchedule\\\":false,\\r\\n\\\"controlSubstance\\\":false,\\r\\n\\\"drugSchedule\\\":\\\"string\\\",\\r\\n\\\"drugClass\\\":\\\"NONE\\\",\\r\\n\\\"packAlone\\\":false,\\r\\n\\\"otc\\\":false,\\r\\n\\\"basePackaged\\\":\\\"EACH\\\",\\r\\n\\\"temperatureClass\\\":\\\"NONE\\\",\\r\\n\\\"scanValidation\\\":false,\\r\\n\\\"status\\\":\\\"Active\\\",\\r\\n\\\"hazardousTypes\\\":[\\r\\n\\\"NONE\\\"\\r\\n],\\r\\n\\\"locations\\\":{\\r\\n\\\"root\\\":{\\r\\n\\\"requireLotCode\\\":true,\\r\\n\\\"requireExpiryDate\\\":true,\\r\\n\\\"requireSerialNumber\\\":true,\\r\\n\\\"preferLocalDispense\\\":true,\\r\\n\\\"status\\\":\\\"Active\\\",\\r\\n\\\"formulary\\\":true\\r\\n}\\r\\n},\\r\\n\\\"created\\\":\\\"2022-05-19T06:22:15.7304228Z\\\",\\r\\n\\\"lastModified\\\":\\\"2022-05-19T06:22:15.7304228Z\\\",\\r\\n\\\"version\\\":1\\r\\n}\",\"changeSet\":\"\"},\"timestamp\":\"2022-05-19T06:22:16.431469Z\"},\"innerHits\":null,\"sourceRef\":{\"fragment\":true},\"sourceAsString\":\"{\\\"@timestamp\\\":\\\"2022-05-19T06:22:17.474Z\\\",\\\"drugEntity\\\":{\\\"isDeleted\\\":false,\\\"createdBy\\\":\\\"anonymous\\\",\\\"lastModifiedBy\\\":\\\"anonymous\\\",\\\"drugId\\\":\\\"drug-for-din-1\\\",\\\"id\\\":\\\"1f69061b-5d73-451b-af2d-1df157fe3b9c\\\",\\\"creationDateUtc\\\":\\\"2022-05-19T06:22:15.7304228Z\\\",\\\"lastModificationDateUtc\\\":\\\"2022-05-19T06:22:15.7304228Z\\\",\\\"version\\\":1,\\\"drugInfo\\\":\\\"{\\\\r\\\\n\\\\\\\"origin\\\\\\\":\\\\\\\"UI\\\\\\\",\\\\r\\\\n\\\\\\\"drugId\\\\\\\":\\\\\\\"drug-for-din-1\\\\\\\",\\\\r\\\\n\\\\\\\"identifiers\\\\\\\":[],\\\\r\\\\n\\\\\\\"name\\\\\\\":\\\\\\\"drug-for-din-1\\\\\\\",\\\\r\\\\n\\\\\\\"strength\\\\\\\":\\\\\\\"10\\\\\\\",\\\\r\\\\n\\\\\\\"volume\\\\\\\":\\\\\\\"mg\\\\\\\",\\\\r\\\\n\\\\\\\"form\\\\\\\":\\\\\\\"INJECTION\\\\\\\",\\\\r\\\\n\\\\\\\"route\\\\\\\":\\\\\\\"string\\\\\\\",\\\\r\\\\n\\\\\\\"controlSchedule\\\\\\\":false,\\\\r\\\\n\\\\\\\"controlSubstance\\\\\\\":false,\\\\r\\\\n\\\\\\\"drugSchedule\\\\\\\":\\\\\\\"string\\\\\\\",\\\\r\\\\n\\\\\\\"drugClass\\\\\\\":\\\\\\\"NONE\\\\\\\",\\\\r\\\\n\\\\\\\"packAlone\\\\\\\":false,\\\\r\\\\n\\\\\\\"otc\\\\\\\":false,\\\\r\\\\n\\\\\\\"basePackaged\\\\\\\":\\\\\\\"EACH\\\\\\\",\\\\r\\\\n\\\\\\\"temperatureClass\\\\\\\":\\\\\\\"NONE\\\\\\\",\\\\r\\\\n\\\\\\\"scanValidation\\\\\\\":false,\\\\r\\\\n\\\\\\\"status\\\\\\\":\\\\\\\"Active\\\\\\\",\\\\r\\\\n\\\\\\\"hazardousTypes\\\\\\\":[\\\\r\\\\n\\\\\\\"NONE\\\\\\\"\\\\r\\\\n],\\\\r\\\\n\\\\\\\"locations\\\\\\\":{\\\\r\\\\n\\\\\\\"root\\\\\\\":{\\\\r\\\\n\\\\\\\"requireLotCode\\\\\\\":true,\\\\r\\\\n\\\\\\\"requireExpiryDate\\\\\\\":true,\\\\r\\\\n\\\\\\\"requireSerialNumber\\\\\\\":true,\\\\r\\\\n\\\\\\\"preferLocalDispense\\\\\\\":true,\\\\r\\\\n\\\\\\\"status\\\\\\\":\\\\\\\"Active\\\\\\\",\\\\r\\\\n\\\\\\\"formulary\\\\\\\":true\\\\r\\\\n}\\\\r\\\\n},\\\\r\\\\n\\\\\\\"created\\\\\\\":\\\\\\\"2022-05-19T06:22:15.7304228Z\\\\\\\",\\\\r\\\\n\\\\\\\"lastModified\\\\\\\":\\\\\\\"2022-05-19T06:22:15.7304228Z\\\\\\\",\\\\r\\\\n\\\\\\\"version\\\\\\\":1\\\\r\\\\n}\\\",\\\"changeSet\\\":\\\"\\\"},\\\"timestamp\\\":\\\"2022-05-19T06:22:16.431469Z\\\"}\",\"rawSortValues\":[],\"fields\":{\"_ignored\":{\"name\":\"_ignored\",\"values\":[\"drugEntity.drugInfo.keyword\"],\"value\":\"drugEntity.drugInfo.keyword\",\"fragment\":true}},\"fragment\":false}],\"totalHits\":{\"value\":37,\"relation\":\"EQUAL_TO\"},\"maxScore\":\"NaN\",\"sortFields\":null,\"collapseField\":null,\"collapseValues\":null,\"fragment\":true},\"aggregations\":null,\"fragment\":false}";
            dataRecordV1.AdditionalProperties?.Add("data", dataRecords);
            List<DataRecordV1> dataRecordV1s = new()
            {
                dataRecordV1
            };
            dataPageV1.Data = dataRecordV1s;

            mockData1ServiceRestClient.Setup(x => x.GetDrugBackup(It.IsAny<DataRequestV1>()).Result).Returns(dataPageV1);
            mockDrugCommand.Setup(x => x.HandleAsync(It.IsAny<DrugEntity>()).Result).Returns(true);

            data1 = new(logData1Service, mockData1ServiceRestClient.Object, mockDrugCommand.Object);
        }
        #endregion

        [TestMethod]
        public void DatabaseRestoreTest()
        {
            //Act
            var result = data1?.DatabaseRestore();
            //Assert
            Assert.IsNotNull(result);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            data1 = null;
        }
    }
}
