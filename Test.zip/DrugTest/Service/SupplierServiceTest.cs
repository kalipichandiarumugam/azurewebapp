﻿using Drug;
using Drug.Data;
using Drug.Services;
using DrugTest.Controller;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NHibernate;
using Swisslog.Drug.Api;
using Swisslog.Supplier2.Api;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DrugTest.Service
{
    [TestClass]
    public class SupplierServiceTest
    {
        SupplierService? _supplierService;
        Mock<SupplierRestClient>? mockSupplierRestClient;
        Mock<DrugCommand>? mockDrugCommand;
        Mock<DrugService>? mockService;
        Tuple<bool, object>? tupleFormulary;
        Tuple<bool, object>? tupleMultipleUserConflict;
        Tuple<bool, object>? tupleInternalServerError;
        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            ILogger<SupplierService> logSupplierService = Mock.Of<ILogger<SupplierService>>();
            ILogger<SupplierRestClient> logSupplierRestClient = Mock.Of<ILogger<SupplierRestClient>>();
            ILogger<DrugService> logDrugService = Mock.Of<ILogger<DrugService>>();
            ILogger<DrugCommand> logDrugCommand = Mock.Of<ILogger<DrugCommand>>();
            ILogger<ProducerService> logProducerService = Mock.Of<ILogger<ProducerService>>();
            ILogger<DrugSyncServiceAdapter> logDrugSyncServiceAdapter = Mock.Of<ILogger<DrugSyncServiceAdapter>>();
            ILogger<DrugQueryProcessor> logDrugQueryProcessor = Mock.Of<ILogger<DrugQueryProcessor>>();
            ILogger<DataChangedService> logDataChangedService = Mock.Of<ILogger<DataChangedService>>();
            ILogger<HazardousTypeQueryProcessor> logHazardousTypeQueryProcessor = Mock.Of<ILogger<HazardousTypeQueryProcessor>>();
            ILogger<DrugIdentifierQueryProcessor> logDrugIdentifierQueryProcessor = Mock.Of<ILogger<DrugIdentifierQueryProcessor>>();
            HttpClient client = Mock.Of<HttpClient>();
            IWebHostEnvironment _env = Mock.Of<IWebHostEnvironment>();
            Mock<IConfiguration> mockConfig = new();
            Mock<IConfigurationSection> mockConfigurationSection = new();
            mockConfig.Setup(a => a.GetSection("kafka:producer")).Returns(mockConfigurationSection.Object);
            mockSupplierRestClient = new(logSupplierRestClient, client, mockConfig.Object);
            NHibernate.ISession session = Mock.Of<NHibernate.ISession>();
            ProducerService mockProducerService = new(mockConfig.Object, logProducerService);
            ISessionFactory sessionFactory = Mock.Of<ISessionFactory>();

            Mock<ILogger<DrugSyncRestClient>> mockDrugServiceLogger2 = new();
            Mock<DrugSyncRestClient> mockDrugSyncRestClient = new(client, mockConfig.Object, mockDrugServiceLogger2.Object);

            Mock<DrugCache> mockCache = new(new Mock<ISessionFactory>().Object, new Mock<ILogger<DrugCache>>().Object);
            mockCache.Setup(x => x.LoadDrugCache()).Verifiable();
            Mock<LocationRestClient> mockLocationRestClient = new(client, mockConfig.Object);

            HttpResponseMessage httpResponseMessageForLocation = new()
            {
                StatusCode = System.Net.HttpStatusCode.OK,
                Content = new StringContent(TestData.locationContent, System.Text.Encoding.UTF8, "application/json")
            };
            mockLocationRestClient.Setup(x => x.GetLocations().Result).Returns(httpResponseMessageForLocation);
            Mock<LocationService> mockLocationService = new(new Mock<ILogger<LocationService>>().Object,
                mockLocationRestClient.Object);
            Mock<DrugQueryProcessor> mockDrugQueryProcessor = new(mockCache.Object, logDrugQueryProcessor, mockLocationService.Object);
            Mock<HazardousTypeQueryProcessor> mockHazardousTypeQueryProcessor = new(mockCache.Object, logHazardousTypeQueryProcessor);
            Mock<DrugIdentifierQueryProcessor> mockDrugIdentifierQueryProcessor = new(mockCache.Object, logDrugIdentifierQueryProcessor);
            Mock<DrugSyncServiceAdapter> mockSyncServiceAdapter = new(mockDrugQueryProcessor.Object,
                logDrugSyncServiceAdapter, mockDrugSyncRestClient.Object, sessionFactory, mockCache.Object);

            Mock<DataChangedService> mockDataChangedService = new(logDataChangedService, mockProducerService, mockConfig.Object);
            mockService = new(mockDrugQueryProcessor.Object, mockHazardousTypeQueryProcessor.Object, mockDrugIdentifierQueryProcessor.Object, logDrugService, mockLocationService.Object);
            mockDrugCommand = new(mockCache.Object, sessionFactory, logDrugCommand, mockProducerService, mockSyncServiceAdapter.Object, mockDataChangedService.Object);

            AccountV2 account1 = new()
            {
                SupplierId = "S1",
                AccountId = "A1",
                Name = "Acc Name",
                LocationId = "hospital/SWISSLOG-NA-TC",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };
            AccountV2 account2 = new()
            {
                SupplierId = "S1",
                AccountId = "A2",
                Name = "Acc Name2",
                LocationId = "hospital/SWISSLOG-NA-TC",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };
            AccountV2 account3 = new()
            {
                SupplierId = "S2",
                AccountId = "A3",
                Name = "Acc Name3",
                LocationId = "hospital/SWISSLOG-NA-TC",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };

            AccountV2Page accountV2Page = new()
            {
                Data = new List<AccountV2> { account1, account2 },
                Count = 2,
                Total = 2,
            };

            Dictionary<string, FormularyLocationSettingsModelV2> locations = new();
            locations["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active };
            locations["locations"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active, PreferredAccount = new PreferredAccountModelV2 { AccountId = "A1", SupplierId = "S1" } };


            FormularyDrugModelV2 formularyDrugModelV2 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };

            DrugCacheDataEntity drugCacheDataEntity = new(formularyDrugModelV2)
            {
                DrugId = "drug",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
            };

            List<DrugCacheDataEntity> listOfDrugCacheEntity = new();
            listOfDrugCacheEntity.Add(drugCacheDataEntity);

            mockSupplierRestClient.Setup(x => x.GetAccounts().Result).Returns(accountV2Page);
            mockSupplierRestClient.Setup(x => x.GetAccount("S1", "A1").Result).Returns(account1);
            mockSupplierRestClient.Setup(x => x.GetAccount("S1", "A2").Result).Returns(account2);
            mockSupplierRestClient.Setup(x => x.GetAccount("S2", "A3").Result).Returns(account3);
            mockService.Setup(x => x.GetDrugByPreferredSetting(It.IsAny<string>(), It.IsAny<string>()).Result).Returns(listOfDrugCacheEntity);
            tupleFormulary = new(true, formularyDrugModelV2);
            tupleMultipleUserConflict = new Tuple<bool, object>(false, "MULTIPLEUSER_UPDATE");
            tupleInternalServerError = new Tuple<bool, object>(false, "Internal Server Error");
            IHttpContextAccessor httpContextAccessor = Mock.Of<IHttpContextAccessor>();

            //Act
            _supplierService = new SupplierService(logSupplierService, mockSupplierRestClient.Object, mockService.Object, mockDrugCommand!.Object, httpContextAccessor);

        }
        #endregion

        #region Method
        [TestMethod]
        public void AddUpdateAccountCacheForAddAccountInCacheTest()
        {
            //Act
            Task<bool>? result = _supplierService?.AddUpdateAccountCache("S2", "A3");

            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Result);

            //Verify
            mockSupplierRestClient?.Verify(mock => mock.GetAccount("S2", "A3"), Times.Once);
            
        }

        [TestMethod]
        public void AddUpdateAccountCacheForUpdateAccountInCacheTest()
        {
            //Act
            Task<bool>? result = _supplierService?.AddUpdateAccountCache("S1", "A1");
            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Result);

            //Verify
            mockSupplierRestClient?.Verify(mock => mock.GetAccount("S1", "A1"), Times.Once);
        }

        [TestMethod]
        public void AddUpdateAccountCacheForUpdatePreferredAccountTest()
        {
            AccountV2 account2 = new()
            {
                SupplierId = "S1",
                AccountId = "A2",
                Name = "Acc Name2",
                LocationId = "hospital/SWISSLOG-NA-HQ",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };
            mockSupplierRestClient?.Setup(x => x.GetAccount("S1", "A1").Result).Returns(account2);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleFormulary!);
            //Act
            Task<bool>? result = _supplierService?.AddUpdateAccountCache("S1", "A1");

            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Result);

            //Verify
            mockSupplierRestClient?.Verify(mock => mock.GetAccount("S1", "A1"), Times.Once);
            mockService?.Verify(mock => mock.GetDrugByPreferredSetting(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            mockDrugCommand?.Verify(mock => mock.HandleAsync(It.IsAny<DrugSaveCommand>()), Times.Once);
        }

        [TestMethod]
        public void AddUpdateAccountCacheForMultipleUserConflictTest()
        {
            AccountV2 account2 = new()
            {
                SupplierId = "S1",
                AccountId = "A2",
                Name = "Acc Name2",
                LocationId = "hospital/SWISSLOG-NA-HQ",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };
            mockSupplierRestClient?.Setup(x => x.GetAccount("S1", "A2").Result).Returns(account2);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleMultipleUserConflict!);
            //Act
            Task<bool>? result = _supplierService?.AddUpdateAccountCache("S1", "A2");

            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Result);

            //Verify
            mockSupplierRestClient?.Verify(mock => mock.GetAccount("S1", "A2"), Times.Once);
        }

        [TestMethod]
        public void AddUpdateAccountCacheForInternalServerErrorTest()
        {
            AccountV2 account2 = new()
            {
                SupplierId = "S1",
                AccountId = "A2",
                Name = "Acc Name2",
                LocationId = "hospital/SWISSLOG-NA-HQ",
                AckPONumberSuffix = "ackSuffix",
                CatalogDriven = false,
                ErpValue = "erpvalue",
                LastModified = DateTime.UtcNow,
                LastModifiedAction = ModifiedAction.CREATE,
                LastModifiedBy = "unknown",
            };
            mockSupplierRestClient?.Setup(x => x.GetAccount("S1", "A2").Result).Returns(account2);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleInternalServerError!);
            //Act
            Task<bool>? result = _supplierService?.AddUpdateAccountCache("S1", "A2");

            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Result);

            //Verify
            mockSupplierRestClient?.Verify(mock => mock.GetAccount("S1", "A2"), Times.Once);
            //mockService?.Verify(mock => mock.GetDrugByPreferredSetting(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            //mockDrugCommand?.Verify(mock => mock.HandleAsync(It.IsAny<DrugSaveCommand>()), Times.Once);
        }
        #endregion

        #region CleanUp
        [TestCleanup]
        public void TestCleanUp()
        {
            _supplierService = null;
        }
        #endregion
    }
}
