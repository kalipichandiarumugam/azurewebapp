﻿using AutoMapper;
using Drug;
using Drug.Data;
using Drug.Models;
using Drug.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NHibernate;
using NHibernate.Linq;
using NHibernate.Type;
using Swisslog.Drug.Api;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace DrugTest.Service
{
    [TestClass]
    public class DrugCommandTest
    {
        DrugCommand? drugCommand;
        Dictionary<string, string[]>? qryParams;
        FormularyDrugModelV2? formularyDrugModelV2;
        ManufacturedDrugModelV2? manufacturedDrugModelV2;
        PackagedDrugModelV2? packagedDrugModelV2;
        string? remoteIp;
        string? localIp;
        string? user;
        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            //Arrange
            ILogger<DrugService> logDrugService = Mock.Of<ILogger<DrugService>>();
            ILogger<DrugCommand> logDrugCommand = Mock.Of<ILogger<DrugCommand>>();
            ILogger<ProducerService> logProducerService = Mock.Of<ILogger<ProducerService>>();
            ILogger<DrugSyncServiceAdapter> logDrugSyncServiceAdapter = Mock.Of<ILogger<DrugSyncServiceAdapter>>();
            ILogger<DataChangedService> logDataChangedService = Mock.Of<ILogger<DataChangedService>>();
            ILogger<DrugValidator> logDrugValidator = Mock.Of<ILogger<DrugValidator>>();
            HttpClient client = Mock.Of<HttpClient>();
            IMapper mapper = Mock.Of<IMapper>();
            IWebHostEnvironment _env = Mock.Of<IWebHostEnvironment>();
            Mock<IConfiguration> mockConfig = new();
            Mock<IConfigurationSection> mockConfigurationSection = new();
            mockConfig.Setup(a => a.GetSection("kafka:producer")).Returns(mockConfigurationSection.Object);
            ILogger<DrugQueryProcessor> logDrugQueryProcessor = Mock.Of<ILogger<DrugQueryProcessor>>();
            ILogger<HazardousTypeQueryProcessor> logHazardousTypeQueryProcessor = Mock.Of<ILogger<HazardousTypeQueryProcessor>>();
            ILogger<DrugIdentifierQueryProcessor> logDrugIdentifierQueryProcessor = Mock.Of<ILogger<DrugIdentifierQueryProcessor>>();
            Mock<LocationRestClient> mockLocationRestClient = new(client, mockConfig.Object);
            HttpResponseMessage httpResponseMessageForLocation = new()
            {
                StatusCode = System.Net.HttpStatusCode.OK,
                Content = new StringContent(Controller.TestData.locationContent, System.Text.Encoding.UTF8, "application/json")
            };

            mockLocationRestClient.Setup(x => x.GetLocations().Result).Returns(httpResponseMessageForLocation);
            Mock<LocationService> mockLocationService = new(new Mock<ILogger<LocationService>>().Object,
                mockLocationRestClient.Object);
            Mock<DrugCache> mockCache = new(new Mock<ISessionFactory>().Object, new Mock<ILogger<DrugCache>>().Object);
            mockCache.Setup(x => x.LoadDrugCache()).Verifiable();
            Mock<DrugQueryProcessor> mockDrugQueryProcessor = new(mockCache.Object, logDrugQueryProcessor, mockLocationService.Object);
            Mock<HazardousTypeQueryProcessor> mockHazardousTypeQueryProcessor = new(mockCache.Object, logHazardousTypeQueryProcessor);
            Mock<DrugIdentifierQueryProcessor> mockDrugIdentifierQueryProcessor = new(mockCache.Object, logDrugIdentifierQueryProcessor);
            qryParams = new()
            {
                { "locations", new string[] { "locations" } },
                { "status", new string[] { "active" } }
            };

            Dictionary<string, FormularyLocationSettingsModelV2> locations = new()
            {
                ["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active },
                ["locations"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active }
            };
            FormularyDrugQryModelV2 formularyDrugQryModelV2 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                FormNormalized = new List<string> { "TABLET", "PILL" },
                Locations = locations
            };
            List<FormularyDrugQryModelV2> formularyDrugQryModelV2s1 = new()
            {
                formularyDrugQryModelV2
            };
            IEnumerable<FormularyDrugQryModelV2> formularyDrugQryModelV2s = formularyDrugQryModelV2s1.AsEnumerable();
            PagingInfo? pageInfo = new(0, 20);
            Swisslog.Base.Api.Page<FormularyDrugQryModelV2> pageData = DrugPage<FormularyDrugQryModelV2>.ApplyPaging(formularyDrugQryModelV2s, pageInfo);

            Mock<DrugService> mockService = new(mockDrugQueryProcessor.Object, mockHazardousTypeQueryProcessor.Object, mockDrugIdentifierQueryProcessor.Object, logDrugService, mockLocationService.Object);
            List<string> drugIds = new()
            {
                "drug"
            };
            mockService.Setup(x => x.QueryDrugIds(qryParams).Result).Returns(drugIds);
            mockService.Setup(x => x.QueryDrugs(qryParams).Result).Returns(pageData);

            Mock<ILogger<DrugSyncRestClient>> mockDrugSyncRestClientLogger = new();
            Mock<DrugSyncRestClient> mockDrugSyncRestClient = new(client, mockConfig.Object, mockDrugSyncRestClientLogger.Object);
            ISessionFactory sessionFactory = Mock.Of<ISessionFactory>();
            IHttpContextAccessor httpContextAccessor = Mock.Of<IHttpContextAccessor>();
            remoteIp = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();
            localIp = httpContextAccessor.HttpContext?.Connection?.LocalIpAddress?.ToString();
            user = httpContextAccessor.HttpContext?.User?.Identity?.Name ?? "unknown";
            formularyDrugModelV2 = new FormularyDrugModelV2
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                FormNormalized = new List<string> { "TABLET", "PILL" },
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };
            manufacturedDrugModelV2 = new ManufacturedDrugModelV2
            {
                DrugId = "formularyId/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "formularyId",
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            packagedDrugModelV2 = new PackagedDrugModelV2
            {
                DrugId = "formularyId/123456789/Each",
                ManufacturedDrugId = "formularyId/123456789",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "BARCODE", Identifier = "987654321", Status = Swisslog.Base.Api.IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            PackagedDrugModelV2 packagedDrugModelV22 = new()
            {
                DrugId = "formularyId/123456789/Pack",
                ManufacturedDrugId = "formularyId/123456789",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 10,
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "BARCODE", Identifier = "Pack987654321", Status = Swisslog.Base.Api.IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            DrugEntity entityFData = new() { Id = Guid.NewGuid(), DrugId = "drug", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityMData = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789", DrugInfo = DrugUtility<string>.DrugToString(manufacturedDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityPData = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789/Each", DrugInfo = DrugUtility<string>.DrugToString(packagedDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityP2Data = new() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789/Pack", DrugInfo = DrugUtility<string>.DrugToString(packagedDrugModelV22), IsDeleted = false, Version = 0 };
            DrugEntity entityF2Data = new() { Id = Guid.NewGuid(), DrugId = "drug1", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityM2Data = new() { Id = Guid.NewGuid(), DrugId = "drug1/NDC1", DrugInfo = DrugUtility<string>.DrugToString(manufacturedDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityF3Data = new() { Id = Guid.NewGuid(), DrugId = "drug2", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityM3Data = new() { Id = Guid.NewGuid(), DrugId = "drug2/NDC2", DrugInfo = DrugUtility<string>.DrugToString(manufacturedDrugModelV2), IsDeleted = false, Version = 0 };
            DrugEntity entityP3Data = new() { Id = Guid.NewGuid(), DrugId = "drug2/NDC2/BARCODE", DrugInfo = DrugUtility<string>.DrugToString(packagedDrugModelV2), IsDeleted = false, Version = 0 };
            List<DrugEntity> drugList = new() { entityFData, entityMData, entityPData, entityP2Data, entityF2Data, entityM2Data, entityF3Data, entityM3Data, entityP3Data };

            DrugCacheDataEntity drugCacheDataEntity = new()
            {
                DrugId = "drug",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
            };

            DrugCacheDataEntity drugCacheDataEntityForManufacturer1 = new()
            {
                DrugId = "drug1/NDC1",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Manufactured,
                HasDrugInfo = true,
                Id = "drug1/NDC1",
                IsActive = true,
                Origin = "UI",
            };

            DrugCacheDataEntity drugCacheDataEntityForPackage2 = new()
            {
                DrugId = "drug2/NDC2/BARCODE",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Packaged,
                HasDrugInfo = true,
                Id = "drug2/NDC2/BARCODE",
                IsActive = true,
                Origin = "UI",
            };

            DrugCacheDataEntity drugCacheDataEntityForManufacturer2 = new()
            {
                DrugId = "drug2/NDC2",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Manufactured,
                HasDrugInfo = true,
                Id = "drug2/NDC2",
                IsActive = true,
                Origin = "UI",
                Children = new List<DrugCacheDataEntity>() { drugCacheDataEntityForPackage2 }
            };



            DrugCacheDataEntity drugCacheDataEntity1 = new()
            {
                DrugId = "drug1",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug1",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                Children = new List<DrugCacheDataEntity>() { drugCacheDataEntityForManufacturer1 },
            };

            DrugCacheDataEntity drugCacheDataEntity2 = new()
            {
                DrugId = "drug2",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug2",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                Children = new List<DrugCacheDataEntity>() { drugCacheDataEntityForManufacturer2 },
            };
			
            Mock<NHibernate.ISession> mockSession = new();
            Mock<ISessionFactory> mockSessionFactory = new();
            Mock<IQuery> queryMock = new();
            Mock<ITransaction> mockTransaction = new();
			mockSessionFactory.Setup(x => x.OpenSession()).Returns(mockSession.Object);
            mockSession.Setup(x => x.BeginTransaction()).Returns(mockTransaction.Object);
            mockSession.Setup(x => x.Dispose());
            mockTransaction.Setup(x => x.Commit());
            mockTransaction.Setup(x => x.Dispose());

            mockTransaction.Setup(x => x.Commit()).Verifiable();
#pragma warning disable CS0618 // Type or member is obsolete
            mockSession.SetupGet(x => x.Transaction).Returns(mockTransaction.Object);
#pragma warning restore CS0618 // Type or member is obsolete
            mockSession.Setup(session => session.CreateQuery("from drugs")).Returns(queryMock.Object);
            //mockSession.Setup(x => x.SaveOrUpdateAsync(It.IsAny<DrugEntity>())).Returns(new object()); ;
            mockSession.Setup(session => session.Query<DrugEntity>()).Returns(new TestingQueryable<DrugEntity>(drugList.AsQueryable()));
            queryMock.Setup(x => x.List<DrugEntity>()).Returns(drugList);

            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug", false).Result).Returns(drugCacheDataEntity);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1", false).Result).Returns(drugCacheDataEntity1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2", false).Result).Returns(drugCacheDataEntity2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1/NDC1", false).Result).Returns(drugCacheDataEntityForManufacturer1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2/NDC2/BARCODE", false).Result).Returns(drugCacheDataEntityForPackage2);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug1/ndc1", false).Result).Returns(drugCacheDataEntityForManufacturer1);
            mockCache.Setup(x => x.GetDrugCacheDataEntityAsync("drug2/ndc2/barcode", false).Result).Returns(drugCacheDataEntityForPackage2);

            OriginData.OriginAsChangeset = new List<string>() { "mfn" };
            OriginData.OriginsToUpdateWM6 = new List<string>() { "ui", "import" };
            OriginData.AllowedOriginTypes = new List<string>() { "ui", "import", "wm6", "mfn" };

            Mock<DrugSyncServiceAdapter> mockSyncServiceAdapter = new(mockDrugQueryProcessor.Object,
                logDrugSyncServiceAdapter, mockDrugSyncRestClient.Object, sessionFactory, mockCache.Object);
            mockSyncServiceAdapter.Setup(x => x.PushFormularyDrug(It.IsAny<string>(), It.IsAny<DateTime>()).Result).Returns(true);
            mockSyncServiceAdapter.Setup(x => x.PushDrugsToWM6Async().Result).Returns(new List<string>() { "drug" });
            ProducerService mockProducerService = new(mockConfig.Object, logProducerService);
            Mock<DataChangedService> mockDataChangedService = new(logDataChangedService, mockProducerService, mockConfig.Object);
            drugCommand = new DrugCommand(mockCache.Object, mockSessionFactory.Object, logDrugCommand, mockProducerService, mockSyncServiceAdapter.Object, mockDataChangedService.Object);

        }
        #endregion

        #region Methods
        [TestMethod]
        public void HandleAsyncForAddFormularyTest()
        {
            Dictionary<string, FormularyLocationSettingsModelV2> locations = new()
            {
                ["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active },
                ["locations"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active }
            };
            FormularyDrugModelV2 localFormularyDrugModelV2 = new()
            {
                DrugId = "drug4",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Add
            };
            DrugCacheDataEntity? drugCacheEntity = new(localFormularyDrugModelV2);
            DrugSaveCommand drugSaveCommand = new(drugCacheEntity, reqContext, DrugType.Formulary);
            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugSaveCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            string output = (String)result.Item2;
            Assert.IsNotNull(output);
        }

        [TestMethod]
        public void HandleAsyncForAddManufacturerTest()
        {
            ManufacturedDrugModelV2 localManufacturedDrugModelV2 = new()
            {
                DrugId = "drug4/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug4",
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Add
            };
            DrugCacheDataEntity? drugCacheEntity = new(localManufacturedDrugModelV2);
            DrugSaveCommand drugSaveCommand = new(drugCacheEntity, reqContext, DrugType.Manufactured);
            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugSaveCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            string output = (String)result.Item2;
            Assert.IsNotNull(output);
        }

        [TestMethod]
        public void HandleAsyncForAddPackageTest()
        {
            PackagedDrugModelV2 localPackagedDrugModelV2 = new()
            {
                DrugId = "drug4/123456789/Each",
                ManufacturedDrugId = "drug4/123456789",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "BARCODE", Identifier = "987654321", Status = Swisslog.Base.Api.IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Add
            };
            DrugCacheDataEntity? drugCacheEntity = new(localPackagedDrugModelV2);
            DrugSaveCommand drugSaveCommand = new(drugCacheEntity, reqContext, DrugType.Packaged);
            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugSaveCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            string output = (String)result.Item2;
            Assert.IsNotNull(output);
        }

        [TestMethod]
        public void HandleAsyncForUpdateFormularyTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Update
            };
            DrugCacheDataEntity? drugCacheEntity = new(formularyDrugModelV2);
            DrugSaveCommand drugSaveCommand = new(drugCacheEntity, reqContext, DrugType.Formulary);
            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugSaveCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            FormularyDrugModelV2 formularyDrug = (FormularyDrugModelV2)result.Item2;
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(formularyDrug.DrugId, "drug");
            Assert.AreEqual(formularyDrug.Name, "drug name");
            Assert.AreEqual(formularyDrug.Strength, "10");
            Assert.AreEqual(formularyDrug.Volume, "mg");
            Assert.AreEqual(formularyDrug.Form, "TABLET");
            Assert.AreEqual(formularyDrug.FormNormalized?.Count, 2);
            Assert.AreEqual(formularyDrug.FormNormalized?[0], "TABLET");
            Assert.AreEqual(formularyDrug.FormNormalized?[1], "PILL");
            Assert.AreEqual(formularyDrug.TemperatureClass, TemperatureClass.COLD);
            Assert.AreEqual(formularyDrug.ScanValidation, false);
            Assert.AreEqual(formularyDrug.ControlSchedule, false);
            Assert.AreEqual(formularyDrug.ControlSubstance, false);
            Assert.AreEqual(formularyDrug.PackAlone, true);
            Assert.AreEqual(formularyDrug.BasePackaged, DrugBaseUnitOfMeasurement.EACH);
            Assert.AreEqual(formularyDrug.Route, "Oral");
            Assert.AreEqual(formularyDrug.Origin, "UI");
            Assert.AreEqual(formularyDrug.HazardousTypes[0], "GROUP_1");
            Assert.AreEqual(formularyDrug.Locations.Count, 2);
            Assert.AreEqual(formularyDrug.Locations["root"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["root"].Status, LocationSettingsStatus.Active);
            Assert.AreEqual(formularyDrug.Locations["locations"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["locations"].Status, LocationSettingsStatus.Active);
        }

        [TestMethod]
        public void HandleAsyncForUpdateManufacturerTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Update
            };
            DrugCacheDataEntity? drugCacheEntity = new(manufacturedDrugModelV2);
            DrugSaveCommand drugSaveCommand = new(drugCacheEntity, reqContext, DrugType.Manufactured);
            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugSaveCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            ManufacturedDrugModelV2 manufacturerDrug = (ManufacturedDrugModelV2)result.Item2;
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(manufacturerDrug.DrugId, "formularyId/123456789");
            Assert.AreEqual(manufacturerDrug.Name, "BrandName");
            Assert.AreEqual(manufacturerDrug.ManufacturerName, "ManufacturerName");
            Assert.AreEqual(manufacturerDrug.ManufacturerId, "123456789");
            Assert.AreEqual(manufacturerDrug.FormularyDrugId, "formularyId");
            Assert.AreEqual(manufacturerDrug.Origin, "UI");
            Assert.AreEqual(manufacturerDrug.Identifiers.Count, 1);
            Assert.AreEqual(manufacturerDrug.Identifiers[0].Type, "NDC");
            Assert.AreEqual(manufacturerDrug.Identifiers[0].Identifier, "123456789");
        }

        [TestMethod]
        public void HandleAsyncForUpdatePackageTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Update
            };
            DrugCacheDataEntity? drugCacheEntity = new(packagedDrugModelV2);
            DrugSaveCommand drugSaveCommand = new(drugCacheEntity, reqContext, DrugType.Packaged);
            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugSaveCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            PackagedDrugModelV2 packagedDrug = (PackagedDrugModelV2)result.Item2;
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(packagedDrug.DrugId, "formularyId/123456789/Each");
            Assert.AreEqual(packagedDrug.Name, "Each");
            Assert.AreEqual(packagedDrug.PackageId, "Each");
            Assert.AreEqual(packagedDrug.ManufacturedDrugId, "formularyId/123456789");
            Assert.AreEqual(packagedDrug.Origin, "UI");
            Assert.AreEqual(packagedDrug.Identifiers.Count, 1);
            Assert.AreEqual(packagedDrug.Identifiers[0].Type, "BARCODE");
            Assert.AreEqual(packagedDrug.Identifiers[0].Identifier, "987654321");
        }

        [TestMethod]
        public void HandleAsyncForDeleteFormularyTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Delete
            };
            DrugDeleteCommand drugDeleteCommand = new("drug", reqContext, null);

            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugDeleteCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(result.Item2, string.Empty);
        }

        [TestMethod]
        public void HandleAsyncForDeleteFormularyAndChildTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new(){ RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Delete
            };
            DrugDeleteCommand drugDeleteCommand = new("drug1", reqContext, null);

            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugDeleteCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(result.Item2, string.Empty);
        }

        [TestMethod]
        public void HandleAsyncForDeleteFormularyAndChildsTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Delete
            };
            DrugDeleteCommand drugDeleteCommand = new("drug2", reqContext, null);

            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugDeleteCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(result.Item2, string.Empty);
        }

        [TestMethod]
        public void HandleAsyncForDeleteManufacturerTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Delete
            };
            DrugDeleteCommand drugDeleteCommand = new("drug1/NDC1", reqContext, null);

            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugDeleteCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(result.Item2, string.Empty);
        }

        [TestMethod]
        public void HandleAsyncForDeletePackageTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Delete
            };
            DrugDeleteCommand drugDeleteCommand = new("drug2/NDC2/BARCODE", reqContext, null);

            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugDeleteCommand).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(result.Item2, string.Empty);
        }

        [TestMethod]
        public void HandleAsyncForAddManufacturerAndPackagesTest()
        {
            ManufacturedDrugModelV2 localManufacturedDrugModelV2 = new()
            {
                DrugId = "drug5/9123456789",
                ManufacturerId = "9123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "drug5",
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "NDC", Identifier = "9123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            PackagedDrugModelV2 localPackagedDrugModelV2 = new()
            {
                DrugId = "drug5/9123456789/Each",
                ManufacturedDrugId = "drug5/9123456789",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "BARCODE", Identifier = "9987654321", Status = Swisslog.Base.Api.IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Add
            };
            DrugCacheDataEntity? drugCacheEntityForM = new(localManufacturedDrugModelV2);
            DrugSaveCommand drugSaveCommandForM = new(drugCacheEntityForM, reqContext, DrugType.Manufactured);
            DrugCacheDataEntity? drugCacheEntityForP = new(localPackagedDrugModelV2);
            DrugSaveCommand drugSaveCommandForP = new(drugCacheEntityForP, reqContext, DrugType.Packaged);
            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugSaveCommandForM, new List<DrugSaveCommand>() { drugSaveCommandForP}).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Item1, false);
        }

        [TestMethod]
        public void HandleAsyncForUpdateManufacturerAndPackagesTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Add
            };
            DrugCacheDataEntity? drugCacheEntityForM = new(manufacturedDrugModelV2);
            DrugSaveCommand drugSaveCommandForM = new(drugCacheEntityForM, reqContext, DrugType.Manufactured);
            DrugCacheDataEntity? drugCacheEntityForP = new(packagedDrugModelV2);
            DrugSaveCommand drugSaveCommandForP = new(drugCacheEntityForP, reqContext, DrugType.Packaged);
            //Act
            Tuple<bool, object>? result = drugCommand?.HandleAsync(drugSaveCommandForM, new List<DrugSaveCommand>() { drugSaveCommandForP }).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(result.Item2, string.Empty);
        }

        [TestMethod]
        public void PushDrugsToWM6Test()
        {
            //Act
            List<string>? result = drugCommand?.PushDrugsToWM6().Result;

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Count, 1);
            Assert.AreEqual(result[0], "drug");
        }

        [TestMethod]
        public void HandleKafkaAsyncTest()
        {
            Guid correlationId = Guid.NewGuid();
            DateTime time = DateTime.UtcNow;
            ClientInfo? clientInfo = new() { RemoteIpAddress = remoteIp, LocalIpAddress = localIp };
            RequestContext? reqContext = new()
            {
                CorrelationId = correlationId,
                UserId = user,
                TimestampUtc = time,
                ClientInfo = clientInfo,
                RequestAction = RequestType.Add
            };

            BarcodeIdentifierModelV2 barcodeIdentifierModelV2 = new()
            {
                DrugId = "formularyId/NDCValue/BarcodeValue",
                Type = "BARCODE",
                Identifier = "BarcodeValue",
                Status = Swisslog.Base.Api.IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin"
            };

            //Act
            Tuple<bool, object>? result = drugCommand?.HandleKafkaAsync(barcodeIdentifierModelV2, reqContext).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Item1, true);
            Assert.AreEqual(result.Item2, string.Empty);
        }

        [TestMethod]
        public void HandleAsyncTest()
        {
            DrugEntity entityFData = new() { Id = Guid.NewGuid(), DrugId = "formularyId", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2!), IsDeleted = false, Version = 0 };

            bool? result = drugCommand?.HandleAsync(entityFData).Result;
            Assert.IsNotNull(result);
            Assert.IsTrue(result);
        }
        #endregion

        #region CleanUp
        public void TestCleanUp()
        {
            drugCommand = null;
        }
        #endregion
    }

    public class TestingQueryable<T> : IQueryable<T>
    {
        private readonly IQueryable<T> _queryable;

        public TestingQueryable(IQueryable<T> queryable)
        {
            _queryable = queryable;
            Provider = new TestingQueryProvider<T>(_queryable);
        }

        public Type ElementType => _queryable.ElementType;

        public Expression Expression => _queryable.Expression;

        public IQueryProvider Provider { get; }

        public IEnumerator<T> GetEnumerator()
        {
            return _queryable.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return _queryable.GetEnumerator();
        }
    }

    public class TestingQueryProvider<T> : INhQueryProvider
    {
        public TestingQueryProvider(IQueryable<T> source)
        {
            Source = source;
        }

        public IQueryable<T> Source { get; set; }

        public IQueryable CreateQuery(Expression expression)
        {
            throw new NotImplementedException();
        }

        public IQueryable<TElement> CreateQuery<TElement>(Expression expression)
        {
            return new TestingQueryable<TElement>(Source.Provider.CreateQuery<TElement>(expression));
        }

        public object Execute(Expression expression)
        {
            throw new NotImplementedException();
        }

        public TResult Execute<TResult>(Expression expression)
        {
            return Source.Provider.Execute<TResult>(expression);
        }

        public Task<TResult> ExecuteAsync<TResult>(Expression expression, CancellationToken cancellationToken)
        {
            return Task.FromResult(Execute<TResult>(expression));
        }

        public int ExecuteDml<T1>(QueryMode queryMode, Expression expression)
        {
            throw new NotImplementedException();
        }

        public Task<int> ExecuteDmlAsync<T1>(QueryMode queryMode, Expression expression, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public IFutureEnumerable<TResult> ExecuteFuture<TResult>(Expression expression)
        {
            throw new NotImplementedException();
        }

        public IFutureValue<TResult> ExecuteFutureValue<TResult>(Expression expression)
        {
            throw new NotImplementedException();
        }

        public void SetResultTransformerAndAdditionalCriteria(IQuery query, NhLinqExpression nhExpression, IDictionary<string, Tuple<object, IType>> parameters)
        {
            throw new NotImplementedException();
        }
    }
}
