﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Drug;
using Drug.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NHibernate;
using Swisslog.Drug.Api;

namespace DrugTest.Service
{
    [TestClass]
    public class DrugServiceTest
    {
        DrugService? drugService;
        Dictionary<string, string[]>? qryParams;
        BarcodeIdentifierSearchParam? barcodeIdentifierSearchParam;
        private readonly System.Guid drugEntityId = System.Guid.NewGuid();
        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            //Arrange
            ILogger<DrugService> _logDrugService = Mock.Of<ILogger<DrugService>>();
            HttpClient _client = Mock.Of<HttpClient>();
            IWebHostEnvironment _env = Mock.Of<IWebHostEnvironment>();
            Mock<IConfiguration> mockConfig = new();
            ILogger<DrugQueryProcessor> logDrugQueryProcessor = Mock.Of<ILogger<DrugQueryProcessor>>();
            ILogger<HazardousTypeQueryProcessor> logHazardousTypeQueryProcessor = Mock.Of<ILogger<HazardousTypeQueryProcessor>>();
            ILogger<DrugIdentifierQueryProcessor> logDrugIdentifierQueryProcessor = Mock.Of<ILogger<DrugIdentifierQueryProcessor>>();
            HttpClient client = Mock.Of<HttpClient>();
            Mock<LocationRestClient> mockLocationRestClient = new(client, mockConfig.Object);
            HttpResponseMessage httpResponseMessageForLocation = new()
            {
                StatusCode = System.Net.HttpStatusCode.OK,
                Content = new StringContent(Controller.TestData.locationContent, System.Text.Encoding.UTF8, "application/json")
            };

            mockLocationRestClient.Setup(x => x.GetLocations().Result).Returns(httpResponseMessageForLocation);

            Mock<LocationService> mockLocationService = new(new Mock<ILogger<LocationService>>().Object,
                mockLocationRestClient.Object);
            Mock<DrugCache> mockCache = new(new Mock<ISessionFactory>().Object, new Mock<ILogger<DrugCache>>().Object);
            mockCache.Setup(x => x.LoadDrugCache()).Verifiable();
            Mock<DrugQueryProcessor> mockDrugQueryProcessor = new(mockCache.Object, logDrugQueryProcessor, mockLocationService.Object);
            Mock<HazardousTypeQueryProcessor> mockHazardousTypeQueryProcessor = new(mockCache.Object, logHazardousTypeQueryProcessor);
            Mock<DrugIdentifierQueryProcessor> mockDrugIdentifierQueryProcessor = new(mockCache.Object, logDrugIdentifierQueryProcessor);
            qryParams = new()
            {
                { "locations", new string[] { "locations" } },
                { "status", new string[] { "Active" } },
                { "enablesecondcheck", new string[] { "false" } },
                { "_pagesize", new string[] { "0" } },
                { "_page", new string[] { "0" } },
                { "sortby", new string[] { "name" } },
                { "sortorder", new string[] { "asc" } }
            };
            Dictionary<string, FormularyLocationSettingsModelV2> locations = new()
            {
                ["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active },
                ["locations"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active }
            };

            Dictionary<string, FormularyLocationSettingsModelV2> locations2 = new()
            {
                ["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Obsolete },
                ["locations"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Obsolete }
            };


            FormularyDrugQryModelV2 formularyDrugQryModelV2 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                FormNormalized = new List<string> { "TABLET", "PILL" },
                Locations = locations
            };
            FormularyDrugModelV2 formularyDrugModelV2 = new()
            {
                DrugId = "drug2",
                Name = "drug2 name",
                Strength = "10",
                Volume = "mg",
                Locations = locations2
            };
            List<FormularyDrugQryModelV2> formularyDrugQryModelV2s1 = new()
            {
                formularyDrugQryModelV2
            };
            IEnumerable<FormularyDrugQryModelV2> formularyDrugQryModelV2s = formularyDrugQryModelV2s1.AsEnumerable();

            DrugLocationSettingsModelV2 drugLocationSettingsModelV2 = new()
            {
                DrugId = "drug",
                Form = "TABLET",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                FormNormalized = new List<string> { "TABLET", "PILL" },
                Locations = locations
            };

            List<DrugLocationSettingsModelV2> listOfDrugLocationSettingsModelV2 = new()
            {
                drugLocationSettingsModelV2
            };

            IdentifierDrugModelV2 identifierDrugModelV2 = new()
            {
                ItemId = "drug/formularyId/NDCValue/BarcodeValue",
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() { new Swisslog.Base.Api.IdentifierV2()
                { Type = "NDC", Identifier = "NDCValue" }, new Swisslog.Base.Api.IdentifierV2()
                { Type = "BARCODE", Identifier = "BarcodeValue", Status = Swisslog.Base.Api.IdentifierStatus.APPROVED }
                },
                Unit = "Each"
            };
            List<IdentifierDrugModelV2> listOfIdentifierDrugModelV2 = new()
            {
                identifierDrugModelV2
            };
            IEnumerable<IdentifierDrugModelV2> identifierDrugModelV2s = listOfIdentifierDrugModelV2.AsEnumerable();

            BarcodeIdentifierModelV2 barcodeIdentifierModelV2 = new()
            {
                DrugId = "formularyId/NDCValue/BarcodeValue",
                Type = "BARCODE",
                Identifier = "BarcodeValue",
                Status = Swisslog.Base.Api.IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin"
            };
            List<BarcodeIdentifierModelV2> listOfBarcodeIdentifierModelV2 = new()
            {
                barcodeIdentifierModelV2
            };
            IEnumerable<BarcodeIdentifierModelV2> barcodeIdentifierModelV2s = listOfBarcodeIdentifierModelV2.AsEnumerable();
            barcodeIdentifierSearchParam = new BarcodeIdentifierSearchParam { Facility = "facility" };

            Dictionary<string, string> operationNotices = new()
            {
                { "dispense", "dispensed" }
            };
            HazardousDrugTypeModelV2 hazardousDrugTypeModelV2 = new()
            {
                OperationNotice = operationNotices,
                Description = "Description",
                HazardousDrugTypeId = HazardousTypes.GROUP_1,
                IsDeleted = false
            };

            List<HazardousDrugTypeModelV2> listOfHazardousDrugTypeModelV2 = new()
            {
                hazardousDrugTypeModelV2
            };
            IEnumerable<HazardousDrugTypeModelV2> hazardousDrugTypeModelV2s = listOfHazardousDrugTypeModelV2.AsEnumerable();

            Drug.Data.DrugCacheDataEntity drugCacheDataEntity = new()
            {
                DrugId = "drug",
                DrugEntityId = drugEntityId,
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string> { "GROUP_1" }
            };

            Drug.Data.DrugCacheDataEntity drugCacheDataEntity2 = new(formularyDrugModelV2, "")
            {
                DrugId = "drug2",
                DrugEntityId = drugEntityId,
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug2",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" }
            };

            List<Drug.Data.DrugCacheDataEntity> listOfDrugCacheEntity = new()
            {
                drugCacheDataEntity
            };

            List<Drug.Data.DrugCacheDataEntity> listOfDrugCacheEntity2 = new()
            {
                drugCacheDataEntity2
            };

            Dictionary<string, QuantityDetails> dicQtyDetails = new()
            {
                { "drug/drug", new QuantityDetails { QuantityAvailable = 30, QuantityOnHand = 40 } }
            };

            mockDrugQueryProcessor.Setup(x => x.HandleAsync("drug", "locations", true).Result).Returns(listOfDrugLocationSettingsModelV2);
            mockDrugQueryProcessor.Setup(x => x.HandleAsync("drug").Result).Returns(formularyDrugQryModelV2);
            mockDrugQueryProcessor.Setup(x => x.HandleAsync(qryParams).Result).Returns(formularyDrugQryModelV2s);
            mockDrugQueryProcessor.Setup(x => x.GetFormularyPreferredSettings("accountId", "supplierId").Result).Returns(listOfDrugCacheEntity);
            mockDrugQueryProcessor.Setup(x => x.GetFormularyDataEntity().Result).Returns(listOfDrugCacheEntity2);
            mockDrugQueryProcessor.Setup(x => x.HandleBarcodeIdentifierAsync(barcodeIdentifierSearchParam, qryParams).Result).Returns(barcodeIdentifierModelV2s);
            mockDrugIdentifierQueryProcessor.Setup(x => x.HandleAsync("drug/formularyId/NDCValue/BarcodeValue", qryParams).Result).Returns(identifierDrugModelV2s);
            mockHazardousTypeQueryProcessor.Setup(x => x.HandleAsync("hazardousDrugTypeId").Result).Returns(hazardousDrugTypeModelV2);
            mockHazardousTypeQueryProcessor.Setup(x => x.HandleAsync(qryParams).Result).Returns(hazardousDrugTypeModelV2s);
            mockLocationService.Setup(x => x.GetQuantities(new string[] { "drug/drug" }, "locations").Result).Returns(dicQtyDetails);
            //Act
            drugService = new DrugService(mockDrugQueryProcessor.Object, mockHazardousTypeQueryProcessor.Object, mockDrugIdentifierQueryProcessor.Object, _logDrugService, mockLocationService.Object);
        }
        #endregion

        #region Method
        [TestMethod]
        public void GetQueryDrugIdsTest()
        {
            //Act            
            List<string>? listOfDrugs = drugService?.QueryDrugIds(qryParams!).Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            Assert.AreEqual(listOfDrugs.Count, 1);
            Assert.AreEqual(listOfDrugs[0], "drug");
        }

        [TestMethod]
        public void GetDrugByPreferredSettingTest()
        {
            //Act            
            List<Drug.Data.DrugCacheDataEntity>? result = drugService?.GetDrugByPreferredSetting("accountId", "supplierId").Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Count, 1);
            Assert.AreEqual(result?[0]?.HasDrugInfo, true);
            Assert.AreEqual(result?[0]?.DrugId, "drug");
            Assert.AreEqual(result?[0]?.DrugEntityId, drugEntityId);
            Assert.AreEqual(result?[0]?.DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(result?[0]?.Id, "drug");
            Assert.AreEqual(result?[0]?.IsActive, true);
            Assert.AreEqual(result?[0]?.Origin, "UI");
            Assert.AreEqual(result?[0]?.HazardousTypes?[0], "GROUP_1");
        }

        [TestMethod]
        public void QueryDrugIdsTest()
        {
            //Act            
            List<string>? listOfDrugs = drugService?.QueryDrugIds(qryParams!).Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            Assert.AreEqual(listOfDrugs.Count, 1);
            Assert.AreEqual(listOfDrugs[0], "drug");
        }

        [TestMethod]
        public void QueryDrugsTest()
        {
            //Act
            Swisslog.Base.Api.Page<FormularyDrugQryModelV2>? listOfDrugs = drugService?.QueryDrugs(qryParams!).Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            Assert.AreEqual(listOfDrugs?.Total, 1);
            Assert.AreEqual(listOfDrugs?.Data?.Count, 1);
            Assert.AreEqual(listOfDrugs?.Data![0].DrugId, "drug");
            Assert.AreEqual(listOfDrugs?.Data![0].Name, "drug name");
            Assert.AreEqual(listOfDrugs?.Data![0].Strength, "10");
            Assert.AreEqual(listOfDrugs?.Data![0].Volume, "mg");
            Assert.AreEqual(listOfDrugs?.Data![0]?.FormNormalized?.Count, 2);
            Assert.AreEqual(listOfDrugs?.Data![0]?.FormNormalized?[0], "TABLET");
            Assert.AreEqual(listOfDrugs?.Data![0]?.FormNormalized?[1], "PILL");

        }

        [TestMethod]
        public void GetDrugByUniqueIdTest()
        {
            //Act            
            FormularyDrugQryModelV2? drug = drugService?.GetDrugByUniqueId("drug").Result;
            //Assert
            Assert.IsNotNull(drug);
            Assert.AreEqual(drug.DrugId, "drug");
            Assert.AreEqual(drug.Name, "drug name");
            Assert.AreEqual(drug.Strength, "10");
            Assert.AreEqual(drug.Volume, "mg");
            Assert.AreEqual(drug?.FormNormalized?.Count, 2);
            Assert.AreEqual(drug?.FormNormalized?[0], "TABLET");
            Assert.AreEqual(drug?.FormNormalized?[1], "PILL");
        }

        [TestMethod]
        public void GetDrugLocationSettingsByUniqueIdsTest()
        {
            //Act            
            Swisslog.Base.Api.Page<DrugLocationSettingsModelV2>? listOfDrugLS = drugService?.GetDrugLocationSettingsByUniqueIds("drug", "locations", true, qryParams!).Result;
            //Assert
            Assert.IsNotNull(listOfDrugLS);
            Assert.AreEqual(listOfDrugLS?.Total, 1);
            Assert.AreEqual(listOfDrugLS?.Data?.Count, 1);
            Assert.AreEqual(listOfDrugLS?.Data![0].DrugId, "drug");
            Assert.AreEqual(listOfDrugLS?.Data![0].Name, "drug name");
            Assert.AreEqual(listOfDrugLS?.Data![0].Strength, "10");
            Assert.AreEqual(listOfDrugLS?.Data![0].Volume, "mg");
            Assert.AreEqual(listOfDrugLS?.Data![0].Form, "TABLET");
            Assert.AreEqual(listOfDrugLS?.Data![0]?.FormNormalized?.Count, 2);
            Assert.AreEqual(listOfDrugLS?.Data![0]?.FormNormalized?[0], "TABLET");
            Assert.AreEqual(listOfDrugLS?.Data![0]?.FormNormalized?[1], "PILL");
            Assert.AreEqual(listOfDrugLS?.Data![0]?.Locations?.Count, 2);
            Assert.AreEqual(listOfDrugLS?.Data![0]?.Locations!["locations"].Formulary, true);
            Assert.AreEqual(listOfDrugLS?.Data![0]?.Locations!["locations"].Status, LocationSettingsStatus.Active);
        }

        [TestMethod]
        public void QueryDrugIdentifiersTest()
        {
            //Act            
            IEnumerable<IdentifierDrugModelV2>? result = drugService?.QueryDrugIdentifiers("drug/formularyId/NDCValue/BarcodeValue", qryParams!).Result;
            //Assert
            Assert.IsNotNull(result);
            List<IdentifierDrugModelV2>? list = result.ToList();
            Assert.AreEqual(list.Count, 1);
            Assert.AreEqual(list[0].Identifiers.Count, 2);
            Assert.AreEqual(list[0].ItemId, "drug/formularyId/NDCValue/BarcodeValue");
            Assert.AreEqual(list[0].Unit, "Each");
            Assert.AreEqual(list[0].Identifiers[0].Type, "NDC");
            Assert.AreEqual(list[0].Identifiers[0].Identifier, "NDCValue");
            Assert.AreEqual(list[0].Identifiers[1].Type, "BARCODE");
            Assert.AreEqual(list[0].Identifiers[1].Identifier, "BarcodeValue");
            Assert.AreEqual(list[0].Identifiers[1].Status, Swisslog.Base.Api.IdentifierStatus.APPROVED);
        }

        [TestMethod]
        public void QueryBarcodeIdentifiersTest()
        {
            //Act            
            Swisslog.Base.Api.Page<BarcodeIdentifierModelV2>? result = drugService?.QueryBarcodeIdentifiers(barcodeIdentifierSearchParam!, qryParams!).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result?.Total, 1);
            Assert.AreEqual(result?.Data?.Count, 1);
            Assert.AreEqual(result?.Data![0].DrugId, "formularyId/NDCValue/BarcodeValue");
            Assert.AreEqual(result?.Data![0].Type, "BARCODE");
            Assert.AreEqual(result?.Data![0].Identifier, "BarcodeValue");
            Assert.AreEqual(result?.Data![0].Status, Swisslog.Base.Api.IdentifierStatus.APPROVED);
            Assert.AreEqual(result?.Data![0].LastModifiedBy, "systemadmin");

        }

        [TestMethod]
        public void GetHazardousTypesByUniqueIdTest()
        {
            //Act            
            HazardousDrugTypeModelV2? result = drugService?.GetHazardousTypesByUniqueId("hazardousDrugTypeId").Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.HazardousDrugTypeId, HazardousTypes.GROUP_1);
            Assert.AreEqual(result.Description, "Description");
            Assert.AreEqual(result.IsDeleted, false);
            Assert.AreEqual(result.OperationNotice?.Count, 1);
            Assert.AreEqual(result.OperationNotice?["dispense"], "dispensed");
        }

        [TestMethod]
        public void QueryHazardousTypesTest()
        {
            //Act            
            Swisslog.Base.Api.Page<HazardousDrugTypeModelV2>? result = drugService?.QueryHazardousTypes(qryParams!).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result?.Total, 1);
            Assert.AreEqual(result?.Data?.Count, 1);
            Assert.AreEqual(result?.Data![0].HazardousDrugTypeId, HazardousTypes.GROUP_1);
            Assert.AreEqual(result?.Data![0].Description, "Description");
            Assert.AreEqual(result?.Data![0].IsDeleted, false);
            Assert.AreEqual(result?.Data![0].OperationNotice?.Count, 1);
            Assert.AreEqual(result?.Data![0].OperationNotice?["dispense"], "dispensed");
        }

        [TestMethod]
        public void GetExportDrugTest()
        {
            //Act 
            var memory = drugService?.GetExportDrug(qryParams!).Result;
            //Assert
            Assert.IsNotNull(memory);
            Assert.IsNotNull(memory.Length);
            Assert.IsTrue(memory.Length > 4000);
        }

        [TestMethod]
        public void GetFormularyDrugEntityTest()
        {
            //Act            
            List<Drug.Data.DrugCacheDataEntity>? result = drugService?.GetFormularyDrugEntity().Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Count, 1);
            Assert.AreEqual(result?[0]?.HasDrugInfo, true);
            Assert.AreEqual(result?[0]?.DrugId, "drug2");
            Assert.AreEqual(result?[0]?.DrugEntityId, drugEntityId);
            Assert.AreEqual(result?[0]?.DrugEntityType, DrugType.Formulary);
            Assert.AreEqual(result?[0]?.Id, "drug2");
            Assert.AreEqual(result?[0]?.IsActive, true);
            Assert.AreEqual(result?[0]?.Origin, "UI");
            Assert.AreEqual(result?[0]?.HazardousTypes?.Count, 1);
            Assert.AreEqual(result?[0]?.Locations?.Count, 2);
            Assert.AreEqual(result?[0]?.Locations?["root"].Formulary, true);
            Assert.AreEqual(result?[0]?.Locations?["root"].Status, LocationSettingsStatus.Obsolete);
            Assert.AreEqual(result?[0]?.Locations?["locations"].Formulary, true);
            Assert.AreEqual(result?[0]?.Locations?["locations"].Status, LocationSettingsStatus.Obsolete);
        }

        #endregion

        #region CleanUp

        [TestCleanup]
        public void TestCleanUp()
        {
            drugService = null;
        }
        #endregion
    }
}
