﻿using Drug.Data;
using Drug.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NHibernate;
using Swisslog.Drug.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

namespace DrugTest.Service
{
    [TestClass]
    public class DrugSyncServiceAdapterTest
    {
        DrugSyncServiceAdapter? drugSyncServiceAdapter;
        FormularyDrugModelV2? formularyDrugModelV2;
        ManufacturedDrugModelV2? manufacturedDrugModelV2;
        PackagedDrugModelV2? packagedDrugModelV2;
        Mock<DrugSyncRestClient>? mockDrugSyncRestClient;
        Dictionary<string, string[]>? qryParams;
        readonly Dictionary<string, FormularyLocationSettingsModelV2> locations = new();

        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            //Arrange
            ILogger<DrugSyncServiceAdapter> logDrugSyncServiceAdapter = Mock.Of<ILogger<DrugSyncServiceAdapter>>();
            HttpClient client = Mock.Of<HttpClient>();
            IWebHostEnvironment _env = Mock.Of<IWebHostEnvironment>();
            Mock<IConfiguration> mockConfig = new();
            Mock<IConfigurationSection> mockConfigurationSection = new();
            mockConfig.Setup(a => a.GetSection("kafka:producer")).Returns(mockConfigurationSection.Object);
            ILogger<DrugQueryProcessor> logDrugQueryProcessor = Mock.Of<ILogger<DrugQueryProcessor>>();
            Mock<LocationService> mockLocationService = new(new Mock<ILogger<LocationService>>().Object,
                new Mock<LocationRestClient>(client, mockConfig.Object).Object);
            Mock<DrugCache> mockCache = new(new Mock<ISessionFactory>().Object, new Mock<ILogger<DrugCache>>().Object);
            mockCache.Setup(x => x.LoadDrugCache()).Verifiable();
            Mock<DrugQueryProcessor> mockDrugQueryProcessor = new(mockCache.Object, logDrugQueryProcessor, mockLocationService.Object);

            Mock<ILogger<DrugSyncRestClient>> mockDrugServiceLogger = new();
            mockDrugSyncRestClient = new Mock<DrugSyncRestClient>(client, mockConfig.Object, mockDrugServiceLogger.Object);
            qryParams = new();
            qryParams.Add("locations", new string[] { "locations" });
            qryParams.Add("status", new string[] { "Active" });
            qryParams.Add("enablesecondcheck", new string[] { "false" });

            locations["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active };
            locations["locations"] = new FormularyLocationSettingsModelV2
            {
                Formulary = true,
                Status = LocationSettingsStatus.Active,
                RequireExpiryDate = true,
                RequireLotCode = true,
                PreferLocalDispense = true,
                RequireSerialNumber = true,
                PreferredAccount = new PreferredAccountModelV2 { AccountId = "accountId", SupplierId = "supplierId" }
            };

            formularyDrugModelV2 = new FormularyDrugModelV2
            {
                DrugId = "formularyId",
                Name = "formulary name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                TemperatureClass = TemperatureClass.ROOM,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0,
                LastModified = DateTime.UtcNow
            };
            manufacturedDrugModelV2 = new ManufacturedDrugModelV2
            {
                DrugId = "formularyId/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "formularyId",
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI",
                LastModified = DateTime.UtcNow
            };
            packagedDrugModelV2 = new PackagedDrugModelV2
            {
                DrugId = "formularyId/123456789/Each",
                ManufacturedDrugId = "formularyId/123456789",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<Swisslog.Base.Api.IdentifierV2>() {
                    new Swisslog.Base.Api.IdentifierV2 {
                        Type = "BARCODE", Identifier = "987654321", Status = Swisslog.Base.Api.IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI",
                LastModified = DateTime.UtcNow
            };

            DrugEntity entityFData = new DrugEntity() { Id = Guid.NewGuid(), DrugId = "formularyId", DrugInfo = DrugUtility<string>.DrugToString(formularyDrugModelV2), IsDeleted = false, Version = 0, LastModificationDateUtc = DateTime.UtcNow };
            DrugEntity entityMData = new DrugEntity() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789", DrugInfo = DrugUtility<string>.DrugToString(manufacturedDrugModelV2), IsDeleted = false, Version = 0, LastModificationDateUtc = DateTime.UtcNow };
            DrugEntity entityPData = new DrugEntity() { Id = Guid.NewGuid(), DrugId = "formularyId/123456789/Each", DrugInfo = DrugUtility<string>.DrugToString(packagedDrugModelV2), IsDeleted = false, Version = 0, LastModificationDateUtc = DateTime.UtcNow };
            List<DrugEntity> drugList = new List<DrugEntity>() { entityFData, entityMData, entityPData };

            DrugSyncEntity drugSyncEntity = new() { Id = Guid.NewGuid(), LastUpdatedDrug = Convert.ToDateTime("2021-12-01"), LastUpdatedWM6 = Convert.ToDateTime("2021-12-02") };

            FormularyDrugQryModelV2 formularyDrugQryModelV2 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Locations = locations
            };
            mockDrugQueryProcessor.Setup(x => x.HandleAsync(It.IsAny<string>()).Result).Returns(formularyDrugQryModelV2);
            List<FormularyDrugQryModelV2> formularyDrugQryModelV2s1 = new();
            formularyDrugQryModelV2s1.Add(formularyDrugQryModelV2);
            IEnumerable<FormularyDrugQryModelV2> formularyDrugQryModelV2s = formularyDrugQryModelV2s1.AsEnumerable();


            IHttpContextAccessor httpContextAccessor = Mock.Of<IHttpContextAccessor>();
            Mock<ISessionFactory> mockSessionFactory = new Mock<NHibernate.ISessionFactory>();
            Mock<NHibernate.ISession> mockSession = new Mock<NHibernate.ISession>();
            Mock<IQuery> queryMock = new Mock<IQuery>();
            Mock<ITransaction> mockTransaction = new Mock<ITransaction>();
            Mock<IStatelessSession> mockStateSession = new Mock<IStatelessSession>();
            mockSessionFactory.Setup(x => x.OpenStatelessSession()).Returns(mockStateSession.Object);
            mockSessionFactory.Setup(x => x.OpenSession()).Returns(mockSession.Object);
            mockSession.Setup(x => x.BeginTransaction()).Returns(mockTransaction.Object);
            mockStateSession.Setup(x => x.BeginTransaction()).Returns(mockTransaction.Object);
            mockSession.Setup(x => x.Dispose());
            mockSessionFactory.Setup(x => x.Dispose());
            mockTransaction.Setup(x => x.Commit());
            mockTransaction.Setup(x => x.Dispose());
            mockStateSession.Setup(x => x.Dispose());

            mockTransaction.Setup(x => x.Commit()).Verifiable();
#pragma warning disable CS0618 // Type or member is obsolete
            mockSession.SetupGet(x => x.Transaction).Returns(mockTransaction.Object);
            mockStateSession.SetupGet(x => x.Transaction).Returns(mockTransaction.Object);
#pragma warning restore CS0618 // Type or member is obsolete
            mockSession.Setup(session => session.CreateQuery("from drugs")).Returns(queryMock.Object);
            mockSession.Setup(session => session.Query<DrugEntity>()).Returns(new TestingQueryable<DrugEntity>(drugList.AsQueryable()));
            mockStateSession.Setup(session => session.Query<DrugEntity>()).Returns(new TestingQueryable<DrugEntity>(drugList.AsQueryable()));
            queryMock.Setup(x => x.List<DrugEntity>()).Returns(drugList);
            mockDrugQueryProcessor.Setup(x => x.HandleAsync(It.IsAny<Dictionary<string, string[]>>()).Result).Returns(formularyDrugQryModelV2s);
            //Act
            drugSyncServiceAdapter = new DrugSyncServiceAdapter(mockDrugQueryProcessor.Object,
                logDrugSyncServiceAdapter, mockDrugSyncRestClient.Object, mockSessionFactory.Object, mockCache.Object);
        }
        #endregion

        [TestMethod]
        public void PushFormularyDrugTest()
        {
            System.Net.HttpStatusCode response = System.Net.HttpStatusCode.Created;

            mockDrugSyncRestClient?.Setup(x => x.PostDrugUpdate(It.IsAny<FormularyDrugQryModelV2>()).Result).Returns(response);

            bool? result = drugSyncServiceAdapter?.PushFormularyDrug("drug", Convert.ToDateTime("2021-12-01")).Result;
            Assert.IsNotNull(result);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void PushFormularyDrugFalseTest()
        {
            System.Net.HttpStatusCode response = System.Net.HttpStatusCode.BadRequest;

            mockDrugSyncRestClient?.Setup(x => x.PostDrugUpdate(It.IsAny<FormularyDrugQryModelV2>()).Result).Returns(response);

            bool? result = drugSyncServiceAdapter?.PushFormularyDrug("drug", Convert.ToDateTime("2021-12-01")).Result;
            Assert.IsNotNull(result);
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void PushDrugsToWM6AsyncTest()
        {
            System.Net.HttpStatusCode response = System.Net.HttpStatusCode.BadRequest;

            mockDrugSyncRestClient?.Setup(x => x.PostDrugUpdate(It.IsAny<FormularyDrugQryModelV2>()).Result).Returns(response);

            List<string>? result = drugSyncServiceAdapter?.PushDrugsToWM6Async().Result;
            Assert.IsNotNull(result);
            Assert.AreEqual(result[0], "drug");
        }

        #region CleanUp
        [TestCleanup]
        public void TestCleanUp()
        {
            drugSyncServiceAdapter = null;
        }
        #endregion
    }
}
