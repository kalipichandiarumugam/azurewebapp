﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Drug.Controllers;

namespace DrugTest.Controller
{
    [TestClass]
    public class RemovePrefixTest
    {
        [TestMethod]
        public void TestItemIdOnly_True()
        {
            // Arrange
            Dictionary<string, string?[]> qryParams = new()
            {
                { "NonsenseKey", new string[] { "one", "two" } },
                { "DrugIds", new string[] { "drug/ItemIdOne/1234567890/PACK", "drug/ItemIdTwo/2342342345/EACH", "ItemIdThree" } }
            };
            // Action
            Dictionary<string, string[]>? UpdatedParams = RemoveDrugPrefix.CheckDrugPrefix(qryParams);
#pragma warning disable CS8620 // Argument cannot be used for parameter due to differences in the nullability of reference types.
            string DisplayString = RemoveDrugPrefix.QryParamsToString(UpdatedParams);
#pragma warning restore CS8620 // Argument cannot be used for parameter due to differences in the nullability of reference types.

            // Assert
            Assert.IsNotNull(UpdatedParams);
            Assert.IsTrue(UpdatedParams["NonsenseKey"].Length == 2);
            Assert.IsTrue(UpdatedParams["DrugIds"].Length == 3);
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("ItemIdOne/1234567890/PACK"));
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("ItemIdTwo/2342342345/EACH"));
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("ItemIdThree"));
            Assert.IsTrue(DisplayString.Contains("Value: ItemIdOne/1234567890/PACK,ItemIdTwo/2342342345/EACH,ItemIdThree"));
            Assert.IsTrue(DisplayString.Contains("Key 'DrugIds':"));
        }
        [TestMethod]
        public void TestBadItemIdOnly_True()
        {
            // Arrange
            Dictionary<string, string?[]> qryParams = new()
            {
                { "NonsenseKey", new string[] { "one", "two" } },
                { "DrugIds", new string[] { "dRuG/ItemIdOne/1234567890/PACK", "DrUG/ItemIdTwo/2342342345/EACH", "Drug/", "Drug//" } }
            };
            // Action
            Dictionary<string, string[]>? UpdatedParams = RemoveDrugPrefix.CheckDrugPrefix(qryParams);
            // Assert
            Assert.IsNotNull(UpdatedParams);
            Assert.IsTrue(UpdatedParams["NonsenseKey"].Length == 2);
            Assert.IsTrue(UpdatedParams["DrugIds"].Length == 2);
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("ItemIdOne/1234567890/PACK"));
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("ItemIdTwo/2342342345/EACH"));
            Assert.IsFalse(UpdatedParams["DrugIds"].Contains<string>("Drug"));
            Assert.IsFalse(UpdatedParams["DrugIds"].Contains<string>("Drug/"));
            Assert.IsFalse(UpdatedParams["DrugIds"].Contains<string>("Drug//"));
            Assert.IsFalse(UpdatedParams["DrugIds"].Contains<string>("/"));
        }
        [TestMethod]
        public void TestBadLeadingSlashOnly_True()
        {
            // Arrange
            Dictionary<string, string?[]> qryParams = new()
            {
                { "NonsenseKey", new string[] { "one", "two" } },
                { "DrugIds", new string[] { "/Item1", "Item2/", "item3", "drug/item4" } }
            };
            // Action
            Dictionary<string, string[]>? UpdatedParams = RemoveDrugPrefix.CheckDrugPrefix(qryParams);
            // Assert
            Assert.IsNotNull(UpdatedParams);
            Assert.IsTrue(UpdatedParams["NonsenseKey"].Length == 2);
            Assert.IsTrue(UpdatedParams["DrugIds"].Length == 4);
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("item3"));
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("item4"));
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("Item1"));
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("Item2"));
            Assert.IsFalse(UpdatedParams["DrugIds"].Contains<string>("/Item1"));
            Assert.IsFalse(UpdatedParams["DrugIds"].Contains<string>("Item2/"));

        }
        [TestMethod]
        public void TestWordDrugOnly_True()
        {
            // Arrange
            Dictionary<string, string?[]> qryParams = new()
            {
                { "NonsenseKey", new string[] { "one", "two" } },
                { "DrugIds", new string?[] { "drug", null, string.Empty } },
                { "NullValueKey", new string?[] { null } }
            };
            // Action
            Dictionary<string, string[]>? UpdatedParams = RemoveDrugPrefix.CheckDrugPrefix(qryParams);
            // Assert
            Assert.IsNotNull(UpdatedParams);
            Assert.IsTrue(UpdatedParams["NonsenseKey"].Length == 2);
            Assert.IsTrue(UpdatedParams["DrugIds"].Length == 1);
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("drug"));
            Assert.IsTrue(UpdatedParams["NullValueKey"].Length == 1);

        }
        [TestMethod]
        public void TestLead_Trail_True()
        {
            // Arrange
            Dictionary<string, string?[]> qryParams = new()
            {
                { "NonsenseKey", new string[] { "one", "two" } },
                { "DrugIds", new string?[] { "item1/", "/item2", "/item3/" } },
                { "NullValueKey", new string?[] { null } }
            };
            // Action
            Dictionary<string, string[]>? UpdatedParams = RemoveDrugPrefix.CheckDrugPrefix(qryParams);
            // Assert
            Assert.IsNotNull(UpdatedParams);
            Assert.IsTrue(UpdatedParams["NonsenseKey"].Length == 2);
            Assert.IsTrue(UpdatedParams["DrugIds"].Length == 3);
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("item1"));
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("item2"));
            Assert.IsTrue(UpdatedParams["DrugIds"].Contains<string>("item3"));

            Assert.IsTrue(UpdatedParams["NullValueKey"].Length == 1);

        }
        [TestMethod]
        public void SpecialCasesDrug_True()
        {
            // Arrange

            // Action
            string? DrugV1 = RemoveDrugPrefix.StripPrefix("drug");
            string? DrugV2 = RemoveDrugPrefix.StripPrefix("drug/drug");
            string? DrugV2A = RemoveDrugPrefix.StripPrefix("/drug/drug");
            string? DrugV3 = RemoveDrugPrefix.StripPrefix("drug/drug/1234567891/PACK");
            string? DrugV3A = RemoveDrugPrefix.StripPrefix("/drug/drug/1234567891/PACK");
            // Assert
            Assert.IsNotNull(DrugV1);
            Assert.IsNotNull(DrugV2);
            Assert.IsNotNull(DrugV3);
            Assert.AreEqual(DrugV1, DrugV2);
            Assert.AreEqual(DrugV1, DrugV2A);
            Assert.AreEqual("drug", DrugV1);
            Assert.AreEqual("drug/1234567891/PACK", DrugV3);
            Assert.AreEqual("drug/1234567891/PACK", DrugV3A);
        }
    }
}
