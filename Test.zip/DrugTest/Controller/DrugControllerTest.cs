﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using AutoMapper;
using Drug;
using Drug.Controllers;
using Drug.Data;
using Drug.Models;
using Drug.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NHibernate;
using Swisslog.Base.Api;
using Swisslog.Drug.Api;
using Swisslog.Base.Api.Location;

namespace DrugTest.Controller
{
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning disable CS8602 // Dereference of a possibly null reference.
    [TestClass]
    public class DrugControllerTest
    {
        DrugController? drugController;
        Dictionary<string, string[]>? qryParams;
        UpdatePreferredAccountModelV2? updatePreferredAccountModelV2;
        DrugCacheDataEntity? drugCacheDataEntity;
        FormularyDrugModelV2? formularyDrugModelV2;
        private readonly Guid drugEntityId = Guid.NewGuid();
        Mock<DrugCommand>? mockDrugCommand;
        Tuple<bool, object>? tupleFormulary;
        Tuple<bool, object>? tupleMultipleUserConflict;
        Tuple<bool, object>? tupleInternalServerError;
        LocationSettingsQuery? locationSettingsQryParam;
        BarcodeIdentifierSearchParam? barcodeIdentifierSearchParam;
        private readonly ExportExcelSettingsQuery exportExcelSettingsQuery = new();
        Mock<DrugValidator>? mockDrugValidator;
        Tuple<bool, object>? tupleManufacturer;
        Tuple<bool, object>? tuplePackaged;
        private static IMapper? _mapper;
        ValidationResult? validationResult;
        ManufacturedDrugQryModelV2? manufacturedDrugQryModelV2;
        ManufacturedDrugModelV2? manufacturedDrugModelV2;
        PackagedDrugModelV2? packagedDrugModelV2;
        BarcodeIdentifierModelV2? barcodeIdentifierModelV2;
        public DrugControllerTest()
        {
            if (_mapper == null)
            {
                MapperConfiguration mappingConfig = new(mc =>
                {
                    mc.AddProfile(new MappingManufacturedQryModel());
                });
                IMapper mapper = mappingConfig.CreateMapper();
                _mapper = mapper;
            }
        }

        #region Initialize
        [TestInitialize]
        public void Initialize()
        {
            //Arrange
            ILogger<DrugController> logDrugController = Mock.Of<ILogger<DrugController>>();
            ILogger<DrugService> logDrugService = Mock.Of<ILogger<DrugService>>();
            ILogger<DrugCommand> logDrugCommand = Mock.Of<ILogger<DrugCommand>>();
            ILogger<ProducerService> logProducerService = Mock.Of<ILogger<ProducerService>>();
            ILogger<DrugSyncServiceAdapter> logDrugSyncServiceAdapter = Mock.Of<ILogger<DrugSyncServiceAdapter>>();
            ILogger<DataChangedService> logDataChangedService = Mock.Of<ILogger<DataChangedService>>();
            ILogger<DrugValidator> logDrugValidator = Mock.Of<ILogger<DrugValidator>>();
            ILogger<Data1Service> logData1Service = Mock.Of<ILogger<Data1Service>>();
            ILogger<Data1ServiceRestClient> logData1ServiceRestClient = Mock.Of<ILogger<Data1ServiceRestClient>>();
            ILogger<PreferenceService> logPreferenceService = Mock.Of<ILogger<PreferenceService>>();
            ILogger<PreferenceServiceRestClient> logPreferenceServiceRestClient = Mock.Of<ILogger<PreferenceServiceRestClient>>();
            HttpClient client = Mock.Of<HttpClient>();
            //IMapper mapper = Mock.Of<IMapper>();
            IWebHostEnvironment _env = Mock.Of<IWebHostEnvironment>();
            Mock<IConfiguration> mockConfig = new();
            Mock<IConfigurationSection> mockConfigurationSection = new();
            mockConfig.Setup(a => a.GetSection("kafka:producer")).Returns(mockConfigurationSection.Object);
            ILogger<DrugQueryProcessor> logDrugQueryProcessor = Mock.Of<ILogger<DrugQueryProcessor>>();
            ILogger<HazardousTypeQueryProcessor> logHazardousTypeQueryProcessor = Mock.Of<ILogger<HazardousTypeQueryProcessor>>();
            ILogger<DrugIdentifierQueryProcessor> logDrugIdentifierQueryProcessor = Mock.Of<ILogger<DrugIdentifierQueryProcessor>>();
            Mock<LocationRestClient> mockLocationRestClient = new(client, mockConfig.Object);

            HttpResponseMessage httpResponseMessageForLocation = new()
            {
                StatusCode = System.Net.HttpStatusCode.OK,
                Content = new StringContent(TestData.locationContent, System.Text.Encoding.UTF8, "application/json")
            };
            mockLocationRestClient.Setup(x => x.GetLocations().Result).Returns(httpResponseMessageForLocation);
            Mock<LocationService> mockLocationService = new(new Mock<ILogger<LocationService>>().Object,
                mockLocationRestClient.Object);
            Mock<DrugCache> mockCache = new(new Mock<ISessionFactory>().Object, new Mock<ILogger<DrugCache>>().Object);
            mockCache.Setup(x => x.LoadDrugCache()).Verifiable();

            List<Location> listOfLocation = new()
            {
                new Location { LocationId = "root", Name = "root", ParentId = null },
                new Location { LocationId = "hospital/SWISSLOG-NA-TC", Name = "SWISSLOG-NA-TC", ParentId = "root" },
                new Location { LocationId = "hospital/SWISSLOG-NA-HQ", Name = "SWISSLOG-NA-HQ", ParentId = "root" },
                new Location { LocationId = "facility/SWISSLOG-NA-TC/PHARMACY-SOUTH", Name = "PHARMACY-SOUTH", ParentId = "hospital/SWISSLOG-NA-TC" },
                new Location { LocationId = "facility/SWISSLOG-NA-TC/PHARMACY-NORTH", Name = "PHARMACY-NORTH", ParentId = "hospital/SWISSLOG-NA-TC" },
                new Location { LocationId = "facility/SWISSLOG-NA-HQ/PHARMACY-EAST", Name = "PHARMACY-EAST", ParentId = "hospital/SWISSLOG-NA-HQ" },
                new Location { LocationId = "facility/SWISSLOG-NA-HQ/PHARMACY-WEST", Name = "PHARMACY-WEST", ParentId = "hospital/SWISSLOG-NA-HQ" }
            };

            mockLocationService.Setup(x => x.GetLocation(It.IsAny<string>())).Returns(listOfLocation);
            Mock<DrugQueryProcessor> mockDrugQueryProcessor = new(mockCache.Object, logDrugQueryProcessor, mockLocationService.Object);
            Mock<HazardousTypeQueryProcessor> mockHazardousTypeQueryProcessor = new(mockCache.Object, logHazardousTypeQueryProcessor);
            Mock<DrugIdentifierQueryProcessor> mockDrugIdentifierQueryProcessor = new(mockCache.Object, logDrugIdentifierQueryProcessor);
            Mock<Data1ServiceRestClient> mockData1ServiceRestClient = new(logData1ServiceRestClient, client, mockConfig.Object);

            qryParams = new()
            {
                { "locations", new string[] { "locations" } },
                { "status", new string[] { "Active" } },
                { "enablesecondcheck", new string[] { "false" } }
            };

            locationSettingsQryParam = new LocationSettingsQuery { DrugId = "drug", LocationId = "locations", Subscribed = true };

            Mock<ILogger<DrugSyncRestClient>> mockDrugServiceLogger = new();
            Mock<DrugSyncRestClient> mockDrugSyncRestClient = new(client, mockConfig.Object, mockDrugServiceLogger.Object);
            ISessionFactory sessionFactory = Mock.Of<ISessionFactory>();
            NHibernate.ISession session = Mock.Of<NHibernate.ISession>();
            IHttpContextAccessor httpContextAccessor = Mock.Of<IHttpContextAccessor>();

            Mock<DrugSyncServiceAdapter> mockSyncServiceAdapter = new(mockDrugQueryProcessor.Object,
                logDrugSyncServiceAdapter, mockDrugSyncRestClient.Object, sessionFactory, mockCache.Object);

            ProducerService mockProducerService = new(mockConfig.Object, logProducerService);

            Mock<DataChangedService> mockDataChangedService = new(logDataChangedService, mockProducerService, mockConfig.Object);

            mockDrugCommand = new Mock<DrugCommand>(mockCache.Object, sessionFactory, logDrugCommand, mockProducerService, mockSyncServiceAdapter.Object, mockDataChangedService.Object);
            mockDrugValidator = new Mock<DrugValidator>(mockCache.Object, logDrugValidator);
            Mock<Data1Service> mockData1Service = new(logData1Service, mockData1ServiceRestClient.Object, mockDrugCommand.Object);


            Mock<DrugService> mockService = new(mockDrugQueryProcessor.Object, mockHazardousTypeQueryProcessor.Object, mockDrugIdentifierQueryProcessor.Object, logDrugService, mockLocationService.Object);
            List<string> drugIds = new()
            {
                "drug"
            };

            Dictionary<string, FormularyLocationSettingsModelV2> locations = new()
            {
                ["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active },
                ["locations"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Active, PreferredAccount = new PreferredAccountModelV2 { AccountId = "accountId", SupplierId = "supplierId" } }
            };
            FormularyDrugQryModelV2 formularyDrugQryModelV2 = new()
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                FormNormalized = new List<string> { "TABLET", "PILL" },
                TemperatureClass = TemperatureClass.COLD,
                Locations = locations
            };

            List<FormularyDrugQryModelV2> formularyDrugQryModelV2s1 = new()
            {
                formularyDrugQryModelV2
            };
            IEnumerable<FormularyDrugQryModelV2> formularyDrugQryModelV2s = formularyDrugQryModelV2s1.AsEnumerable();
            PagingInfo? pageInfo = new(0, 20);
            Page<FormularyDrugQryModelV2> pageData = DrugPage<FormularyDrugQryModelV2>.ApplyPaging(formularyDrugQryModelV2s, pageInfo);

            Dictionary<string, StringValues> dictionary = new()
            {
                { "locations", new StringValues("locations") },
                { "status", new StringValues("active") }
            };
            DefaultHttpContext httpContext = new();
            httpContext.Request.Query = new QueryCollection(dictionary);

            DrugLocationSettingsModelV2 drugLocationSettingsModelV2 = new()
            {
                DrugId = "drug",
                Form = "TABLET",
                Name = "drug name",
                FormNormalized = new List<string> { "TABLET", "PILL" },
                Strength = "10",
                Volume = "mg",
                Locations = locations
            };

            List<DrugLocationSettingsModelV2> listOfDrugLocationSettingsModelV2 = new()
            {
                drugLocationSettingsModelV2
            };
            Page<DrugLocationSettingsModelV2> pagedDrugLocationSettingsModelV2 = DrugPage<DrugLocationSettingsModelV2>.ApplyPaging(listOfDrugLocationSettingsModelV2, pageInfo);

            IdentifierDrugModelV2 identifierDrugModelV2 = new()
            {
                ItemId = "drug/formularyId/NDCValue/BarcodeValue",
                Identifiers = new List<IdentifierV2>() { new IdentifierV2()
                { Type = "NDC", Identifier = "NDCValue" }, new IdentifierV2()
                { Type = "BARCODE", Identifier = "BarcodeValue", Status = IdentifierStatus.APPROVED }
                },
                Unit = "Each"
            };
            List<IdentifierDrugModelV2> listOfIdentifierDrugModelV2 = new()
            {
                identifierDrugModelV2
            };
            IEnumerable<IdentifierDrugModelV2> identifierDrugModelV2s = listOfIdentifierDrugModelV2.AsEnumerable();

            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/NDCValue/BarcodeValue",
                Type = "BARCODE",
                Identifier = "BarcodeValue",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin"
            };
            List<BarcodeIdentifierModelV2> listOfBarcodeIdentifierModelV2 = new()
            {
                barcodeIdentifierModelV2
            };
            IEnumerable<BarcodeIdentifierModelV2> barcodeIdentifierModelV2s = listOfBarcodeIdentifierModelV2.AsEnumerable();
            Page<BarcodeIdentifierModelV2> pagedBarcodeIdentifierModelV2 = DrugPage<BarcodeIdentifierModelV2>.ApplyPaging(barcodeIdentifierModelV2s, pageInfo);
            barcodeIdentifierSearchParam = new BarcodeIdentifierSearchParam { Facility = "facility", DrugId = "", Identifier = "", Status = IdentifierStatus.APPROVED, Type = "" };

            Dictionary<string, string> operationNotices = new()
            {
                { "dispense", "dispensed" }
            };
            HazardousDrugTypeModelV2 hazardousDrugTypeModelV2 = new()
            {
                OperationNotice = operationNotices,
                Description = "Description",
                HazardousDrugTypeId = HazardousTypes.GROUP_1,
                IsDeleted = false
            };

            List<HazardousDrugTypeModelV2> listOfHazardousDrugTypeModelV2 = new()
            {
                hazardousDrugTypeModelV2
            };
            IEnumerable<HazardousDrugTypeModelV2> hazardousDrugTypeModelV2s = listOfHazardousDrugTypeModelV2.AsEnumerable();



            Swisslog.Excel.ExcelWriter? excelWriter = new();

            ProblemDetail? problemDetail2 = new() { Title = "Error Title", Detail = "Error Detail", Status = 409 };

            Dictionary<string, QuantityDetails> dicQtyDetails = new()
            {
                { "drug/drug", new QuantityDetails { QuantityAvailable = 30, QuantityOnHand = 40 } }
            };

            formularyDrugModelV2 = new FormularyDrugModelV2
            {
                DrugId = "drug",
                Name = "drug name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                FormNormalized = new List<string> { "TABLET", "PILL" },
                TemperatureClass = TemperatureClass.COLD,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations,
                Version = 0
            };

            Dictionary<string, FormularyLocationSettingsModelV2> locations2 = new()
            {
                ["root"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Obsolete },
                ["locations"] = new FormularyLocationSettingsModelV2 { Formulary = true, Status = LocationSettingsStatus.Obsolete }
            };


            FormularyDrugModelV2 formularyDrugModel2 = new()
            {
                DrugId = "drug2",
                Name = "drug2 name",
                Strength = "10",
                Volume = "mg",
                Form = "TABLET",
                FormNormalized = new List<string> { "TABLET", "PILL" },
                TemperatureClass = TemperatureClass.ROOM,
                ScanValidation = false,
                ControlSchedule = false,
                ControlSubstance = false,
                BasePackaged = DrugBaseUnitOfMeasurement.EACH,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
                PackAlone = true,
                Route = "Oral",
                Locations = locations2,
                Version = 0
            };

            drugCacheDataEntity = new DrugCacheDataEntity(formularyDrugModelV2)
            {
                DrugId = "drug",
                DrugEntityId = drugEntityId,
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" },
            };

            DrugCacheDataEntity drugCacheDataEntity2 = new(formularyDrugModel2)
            {
                DrugId = "drug2",
                DrugEntityId = Guid.NewGuid(),
                DrugEntityType = DrugType.Formulary,
                HasDrugInfo = true,
                Id = "drug2",
                IsActive = true,
                Origin = "UI",
                HazardousTypes = new List<string>() { "GROUP_1" }
            };

            updatePreferredAccountModelV2 = new UpdatePreferredAccountModelV2 { NewAccountId = "newacc1", NewSupplierId = "newsupp1", OldAccountId = "accountId", OldSupplierId = "supplierId" };

            List<DrugCacheDataEntity> listOfDrugCacheEntity = new()
            {
                drugCacheDataEntity
            };
            List<DrugCacheDataEntity> listOfDrugCacheEntity2 = new()
            {
                drugCacheDataEntity2
            };

            manufacturedDrugModelV2 = new ManufacturedDrugModelV2
            {
                DrugId = "formularyId/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "formularyId",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC", Identifier = "123456789"
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            packagedDrugModelV2 = new PackagedDrugModelV2
            {
                DrugId = "formularyId/123456789/Each",
                ManufacturedDrugId = "formularyId/123456789",
                Name = "Each",
                PackageId = "Each",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "BARCODE", Identifier = "987654321", Status = IdentifierStatus.APPROVED
                    }
                },
                Version = 0,
                Origin = "UI"
            };
            manufacturedDrugQryModelV2 = new ManufacturedDrugQryModelV2
            {
                DrugId = "formularyId/123456789",
                ManufacturerId = "123456789",
                ManufacturerName = "ManufacturerName",
                Name = "BrandName",
                FormularyDrugId = "formularyId",
                Identifiers = new List<IdentifierV2>() {
                    new IdentifierV2 {
                        Type = "NDC",
                        Identifier = "123456789"
                    }
                },
                IsBrand = false,
                Color = "",
                Imprint1 = "",
                Imprint2 = "",
                ImageFile = "",
                Shape = "",
                Status = DrugStatus.Active,
                Created = DateTime.Now,
                LastModified = DateTime.Now,
                Version = 0,
                Origin = "UI",
                PackagedDrugs = new List<PackagedDrugQryModelV2>() {
                    new PackagedDrugQryModelV2
                    {
                        DrugId = "formularyId/123456789/Each",
                        ManufacturedDrugId = "formularyId/123456789",
                        Name = "Each",
                        PackageId = "Each",
                        PackageQty = 1,
                        Identifiers = new List<IdentifierV2>() {
                            new IdentifierV2 {
                                Type = "BARCODE",
                                Identifier = "987654321",
                                Status = IdentifierStatus.APPROVED
                            }
                        },
                        Version = 0,
                        Origin = "UI",
                        PackageContainer = "",
                        Status = DrugStatus.Active,
                        Created = DateTime.Now,
                        LastModified = DateTime.Now,
                    }
                }
            };
            validationResult = new ValidationResult { IsError = false };
            tupleFormulary = new Tuple<bool, object>(true, formularyDrugModelV2);
            tupleManufacturer = new Tuple<bool, object>(true, manufacturedDrugModelV2);
            tuplePackaged = new Tuple<bool, object>(true, packagedDrugModelV2);
            tupleMultipleUserConflict = new Tuple<bool, object>(false, "MULTIPLEUSER_UPDATE");
            tupleInternalServerError = new Tuple<bool, object>(false, "Internal Server Error");

            Mock<PreferenceServiceRestClient> mockPreferenceServiceRestClient = new(logPreferenceServiceRestClient, client, mockConfig.Object);
            Mock<PreferenceService> mockPreferenceService = new(logPreferenceService, mockPreferenceServiceRestClient.Object);
            mockPreferenceServiceRestClient.Setup(x => x.PostPreferenceForDrugEnumUpdate(It.IsAny<Swisslog.Preference.Api.PreferenceV1>()).Result).Returns(System.Net.HttpStatusCode.Created);

            mockService.Setup(x => x.QueryDrugIds(It.IsAny<Dictionary<string, string[]>>()).Result).Returns(drugIds);
            mockService.Setup(x => x.QueryDrugs(It.IsAny<Dictionary<string, string[]>>()).Result).Returns(pageData);
            mockService.Setup(x => x.GetDrugLocationSettingsByUniqueIds(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>(), It.IsAny<Dictionary<string, string[]>>()).Result).Returns(pagedDrugLocationSettingsModelV2);
            mockService.Setup(x => x.QueryDrugIdentifiers(It.IsAny<string>(), It.IsAny<Dictionary<string, string[]>>()).Result).Returns(identifierDrugModelV2s);
            mockService.Setup(x => x.GetDrugByUniqueId(It.IsAny<string>()).Result).Returns(formularyDrugQryModelV2);
            mockService.Setup(x => x.QueryBarcodeIdentifiers(It.IsAny<BarcodeIdentifierSearchParam>(), It.IsAny<Dictionary<string, string[]>>()).Result).Returns(pagedBarcodeIdentifierModelV2);
            mockService.Setup(x => x.GetExportDrug(It.IsAny<Dictionary<string, string[]>>()).Result).Returns(excelWriter.GetMemoryStream());
            mockService.Setup(x => x.GetDrugByPreferredSetting(It.IsAny<string>(), It.IsAny<string>()).Result).Returns(listOfDrugCacheEntity);
            mockService.Setup(x => x.GetFormularyDrugEntity().Result).Returns(listOfDrugCacheEntity2);
            mockDrugValidator.Setup(x => x.ValidateBarcode("54321").Result).Returns(problemDetail2);
            mockDrugValidator.Setup(x => x.ValidateDrugIdAsync("drug2", true).Result).Returns(problemDetail2);
            mockDrugCommand.Setup(x => x.PushDrugsToWM6().Result).Returns(drugIds);
            //Act
            drugController = new DrugController(mockService.Object, mockDrugCommand.Object, mockDrugValidator.Object, httpContextAccessor, logDrugController, _mapper!, mockData1Service.Object, mockPreferenceService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

        }
        #endregion

        #region Method
        [TestMethod]
        public void GetDrugIdsTest()
        {
            DrugQueryParam drugQueryParam = null;
            //Act
            Task<ActionResult>? listOfDrugs = drugController?.GetDrugIds(drugQueryParam!);
            //Assert
            Assert.IsNotNull(listOfDrugs);
            Assert.AreEqual(listOfDrugs.Status, TaskStatus.RanToCompletion);
        }

        [TestMethod]
        public void UpdatePreferredAccountSettingsTest()
        {
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleFormulary!);
            //Act
            Task<ActionResult>? result = drugController?.UpdatePreferredAccountSettings(updatePreferredAccountModelV2!);
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((OkResult)result.Result).StatusCode, 200);
        }

        [TestMethod]
        public void UpdatePreferredAccountSettingsRequestValueNULLTest()
        {
            UpdatePreferredAccountModelV2? updatePreferredAccountModelV2 = null;
            //Act
            Task<ActionResult>? result = drugController?.UpdatePreferredAccountSettings(updatePreferredAccountModelV2!);
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = result.Result as ObjectResult;
            ErrorDetail? errorDetail = (ErrorDetail)output.Value;
            Assert.AreEqual(output.StatusCode, 400);
            Assert.IsNotNull(errorDetail);
            Assert.AreEqual(errorDetail.ErrorCode, 3012);
            Assert.AreEqual(errorDetail.ErrorMessage, "Request body is empty.");
        }

        [TestMethod]
        public void UpdatePreferredAccountSettingsOneRequestPropertyNULLTest()
        {
            UpdatePreferredAccountModelV2 updatePreferredAccountModelV2 = new() { NewAccountId = "a2", NewSupplierId = "s2", OldAccountId = "a1", OldSupplierId = "" };
            //Act
            Task<ActionResult>? result = drugController?.UpdatePreferredAccountSettings(updatePreferredAccountModelV2);
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = result.Result as ObjectResult;
            ErrorDetail? errorDetail = (ErrorDetail)output.Value;
            Assert.AreEqual(output.StatusCode, 400);
            Assert.IsNotNull(errorDetail);
            Assert.AreEqual(errorDetail.ErrorCode, 3013);
            Assert.AreEqual(errorDetail.ErrorMessage, "OldAccountId, OldSupplierId, NewAccountId & NewSupplierId are required");
        }

        [TestMethod]
        public void UpdatePreferredAccountSettingsMultipleUserConflictTest()
        {
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleMultipleUserConflict!);
            //Act
            Task<ActionResult>? result = drugController?.UpdatePreferredAccountSettings(updatePreferredAccountModelV2!);
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = result.Result as ObjectResult;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "This record is being updated by another user");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_MULTIPLE_USER_UPDATE.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/updatePreferredAccount"));
        }

        [TestMethod]
        public void UpdatePreferredAccountSettingsInternalServerErrorTest()
        {
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleInternalServerError!);
            //Act
            Task<ActionResult>? result = drugController?.UpdatePreferredAccountSettings(updatePreferredAccountModelV2!);
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((ObjectResult)result.Result).StatusCode, 500);
        }

        [TestMethod]
        public void GetFormularyDrugsByPreferredAccountTest()
        {
            PreferredAccountModelV2 preferredAccountModelV2 = new() { SupplierId = "supplierId", AccountId = "accountId" };
            //Act
            Task<ActionResult>? result = drugController?.GetFormularyDrugsByPreferredAccount(preferredAccountModelV2);
            //Assert
            Assert.IsNotNull(result);
            OkObjectResult? output = result.Result as OkObjectResult;
            List<FormularyDrugModelV2>? listOfFormulary = (List<FormularyDrugModelV2>)output.Value;
            Assert.AreEqual(output.StatusCode, 200);
            Assert.AreEqual(listOfFormulary.Count, 1);
            Dictionary<string, FormularyLocationSettingsModelV2> keyValuePairs = listOfFormulary[0].Locations;
            Assert.AreEqual(keyValuePairs.Count, 1);
            foreach (KeyValuePair<string, FormularyLocationSettingsModelV2> keyValuePair in keyValuePairs)
            {
                switch (keyValuePair.Key)
                {
                    case "root":
                        Assert.AreEqual(keyValuePair.Value.Formulary, true);
                        Assert.AreEqual(keyValuePair.Value.Status, LocationSettingsStatus.Active);
                        Assert.AreEqual(keyValuePair.Value.PreferredAccount, null);
                        break;
                    case "location":
                        Assert.AreEqual(keyValuePair.Value.Formulary, true);
                        Assert.AreEqual(keyValuePair.Value.Status, LocationSettingsStatus.Active);
                        Assert.AreEqual(keyValuePair.Value.PreferredAccount.AccountId, preferredAccountModelV2.AccountId);
                        Assert.AreEqual(keyValuePair.Value.PreferredAccount.SupplierId, preferredAccountModelV2.SupplierId);
                        break;
                    default:
                        break;

                }
            }
        }

        [TestMethod]
        public void GetFormularyDrugsByPreferredAccountRequestValueNULLTest()
        {
            PreferredAccountModelV2? preferredAccountModelV2 = null;
            //Act
            Task<ActionResult>? result = drugController?.GetFormularyDrugsByPreferredAccount(preferredAccountModelV2!);
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = result.Result as ObjectResult;
            ErrorDetail? errorDetail = (ErrorDetail)output.Value;
            Assert.AreEqual(output.StatusCode, 400);
            Assert.IsNotNull(errorDetail);
            Assert.AreEqual(errorDetail.ErrorCode, 3012);
            Assert.AreEqual(errorDetail.ErrorMessage, "Request body is empty.");
        }

        [TestMethod]
        public void GetFormularyDrugsByPreferredAccountOneRequestPropertyNULLTest()
        {
            PreferredAccountModelV2 preferredAccountModelV2 = new() { SupplierId = "", AccountId = "accountId" };
            //Act
            Task<ActionResult>? result = drugController?.GetFormularyDrugsByPreferredAccount(preferredAccountModelV2);
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = result.Result as ObjectResult;
            ErrorDetail? errorDetail = (ErrorDetail)output.Value;
            Assert.AreEqual(output.StatusCode, 400);
            Assert.IsNotNull(errorDetail);
            Assert.AreEqual(errorDetail.ErrorCode, 3013);
            Assert.AreEqual(errorDetail.ErrorMessage, "AccountId & SupplierId both required");
        }

        [TestMethod]
        public void GetTest()
        {
            DrugQueryParam drugQueryParam = null;
            //Act
            ActionResult? listOfDrugs = drugController?.Get(drugQueryParam!).Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                Page<FormularyDrugQryModelV2>? pageData = (Page<FormularyDrugQryModelV2>)output.Value;
                Assert.AreEqual(pageData.Total, 1);
                Assert.AreEqual(pageData.Data?[0].DrugId, "drug");
                Assert.AreEqual(pageData.Data?[0].Name, "drug name");
                Assert.AreEqual(pageData.Data?[0].Strength, "10");
                Assert.AreEqual(pageData.Data?[0].Volume, "mg");
                Assert.AreEqual(pageData.Data?[0].Locations.Count, 2);
                Assert.AreEqual(pageData.Data?[0].Locations["root"].Formulary, true);
                Assert.AreEqual(pageData.Data?[0].Locations["root"].Status, LocationSettingsStatus.Active);
                Assert.AreEqual(pageData.Data?[0].Locations["locations"].Formulary, true);
                Assert.AreEqual(pageData.Data?[0].Locations["locations"].Status, LocationSettingsStatus.Active);
            }
        }

        [TestMethod]
        public void GetLocationSettingsTest()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.GetLocationSettings(locationSettingsQryParam!).Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                Page<DrugLocationSettingsModelV2>? pageData = (Page<DrugLocationSettingsModelV2>)output.Value;
                Assert.AreEqual(pageData.Total, 1);
                Assert.AreEqual(pageData.Data?[0].DrugId, "drug");
                Assert.AreEqual(pageData.Data?[0].Name, "drug name");
                Assert.AreEqual(pageData.Data?[0].Strength, "10");
                Assert.AreEqual(pageData.Data?[0].Volume, "mg");
                Assert.AreEqual(pageData.Data?[0].Form, "TABLET");
                Assert.AreEqual(pageData.Data?[0].FormNormalized.Count, 2);
                Assert.AreEqual(pageData.Data?[0].FormNormalized[0], "TABLET");
                Assert.AreEqual(pageData.Data?[0].FormNormalized[1], "PILL");
                Assert.AreEqual(pageData.Data?[0]?.Locations?.Count, 2);
                Assert.AreEqual(pageData.Data?[0]?.Locations?["root"].Formulary, true);
                Assert.AreEqual(pageData.Data?[0]?.Locations?["root"].Status, LocationSettingsStatus.Active);
                Assert.AreEqual(pageData.Data?[0]?.Locations?["locations"].Formulary, true);
                Assert.AreEqual(pageData.Data?[0]?.Locations?["locations"].Status, LocationSettingsStatus.Active);
            }
        }

        [TestMethod]
        public void GetIdentifiersTest()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.GetIdentifiers("").Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                List<IdentifierDrugModelV2>? drugs = (List<IdentifierDrugModelV2>)output.Value;
                Assert.AreEqual(drugs.Count, 1);
                Assert.AreEqual(drugs[0].Identifiers.Count, 2);
                Assert.AreEqual(drugs[0].ItemId, "drug/formularyId/NDCValue/BarcodeValue");
                Assert.AreEqual(drugs[0].Unit, "Each");
                Assert.AreEqual(drugs[0].Identifiers[0].Type, "NDC");
                Assert.AreEqual(drugs[0].Identifiers[0].Identifier, "NDCValue");
                Assert.AreEqual(drugs[0].Identifiers[1].Type, "BARCODE");
                Assert.AreEqual(drugs[0].Identifiers[1].Identifier, "BarcodeValue");
                Assert.AreEqual(drugs[0].Identifiers[1].Status, IdentifierStatus.APPROVED);
            }
        }

        [TestMethod]
        public void GetByIdTest()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.GetById("drug").Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                FormularyDrugQryModelV2? result = (FormularyDrugQryModelV2)output.Value;
                Assert.AreEqual(result.DrugId, "drug");
                Assert.AreEqual(result.Name, "drug name");
                Assert.AreEqual(result.Strength, "10");
                Assert.AreEqual(result.Volume, "mg");
                Assert.AreEqual(result.FormNormalized.Count, 2);
                Assert.AreEqual(result.FormNormalized[0], "TABLET");
                Assert.AreEqual(result.FormNormalized[1], "PILL");
                Assert.AreEqual(result.Locations.Count, 2);
                Assert.AreEqual(result.Locations["root"].Formulary, true);
                Assert.AreEqual(result.Locations["root"].Status, LocationSettingsStatus.Active);
                Assert.AreEqual(result.Locations["locations"].Formulary, true);
                Assert.AreEqual(result.Locations["locations"].Status, LocationSettingsStatus.Active);
            }
        }
        [TestMethod]
        public void GetByIdTestPrefix()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.GetById("drug/drug").Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                FormularyDrugQryModelV2? result = (FormularyDrugQryModelV2)output.Value;
                Assert.AreEqual(result.DrugId, "drug");
                Assert.AreEqual(result.Name, "drug name");
                Assert.AreEqual(result.Strength, "10");
                Assert.AreEqual(result.Volume, "mg");
                Assert.AreEqual(result.FormNormalized.Count, 2);
                Assert.AreEqual(result.FormNormalized[0], "TABLET");
                Assert.AreEqual(result.FormNormalized[1], "PILL");
                Assert.AreEqual(result.Locations.Count, 2);
                Assert.AreEqual(result.Locations["root"].Formulary, true);
                Assert.AreEqual(result.Locations["root"].Status, LocationSettingsStatus.Active);
                Assert.AreEqual(result.Locations["locations"].Formulary, true);
                Assert.AreEqual(result.Locations["locations"].Status, LocationSettingsStatus.Active);
            }
        }
        [TestMethod]
        public void GetBarcodeIdentifiersTest()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.GetBarcodeIdentifiers(barcodeIdentifierSearchParam!).Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                Page<BarcodeIdentifierModelV2>? result = (Page<BarcodeIdentifierModelV2>)output.Value;
                Assert.AreEqual(result?.Total, 1);
                Assert.AreEqual(result?.Data?.Count, 1);
                Assert.AreEqual(result?.Data![0].DrugId, "formularyId/NDCValue/BarcodeValue");
                Assert.AreEqual(result?.Data![0].Type, "BARCODE");
                Assert.AreEqual(result?.Data![0].Identifier, "BarcodeValue");
                Assert.AreEqual(result?.Data![0].Status, IdentifierStatus.APPROVED);
                Assert.AreEqual(result?.Data![0].LastModifiedBy, "systemadmin");
            }
        }

        [TestMethod]
        public void ExportExcelTest()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.ExportExcel(exportExcelSettingsQuery!).Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
        }

        [TestMethod]
        public void ValidateTest()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.Validate("12345").Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                bool isFalse = output.Value == null || (bool)output.Value;
                Assert.IsFalse(isFalse);
            }
        }

        [TestMethod]
        public void ValidateTrueTest()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.Validate("54321").Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                bool isTrue = output.Value != null && (bool)output.Value;
                Assert.IsTrue(isTrue);
            }
        }

        [TestMethod]
        public void ValidateDrugTest()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.ValidateDrug("drug1").Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                bool isFalse = output.Value == null || (bool)output.Value;
                Assert.IsFalse(isFalse);
            }
        }
        [TestMethod]
        public void ValidateDrugTestPrefix()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.ValidateDrug("drug/drug1").Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                bool isFalse = output.Value == null || (bool)output.Value;
                Assert.IsFalse(isFalse);
            }
        }
        [TestMethod]
        public void ValidateDrugTrueTest()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.ValidateDrug("drug2").Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                bool isTrue = output.Value != null && (bool)output.Value;
                Assert.IsTrue(isTrue);
            }
        }
        [TestMethod]
        public void ValidateDrugTrueTestPrefix()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.ValidateDrug("drug/drug2").Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                ObjectResult output = (ObjectResult)listOfDrugs;
                bool isTrue = output.Value != null && (bool)output.Value;
                Assert.IsTrue(isTrue);
            }
        }
        [TestMethod]
        public void PostFormularyTest()
        {
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(formularyDrugModelV2, null).Result).Returns(validationResult!);

            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleFormulary!);
            //Act
            ActionResult<FormularyDrugModelV2>? result = drugController?.PostFormulary(formularyDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            FormularyDrugModelV2? formularyDrug = (FormularyDrugModelV2)output.Value;
            Assert.AreEqual(formularyDrug.DrugId, "drug");
            Assert.AreEqual(formularyDrug.Name, "drug name");
            Assert.AreEqual(formularyDrug.Strength, "10");
            Assert.AreEqual(formularyDrug.Volume, "mg");
            Assert.AreEqual(formularyDrug.Form, "TABLET");
            Assert.AreEqual(formularyDrug.FormNormalized.Count, 2);
            Assert.AreEqual(formularyDrug.FormNormalized[0], "TABLET");
            Assert.AreEqual(formularyDrug.FormNormalized[1], "PILL");
            Assert.AreEqual(formularyDrug.TemperatureClass, TemperatureClass.COLD);
            Assert.AreEqual(formularyDrug.ScanValidation, false);
            Assert.AreEqual(formularyDrug.ControlSchedule, false);
            Assert.AreEqual(formularyDrug.ControlSubstance, false);
            Assert.AreEqual(formularyDrug.PackAlone, true);
            Assert.AreEqual(formularyDrug.BasePackaged, DrugBaseUnitOfMeasurement.EACH);
            Assert.AreEqual(formularyDrug.Route, "Oral");
            Assert.AreEqual(formularyDrug.Origin, "UI");
            Assert.AreEqual(formularyDrug.HazardousTypes[0], "GROUP_1");
            Assert.AreEqual(formularyDrug.Locations.Count, 2);
            Assert.AreEqual(formularyDrug.Locations["root"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["root"].Status, LocationSettingsStatus.Active);
            Assert.AreEqual(formularyDrug.Locations["locations"].Formulary, true);
            Assert.AreEqual(formularyDrug.Locations["locations"].Status, LocationSettingsStatus.Active);
        }

        [TestMethod]
        public void PostFormularyError1Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString(), Title = "Drug Code already exist", Status = 409 } };
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(formularyDrugModelV2, null).Result).Returns(error);
            //Act
            ActionResult<FormularyDrugModelV2>? result = drugController?.PostFormulary(formularyDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Code already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formulary"));
        }

        [TestMethod]
        public void PostFormularyError2Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_ALREADY_EXIST.ToString(), Title = "Drug Id already exist", Status = 409 } };
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(formularyDrugModelV2, null).Result).Returns(error);
            //Act
            ActionResult<FormularyDrugModelV2>? result = drugController?.PostFormulary(formularyDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Id already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_ID_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formulary"));
        }

        [TestMethod]
        public void PostFormularyError3Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString(), Title = "Drug Id is mandatory", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_ID_IS_MANDATORY, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString()) };
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(formularyDrugModelV2, null).Result).Returns(error);
            //Act
            ActionResult<FormularyDrugModelV2>? result = drugController?.PostFormulary(formularyDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_ID_IS_MANDATORY);
        }

        [TestMethod]
        public void PostManufacturedTest()
        {
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(manufacturedDrugModelV2, null).Result).Returns(validationResult!);

            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleManufacturer!);
            //Act
            ActionResult<ManufacturedDrugModelV2>? result = drugController?.PostMfgDrug(manufacturedDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ManufacturedDrugModelV2? manufacturerDrug = (ManufacturedDrugModelV2)output.Value;
            Assert.AreEqual(manufacturerDrug.DrugId, "formularyId/123456789");
            Assert.AreEqual(manufacturerDrug.Name, "BrandName");
            Assert.AreEqual(manufacturerDrug.ManufacturerName, "ManufacturerName");
            Assert.AreEqual(manufacturerDrug.ManufacturerId, "123456789");
            Assert.AreEqual(manufacturerDrug.FormularyDrugId, "formularyId");
            Assert.AreEqual(manufacturerDrug.Origin, "UI");
            Assert.AreEqual(manufacturerDrug.Identifiers.Count, 1);
            Assert.AreEqual(manufacturerDrug.Identifiers[0].Type, "NDC");
            Assert.AreEqual(manufacturerDrug.Identifiers[0].Identifier, "123456789");
        }

        [TestMethod]
        public void PostManufacturedError1Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString(), Title = "Drug Code already exist", Status = 409 } };
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(manufacturedDrugModelV2, null).Result).Returns(error);
            //Act
            ActionResult<ManufacturedDrugModelV2>? result = drugController?.PostMfgDrug(manufacturedDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Code already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/manufactured"));
        }

        [TestMethod]
        public void PostManufacturedError2Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_ALREADY_EXIST.ToString(), Title = "Drug Id already exist", Status = 409 } };
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(manufacturedDrugModelV2, null).Result).Returns(error);
            //Act
            ActionResult<ManufacturedDrugModelV2>? result = drugController?.PostMfgDrug(manufacturedDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Id already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_ID_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/manufactured"));
        }

        [TestMethod]
        public void PostManufacturedError3Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString(), Title = "Drug Id is mandatory", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_ID_IS_MANDATORY, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString()) };
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(manufacturedDrugModelV2, null).Result).Returns(error);
            //Act
            ActionResult<ManufacturedDrugModelV2>? result = drugController?.PostMfgDrug(manufacturedDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_ID_IS_MANDATORY);
        }

        [TestMethod]
        public void PostPackagedTest()
        {
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(packagedDrugModelV2, null).Result).Returns(validationResult!);

            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult<PackagedDrugModelV2>? result = drugController?.PostPackaged(packagedDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            PackagedDrugModelV2? packagedDrug = (PackagedDrugModelV2)output.Value;
            Assert.AreEqual(packagedDrug.DrugId, "formularyId/123456789/Each");
            Assert.AreEqual(packagedDrug.Name, "Each");
            Assert.AreEqual(packagedDrug.PackageId, "Each");
            Assert.AreEqual(packagedDrug.ManufacturedDrugId, "formularyId/123456789");
            Assert.AreEqual(packagedDrug.Origin, "UI");
            Assert.AreEqual(packagedDrug.Identifiers.Count, 1);
            Assert.AreEqual(packagedDrug.Identifiers[0].Type, "BARCODE");
            Assert.AreEqual(packagedDrug.Identifiers[0].Identifier, "987654321");
        }

        [TestMethod]
        public void PostPackagedError1Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString(), Title = "Drug Code already exist", Status = 409 } };
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(packagedDrugModelV2, null).Result).Returns(error);
            //Act
            ActionResult<PackagedDrugModelV2>? result = drugController?.PostPackaged(packagedDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Code already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/packaged"));
        }

        [TestMethod]
        public void PostPackagedError2Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_ALREADY_EXIST.ToString(), Title = "Drug Id already exist", Status = 409 } };
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(packagedDrugModelV2, null).Result).Returns(error);
            //Act
            ActionResult<PackagedDrugModelV2>? result = drugController?.PostPackaged(packagedDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Id already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_ID_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/packaged"));
        }

        [TestMethod]
        public void PostPackagedError3Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString(), Title = "Drug Id is mandatory", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_ID_IS_MANDATORY, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString()) };
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(packagedDrugModelV2, null).Result).Returns(error);
            //Act
            ActionResult<PackagedDrugModelV2>? result = drugController?.PostPackaged(packagedDrugModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = (ObjectResult)result.Result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_ID_IS_MANDATORY.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_ID_IS_MANDATORY);
        }

        [TestMethod]
        public void PushDrugsToWM6Test()
        {
            //Act
            ActionResult? listOfDrugs = drugController?.PushDrugsToWM6().Result;
            //Assert
            Assert.IsNotNull(listOfDrugs);
            if (listOfDrugs != null)
            {
                CreatedAtActionResult output = (CreatedAtActionResult)listOfDrugs;
                List<string>? drugs = (List<string>)output.Value;
                Assert.AreEqual(drugs.Count, 1);
                Assert.AreEqual(drugs[0], "drug");
            }
        }

        [TestMethod]
        public void PutFormularyTest()
        {
            string formularyData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug\",\n  \"name\": \"drug name\",\n  \"strength\": \"10\",\n  \"volume\": \"mg\",\n  \"form\": \"INJECTION\",\n  \"route\": \"Oral\",\n  \"controlSchedule\": false,\n  \"controlSubstance\": false,\n  \"packAlone\": false,\n  \"otc\": false,\n  \"basePackaged\": \"EACH\",\n  \"temperatureClass\": \"NONE\",\n  \"scanValidation\": false,\n  \"hazardousTypes\": [\n    \"NONE\"\n  ],\n  \"locations\": {\n    \"root\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    },\n    \"locations\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    }\n  },\n  \"created\": \"2021-12-03T03:12:13.424Z\",\n  \"lastModified\": \"2021-12-03T03:12:13.424Z\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(It.IsAny<FormularyDrugModelV2>(), It.IsAny<string>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);

            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleFormulary!);
            //Act
            ActionResult? result = drugController?.Put("drug", formularyData).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((OkResult)result).StatusCode, 200);
        }

        [TestMethod]
        public void PutFormularyError1Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString(), Title = "Drug does not exist", Status = 404 } };

            string formularyData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug\",\n  \"name\": \"drug name\",\n  \"strength\": \"10\",\n  \"volume\": \"mg\",\n  \"form\": \"INJECTION\",\n  \"route\": \"Oral\",\n  \"controlSchedule\": false,\n  \"controlSubstance\": false,\n  \"packAlone\": false,\n  \"otc\": false,\n  \"basePackaged\": \"EACH\",\n  \"temperatureClass\": \"NONE\",\n  \"scanValidation\": false,\n  \"hazardousTypes\": [\n    \"NONE\"\n  ],\n  \"locations\": {\n    \"root\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    },\n    \"locations\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    }\n  },\n  \"created\": \"2021-12-03T03:12:13.424Z\",\n  \"lastModified\": \"2021-12-03T03:12:13.424Z\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(It.IsAny<FormularyDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug", formularyData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug does not exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());
            Assert.AreEqual(problem.Status, 404);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug"));
        }

        [TestMethod]
        public void PutFormularyError2Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString(), Title = "Drug Identifier already exist", Status = 409 } };

            string formularyData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug\",\n  \"name\": \"drug name\",\n  \"strength\": \"10\",\n  \"volume\": \"mg\",\n  \"form\": \"INJECTION\",\n  \"route\": \"Oral\",\n  \"controlSchedule\": false,\n  \"controlSubstance\": false,\n  \"packAlone\": false,\n  \"otc\": false,\n  \"basePackaged\": \"EACH\",\n  \"temperatureClass\": \"NONE\",\n  \"scanValidation\": false,\n  \"hazardousTypes\": [\n    \"NONE\"\n  ],\n  \"locations\": {\n    \"root\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    },\n    \"locations\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    }\n  },\n  \"created\": \"2021-12-03T03:12:13.424Z\",\n  \"lastModified\": \"2021-12-03T03:12:13.424Z\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(It.IsAny<FormularyDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug", formularyData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Identifier already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug"));
        }

        [TestMethod]
        public void PutFormularyError3Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString(), Title = "Drug Id does not match", Status = 409 } };

            string formularyData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug\",\n  \"name\": \"drug name\",\n  \"strength\": \"10\",\n  \"volume\": \"mg\",\n  \"form\": \"INJECTION\",\n  \"route\": \"Oral\",\n  \"controlSchedule\": false,\n  \"controlSubstance\": false,\n  \"packAlone\": false,\n  \"otc\": false,\n  \"basePackaged\": \"EACH\",\n  \"temperatureClass\": \"NONE\",\n  \"scanValidation\": false,\n  \"hazardousTypes\": [\n    \"NONE\"\n  ],\n  \"locations\": {\n    \"root\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    },\n    \"locations\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    }\n  },\n  \"created\": \"2021-12-03T03:12:13.424Z\",\n  \"lastModified\": \"2021-12-03T03:12:13.424Z\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(It.IsAny<FormularyDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug", formularyData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Id does not match");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug"));
        }

        [TestMethod]
        public void PutFormularyError4Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString(), Title = "Drug Id is mandatory", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_STATUS_IS_INVALID, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString()) };

            string formularyData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug\",\n  \"name\": \"drug name\",\n  \"strength\": \"10\",\n  \"volume\": \"mg\",\n  \"form\": \"INJECTION\",\n  \"route\": \"Oral\",\n  \"controlSchedule\": false,\n  \"controlSubstance\": false,\n  \"packAlone\": false,\n  \"otc\": false,\n  \"basePackaged\": \"EACH\",\n  \"temperatureClass\": \"NONE\",\n  \"scanValidation\": false,\n  \"hazardousTypes\": [\n    \"NONE\"\n  ],\n  \"locations\": {\n    \"root\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    },\n    \"locations\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    }\n  },\n  \"created\": \"2021-12-03T03:12:13.424Z\",\n  \"lastModified\": \"2021-12-03T03:12:13.424Z\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(It.IsAny<FormularyDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug", formularyData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_STATUS_IS_INVALID);
        }

        [TestMethod]
        public void PutFormularyError5Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_FORMULARY_DRUG_ID_IS_INVALID.ToString(), Title = "Drug Id is mandatory", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_FORMULARY_DRUG_ID_IS_INVALID, ProblemErrorCode.DRUG_FORMULARY_DRUG_ID_IS_INVALID.ToString()) };

            string formularyData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug\",\n  \"name\": \"drug name\",\n  \"strength\": \"10\",\n  \"volume\": \"mg\",\n  \"form\": \"INJECTION\",\n  \"route\": \"Oral\",\n  \"controlSchedule\": false,\n  \"controlSubstance\": false,\n  \"packAlone\": false,\n  \"otc\": false,\n  \"basePackaged\": \"EACH\",\n  \"temperatureClass\": \"NONE\",\n  \"scanValidation\": false,\n  \"hazardousTypes\": [\n    \"NONE\"\n  ],\n  \"locations\": {\n    \"root\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    },\n    \"locations\": {\n      \"requireLotCode\": true,\n      \"requireExpiryDate\": true,\n      \"requireSerialNumber\": true,\n      \"preferLocalDispense\": true,\n      \"status\": \"Active\",\n      \"formulary\": true,\n      \"flag1\": true,\n      \"flag2\": true,\n      \"flag3\": true\n    }\n  },\n  \"created\": \"2021-12-03T03:12:13.424Z\",\n  \"lastModified\": \"2021-12-03T03:12:13.424Z\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(It.IsAny<FormularyDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug123", formularyData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_FORMULARY_DRUG_ID_IS_INVALID.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_FORMULARY_DRUG_ID_IS_INVALID);
        }

        [TestMethod]
        public void PutMfgTest()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(manufacturedDrugModelV2)
            {
                Origin = "UI"
            };
            string mfgData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123\",\n  \"identifiers\": [\n    {\n      \"type\": \"NDC\",\n      \"identifier\": \"NDC123\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"name\": \"bname\",\n  \"manufacturerName\": \"mname\",\n  \"manufacturerId\": \"NDC123\",\n  \"isBrand\": false,\n  \"color\": \"string\",\n  \"shape\": \"string\",\n  \"imprint1\": \"string\",\n  \"imprint2\": \"string\",\n  \"imageFile\": \"string\",\n  \"created\": \"2021-12-03T03:50:45.196Z\",\n  \"lastModified\": \"2021-12-03T03:50:45.196Z\",\n  \"formularyDrugId\": \"drug\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>(), It.IsAny<string>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);

            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleManufacturer!);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123", mfgData).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((OkResult)result).StatusCode, 200);
        }

        [TestMethod]
        public void PutMfgError1Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString(), Title = "Drug does not exist", Status = 404 } };

            string mfgData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123\",\n  \"identifiers\": [\n    {\n      \"type\": \"NDC\",\n      \"identifier\": \"NDC123\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"name\": \"bname\",\n  \"manufacturerName\": \"mname\",\n  \"manufacturerId\": \"NDC123\",\n  \"isBrand\": false,\n  \"color\": \"string\",\n  \"shape\": \"string\",\n  \"imprint1\": \"string\",\n  \"imprint2\": \"string\",\n  \"imageFile\": \"string\",\n  \"created\": \"2021-12-03T03:50:45.196Z\",\n  \"lastModified\": \"2021-12-03T03:50:45.196Z\",\n  \"formularyDrugId\": \"drug\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123", mfgData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug does not exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());
            Assert.AreEqual(problem.Status, 404);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug/NDC123"));
        }

        [TestMethod]
        public void PutMfgError2Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString(), Title = "Drug Identifier already exist", Status = 409 } };

            string mfgData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123\",\n  \"identifiers\": [\n    {\n      \"type\": \"NDC\",\n      \"identifier\": \"NDC123\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"name\": \"bname\",\n  \"manufacturerName\": \"mname\",\n  \"manufacturerId\": \"NDC123\",\n  \"isBrand\": false,\n  \"color\": \"string\",\n  \"shape\": \"string\",\n  \"imprint1\": \"string\",\n  \"imprint2\": \"string\",\n  \"imageFile\": \"string\",\n  \"created\": \"2021-12-03T03:50:45.196Z\",\n  \"lastModified\": \"2021-12-03T03:50:45.196Z\",\n  \"formularyDrugId\": \"drug\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123", mfgData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Identifier already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug/NDC123"));
        }

        [TestMethod]
        public void PutMfgError3Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString(), Title = "Drug Id does not match", Status = 409 } };

            string mfgData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123\",\n  \"identifiers\": [\n    {\n      \"type\": \"NDC\",\n      \"identifier\": \"NDC123\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"name\": \"bname\",\n  \"manufacturerName\": \"mname\",\n  \"manufacturerId\": \"NDC123\",\n  \"isBrand\": false,\n  \"color\": \"string\",\n  \"shape\": \"string\",\n  \"imprint1\": \"string\",\n  \"imprint2\": \"string\",\n  \"imageFile\": \"string\",\n  \"created\": \"2021-12-03T03:50:45.196Z\",\n  \"lastModified\": \"2021-12-03T03:50:45.196Z\",\n  \"formularyDrugId\": \"drug\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123", mfgData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Id does not match");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug/NDC123"));
        }

        [TestMethod]
        public void PutMfgError4Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString(), Title = "Drug Id is mandatory", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_STATUS_IS_INVALID, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString()) };

            string mfgData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123\",\n  \"identifiers\": [\n    {\n      \"type\": \"NDC\",\n      \"identifier\": \"NDC123\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"name\": \"bname\",\n  \"manufacturerName\": \"mname\",\n  \"manufacturerId\": \"NDC123\",\n  \"isBrand\": false,\n  \"color\": \"string\",\n  \"shape\": \"string\",\n  \"imprint1\": \"string\",\n  \"imprint2\": \"string\",\n  \"imageFile\": \"string\",\n  \"created\": \"2021-12-03T03:50:45.196Z\",\n  \"lastModified\": \"2021-12-03T03:50:45.196Z\",\n  \"formularyDrugId\": \"drug\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123", mfgData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_STATUS_IS_INVALID);
        }

        [TestMethod]
        public void PutMfgError5Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID.ToString(), Title = "Drug Id is mandatory", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID, ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID.ToString()) };

            string mfgData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123\",\n  \"identifiers\": [\n    {\n      \"type\": \"NDC\",\n      \"identifier\": \"NDC123\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"name\": \"bname\",\n  \"manufacturerName\": \"mname\",\n  \"manufacturerId\": \"NDC123\",\n  \"isBrand\": false,\n  \"color\": \"string\",\n  \"shape\": \"string\",\n  \"imprint1\": \"string\",\n  \"imprint2\": \"string\",\n  \"imageFile\": \"string\",\n  \"created\": \"2021-12-03T03:50:45.196Z\",\n  \"lastModified\": \"2021-12-03T03:50:45.196Z\",\n  \"formularyDrugId\": \"drug\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidateMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC1235", mfgData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID);
        }

        [TestMethod]
        public void PutPackagedTest()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            string packagedData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123/Each\",\n  \"identifiers\": [\n    {\n      \"type\": \"BARCODE\",\n      \"identifier\": \"123456789\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"packageId\": \"Each\",\n  \"name\": \"Each\",\n  \"packageContainer\": \"string\",\n  \"packageQty\": 1,\n  \"created\": \"2021-12-03T04:07:04.414Z\",\n  \"lastModified\": \"2021-12-03T04:07:04.414Z\",\n  \"manufacturedDrugId\": \"drug/NDC123\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(It.IsAny<PackagedDrugModelV2>(), It.IsAny<string>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123/Each", packagedData).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((OkResult)result).StatusCode, 200);
        }

        [TestMethod]
        public void PutPackagedError1Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString(), Title = "Drug does not exist", Status = 404 } };

            string packagedData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123/Each\",\n  \"identifiers\": [\n    {\n      \"type\": \"BARCODE\",\n      \"identifier\": \"123456789\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"packageId\": \"Each\",\n  \"name\": \"Each\",\n  \"packageContainer\": \"string\",\n  \"packageQty\": 1,\n  \"created\": \"2021-12-03T04:07:04.414Z\",\n  \"lastModified\": \"2021-12-03T04:07:04.414Z\",\n  \"manufacturedDrugId\": \"drug/NDC123\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(It.IsAny<PackagedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123/Each", packagedData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug does not exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());
            Assert.AreEqual(problem.Status, 404);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug/NDC123/Each"));
        }

        [TestMethod]
        public void PutPackagedError2Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString(), Title = "Drug Identifier already exist", Status = 409 } };

            string packagedData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123/Each\",\n  \"identifiers\": [\n    {\n      \"type\": \"BARCODE\",\n      \"identifier\": \"123456789\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"packageId\": \"Each\",\n  \"name\": \"Each\",\n  \"packageContainer\": \"string\",\n  \"packageQty\": 1,\n  \"created\": \"2021-12-03T04:07:04.414Z\",\n  \"lastModified\": \"2021-12-03T04:07:04.414Z\",\n  \"manufacturedDrugId\": \"drug/NDC123\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(It.IsAny<PackagedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123/Each", packagedData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Identifier already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug/NDC123/Each"));
        }

        [TestMethod]
        public void PutPackagedError3Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString(), Title = "Drug Id does not match", Status = 409 } };

            string packagedData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123/Each\",\n  \"identifiers\": [\n    {\n      \"type\": \"BARCODE\",\n      \"identifier\": \"123456789\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"packageId\": \"Each\",\n  \"name\": \"Each\",\n  \"packageContainer\": \"string\",\n  \"packageQty\": 1,\n  \"created\": \"2021-12-03T04:07:04.414Z\",\n  \"lastModified\": \"2021-12-03T04:07:04.414Z\",\n  \"manufacturedDrugId\": \"drug/NDC123\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(It.IsAny<PackagedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123/Each", packagedData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Id does not match");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug/NDC123/Each"));
        }

        [TestMethod]
        public void PutPackagedError4Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString(), Title = "Drug Id is mandatory", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_STATUS_IS_INVALID, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString()) };

            string packagedData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123/Each\",\n  \"identifiers\": [\n    {\n      \"type\": \"BARCODE\",\n      \"identifier\": \"123456789\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"packageId\": \"Each\",\n  \"name\": \"Each\",\n  \"packageContainer\": \"string\",\n  \"packageQty\": 1,\n  \"created\": \"2021-12-03T04:07:04.414Z\",\n  \"lastModified\": \"2021-12-03T04:07:04.414Z\",\n  \"manufacturedDrugId\": \"drug/NDC123\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(It.IsAny<PackagedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123/Each", packagedData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_STATUS_IS_INVALID);
        }

        [TestMethod]
        public void PutPackagedError5Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_PACKAGED_DRUG_ID_IS_INVALID.ToString(), Title = "Drug Id is mandatory", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_PACKAGED_DRUG_ID_IS_INVALID, ProblemErrorCode.DRUG_PACKAGED_DRUG_ID_IS_INVALID.ToString()) };

            string packagedData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123/Each\",\n  \"identifiers\": [\n    {\n      \"type\": \"BARCODE\",\n      \"identifier\": \"123456789\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"packageId\": \"Each\",\n  \"name\": \"Each\",\n  \"packageContainer\": \"string\",\n  \"packageQty\": 1,\n  \"created\": \"2021-12-03T04:07:04.414Z\",\n  \"lastModified\": \"2021-12-03T04:07:04.414Z\",\n  \"manufacturedDrugId\": \"drug/NDC123\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(It.IsAny<PackagedDrugModelV2>(), It.IsAny<string>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123/Pack", packagedData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_PACKAGED_DRUG_ID_IS_INVALID.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_PACKAGED_DRUG_ID_IS_INVALID);
        }

        [TestMethod]
        public void PutMultipleUserConflictTest()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            string packagedData = "{\n  \"origin\": \"UI\",\n  \"drugId\": \"drug/NDC123/Each\",\n  \"identifiers\": [\n    {\n      \"type\": \"BARCODE\",\n      \"identifier\": \"123456789\",\n      \"status\": \"APPROVED\",\n      \"lastModifiedBy\": \"systemadmin\"\n    }\n  ],\n  \"packageId\": \"Each\",\n  \"name\": \"Each\",\n  \"packageContainer\": \"string\",\n  \"packageQty\": 1,\n  \"created\": \"2021-12-03T04:07:04.414Z\",\n  \"lastModified\": \"2021-12-03T04:07:04.414Z\",\n  \"manufacturedDrugId\": \"drug/NDC123\",\n  \"version\": 0\n}";
            mockDrugValidator?.Setup(x => x.ValidatePackagedDrugRequestAsync(It.IsAny<PackagedDrugModelV2>(), It.IsAny<string>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleMultipleUserConflict!);
            //Act
            ActionResult? result = drugController?.Put("drug/NDC123/Each", packagedData).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "This record is being updated by another user");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_MULTIPLE_USER_UPDATE.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug/NDC123/Each"));
        }

        [TestMethod]
        public void PostManufacturerPackagesTest()
        {
            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>(), It.IsAny<List<DrugSaveCommand>>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);

            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((OkResult)result).StatusCode, 200);
        }

        [TestMethod]
        public void PostManufacturerPackagesError1Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString(), Title = "Drug does not exist", Status = 404 } };

            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(error);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(validationResult!);

            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug does not exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());
            Assert.AreEqual(problem.Status, 404);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId/123456789"));
        }

        [TestMethod]
        public void PostManufacturerPackagesError2Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString(), Title = "Drug Identifier already exist", Status = 409 } };

            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(error);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(validationResult!);

            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Identifier already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId/123456789"));
        }

        [TestMethod]
        public void PostManufacturerPackagesError3Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString(), Title = "Drug Id does not match", Status = 409 } };

            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(error);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(validationResult!);

            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Id does not match");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId/123456789"));
        }

        [TestMethod]
        public void PostManufacturerPackagesError4Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString(), Title = "Drug Id does not match", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_STATUS_IS_INVALID, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString()) };

            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(error);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(validationResult!);

            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_STATUS_IS_INVALID);
        }

        [TestMethod]
        public void PostManufacturerPackagesError5Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString(), Title = "Drug does not exist", Status = 404 } };

            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(error);

            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug does not exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString());
            Assert.AreEqual(problem.Status, 404);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId/123456789"));
        }

        [TestMethod]
        public void PostManufacturerPackagesError6Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString(), Title = "Drug Identifier already exist", Status = 409 } };

            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Identifier already exist");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_CODE_ALREADY_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId/123456789"));
        }

        [TestMethod]
        public void PostManufacturerPackagesError7Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString(), Title = "Drug Id does not match", Status = 409 } };

            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Id does not match");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_ID_DOES_NOT_MATCH.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId/123456789"));
        }

        [TestMethod]
        public void PostManufacturerPackagesError8Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString(), Title = "Drug Id does not match", Status = 400 }, ErrorDetail = new ErrorDetail((int)ProblemErrorCode.DRUG_STATUS_IS_INVALID, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString()) };

            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, ProblemErrorCode.DRUG_STATUS_IS_INVALID.ToString());
            Assert.AreEqual(problem.ErrorCode, (int)ProblemErrorCode.DRUG_STATUS_IS_INVALID);
        }

        [TestMethod]
        public void PostManufacturerPackagesError9Test()
        {
            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId1", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Formulary drug Id is invalid");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_FORMULARY_DRUG_ID_IS_INVALID.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId1/123456789"));
        }

        [TestMethod]
        public void PostManufacturerPackagesError10Test()
        {
            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "1234567890", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Manufacturer drug Id is invalid");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_MANUFACTURER_DRUG_ID_IS_INVALID.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId/1234567890"));
        }

        [TestMethod]
        public void PostManufacturerPackagesError11Test()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_INPUT_DATA_DUPLICATE_IDENTIFIER.ToString(), Title = "Input data has duplicate identifier", Status = 409 } };
            List<PackagedDrugQryModelV2> packagedDrugQryModelV2s = manufacturedDrugQryModelV2!.PackagedDrugs;
            PackagedDrugQryModelV2 packagedDrugQryModelV2 = new()
            {
                DrugId = "formularyId/123456789/Pack",
                ManufacturedDrugId = "formularyId/123456789",
                Name = "Pack",
                PackageId = "Pack",
                PackageQty = 1,
                Identifiers = new List<IdentifierV2>() {
                            new IdentifierV2 {
                                Type = "BARCODE",
                                Identifier = "987654321",
                                Status = IdentifierStatus.APPROVED
                            }
                        },
                Version = 0,
                Origin = "UI",
                PackageContainer = "",
                Status = DrugStatus.Active,
                Created = DateTime.Now,
                LastModified = DateTime.Now,
            };
            packagedDrugQryModelV2s.Add(packagedDrugQryModelV2);
            manufacturedDrugQryModelV2!.PackagedDrugs = packagedDrugQryModelV2s;
            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(error);
            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Input data has duplicate identifier");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_INPUT_DATA_DUPLICATE_IDENTIFIER.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId/123456789"));
        }

        [TestMethod]
        public void PostManufacturerPackagesMultipleUserConflictTest()
        {
            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>(), It.IsAny<List<DrugSaveCommand>>()).Result).Returns(tupleMultipleUserConflict!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);

            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "This record is being updated by another user");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_MULTIPLE_USER_UPDATE.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/formularyId/123456789"));
        }

        [TestMethod]
        public void PostManufacturerPackagesError12Test()
        {
            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>(), It.IsAny<List<DrugSaveCommand>>()).Result).Returns(tupleInternalServerError!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);

            //Act
            ActionResult? result = drugController?.PostManufacturerPackages("formularyId", "123456789", manufacturedDrugQryModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((ObjectResult)result).StatusCode, 500);
        }

        [TestMethod]
        public void UpdateBarcodeStatusTest()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "987654321",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((OkResult)result).StatusCode, 200);
        }

        [TestMethod]
        public void UpdateBarcodeStatusConflict1Test()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "987654321",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Id is invalid");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_ID_IS_INVALID.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/barcodestatus"));
        }

        [TestMethod]
        public void UpdateBarcodeStatusConflict2Test()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(manufacturedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "987654321",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Invalid packaged drug");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_INVALID_PACKAGED_DRUG.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/barcodestatus"));
        }

        [TestMethod]
        public void UpdateBarcodeStatusConflict3Test()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "NDC",
                Identifier = "987654321",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Invalid identifier type");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_IDENTIFIER_TYPE_SHOULD_BE_BARCODE.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/barcodestatus"));
        }

        [TestMethod]
        public void UpdateBarcodeStatusConflict4Test()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "987654321",
                Status = IdentifierStatus.PENDING,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Invalid identifier status");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_IDENIFIER_STATUS_IS_INVALID.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/barcodestatus"));
        }

        [TestMethod]
        public void UpdateBarcodeStatusConflict5Test()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "987654321",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "",
                Version = 0
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "UserId is empty");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_USERID_IS_EMPTY.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/barcodestatus"));
        }

        [TestMethod]
        public void UpdateBarcodeStatusConflict6Test()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Empty identifier value");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_IDENTIFIER_VALUE_IS_EMPTY.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/barcodestatus"));
        }

        [TestMethod]
        public void UpdateBarcodeStatusConflict7Test()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "987654321",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 1
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "This record is being updated by another user");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_MULTIPLE_USER_UPDATE.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/barcodestatus"));
        }

        [TestMethod]
        public void UpdateBarcodeStatusConflict8Test()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "9876543211",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Barcode not found");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_BARCODE_DOES_NOT_EXIST.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/barcodestatus"));
        }

        [TestMethod]
        public void UpdateBarcodeStatusMultipleUserConflictTest()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "987654321",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            Tuple<bool, object> tupleError = new(false, "Row was updated or deleted by another transaction (or unsaved-value mapping was incorrect)");
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleError);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "This record is being updated by another user");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_MULTIPLE_USER_UPDATE.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/barcodestatus"));
        }

        [TestMethod]
        public void UpdateBarcodeStatusInternalServerErrorTest()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "987654321",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tupleInternalServerError!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((ObjectResult)result).StatusCode, 500);
        }

        [TestMethod]
        public void UpdateBarcodeStatusInternalServerError2Test()
        {
            drugCacheDataEntity = new DrugCacheDataEntity(packagedDrugModelV2)
            {
                Origin = "UI"
            };
            barcodeIdentifierModelV2 = new BarcodeIdentifierModelV2
            {
                DrugId = "formularyId/123456789/Each",
                Type = "BARCODE",
                Identifier = "987654321",
                Status = IdentifierStatus.APPROVED,
                LastModifiedBy = "systemadmin",
                Version = 0
            };
            mockDrugValidator?.Setup(x => x.GetExistingDrugAsync(It.IsAny<string>()).Result).Returns(drugCacheDataEntity!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleInternalServerError!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult? result = drugController?.UpdateBarcodeStatus(barcodeIdentifierModelV2!).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((ObjectResult)result).StatusCode, 500);
        }

        [TestMethod]
        public void DeleteTest()
        {
            mockDrugValidator?.Setup(x => x.ValidateDeleteDrugRequestAsync(It.IsAny<string>()).Result).Returns(validationResult!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugDeleteCommand>()).Result).Returns(tuplePackaged!);

            //Act
            ActionResult? result = drugController?.Delete("drug").Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((OkResult)result).StatusCode, 200);
        }

        [TestMethod]
        public void DeleteConflictTest()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_DOES_NOT_EXIST.ToString(), Title = "Drug does not exist", Status = 404 } };

            mockDrugValidator?.Setup(x => x.ValidateDeleteDrugRequestAsync(It.IsAny<string>()).Result).Returns(error);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugDeleteCommand>()).Result).Returns(tuplePackaged!);

            //Act
            ActionResult? result = drugController?.Delete("drug1").Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "Drug Not Found");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_NO_RECORD_FOUND.ToString());
            Assert.AreEqual(problem.Status, 404);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/drug1"));
        }

        [TestMethod]
        public void DeleteBadRequestTest()
        {
            ValidationResult error = new() { IsError = true, Error = new ProblemDetail { Type = ProblemErrorCode.DRUG_ID_IS_INVALID.ToString(), Title = "", Status = 400 }, ErrorDetail = new ErrorDetail(400, "Invalid drug") };

            mockDrugValidator?.Setup(x => x.ValidateDeleteDrugRequestAsync(It.IsAny<string>()).Result).Returns(error);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugDeleteCommand>()).Result).Returns(tuplePackaged!);

            //Act
            ActionResult? result = drugController?.Delete("drug1").Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, "Invalid drug");
            Assert.AreEqual(problem.ErrorCode, 400);
        }

        [TestMethod]
        public void DeleteInternalServerErrorTest()
        {
            mockDrugValidator?.Setup(x => x.ValidateDeleteDrugRequestAsync(It.IsAny<string>()).Result).Returns(validationResult!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugDeleteCommand>()).Result).Returns(tupleInternalServerError!);

            //Act
            ActionResult? result = drugController?.Delete("drug1").Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((ObjectResult)result).StatusCode, 500);
        }

        [TestMethod]
        public void PreferredAccountSettingsTest()
        {
            HospitalChangedModelV2 hospitalChangedModelV2 = new() { SupplierId = "supplierId", AccountId = "accountId" };
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tuplePackaged!);

            //Act
            ActionResult? result = drugController?.PreferredAccountSettings(hospitalChangedModelV2).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((OkResult)result).StatusCode, 200);
        }

        [TestMethod]
        public void PreferredAccountSettingsConflictTest()
        {
            HospitalChangedModelV2 hospitalChangedModelV2 = new() { SupplierId = "supplierId", AccountId = "accountId" };
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleMultipleUserConflict!);

            //Act
            ActionResult? result = drugController?.PreferredAccountSettings(hospitalChangedModelV2).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "This record is being updated by another user");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_MULTIPLE_USER_UPDATE.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/preferredAccount"));
        }

        [TestMethod]
        public void PreferredAccountSettingsISETest()
        {
            HospitalChangedModelV2 hospitalChangedModelV2 = new() { SupplierId = "supplierId", AccountId = "accountId" };
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleInternalServerError!);

            //Act
            ActionResult? result = drugController?.PreferredAccountSettings(hospitalChangedModelV2).Result;
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((ObjectResult)result).StatusCode, 500);
        }

        [TestMethod]
        public void PreferredAccountSettingsBRTest()
        {
            HospitalChangedModelV2 hospitalChangedModelV2 = new() { SupplierId = "", AccountId = "accountId" };
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleInternalServerError!);

            //Act
            ActionResult? result = drugController?.PreferredAccountSettings(hospitalChangedModelV2).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, "AccountId & SupplierId both required");
            Assert.AreEqual(problem.ErrorCode, 3013);
        }

        [TestMethod]
        public void PreferredAccountSettingsBR2Test()
        {
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleInternalServerError!);

            //Act
            ActionResult? result = drugController?.PreferredAccountSettings(null!).Result;
            //Assert
            Assert.IsNotNull(result);
            ObjectResult output = (ObjectResult)result;
            ErrorDetail? problem = (ErrorDetail)output.Value;
            Assert.AreEqual(problem.ErrorMessage, "Request body is empty.");
            Assert.AreEqual(problem.ErrorCode, 3012);
        }

        //https://stackoverflow.com/questions/53618704/create-moq-for-epplus-excel-file
        //https://stackoverflow.com/questions/36858542/how-to-mock-an-iformfile-for-a-unit-integration-test-in-asp-net-core
        [TestMethod]
        public async Task PostFileTest()
        {
            FileStream content = File.OpenRead(Path.Combine("data", "TestDrugData.xlsx"));
            IFormFile file = new FormFile(content, 0, content.Length, "ExcelUpload-1", content.Name);
            mockDrugValidator?.Setup(x => x.ValidateFormularyDrugRequestAsync(It.IsAny<FormularyDrugModelV2>(), null).Result).Returns(validationResult!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleFormulary!);
            mockDrugValidator?.Setup(x => x.ValidatePutMfgDrugRequestAsync(It.IsAny<ManufacturedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugValidator?.Setup(x => x.ValidatePutPackagedDrugRequestAsync(It.IsAny<string>(), It.IsAny<PackagedDrugModelV2>()).Result).Returns(validationResult!);
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>(), It.IsAny<List<DrugSaveCommand>>()).Result).Returns(tuplePackaged!);
            mockDrugCommand?.Setup(x => x.HandleKafkaAsync(It.IsAny<BarcodeIdentifierModelV2>(), It.IsAny<RequestContext>()).Result).Returns(tuplePackaged!);
            //Act
            ActionResult<ImportResponseModelV2> result = await drugController.PostFile(file).ConfigureAwait(true);

            //Assert
            Assert.IsNotNull(result.Result);
            CreatedAtActionResult? output = result.Result as CreatedAtActionResult;
            ImportResponseModelV2? importResponse = (ImportResponseModelV2)output.Value;
            Assert.IsNotNull(importResponse);
            Assert.AreEqual(importResponse.Type, "Drug");
            Assert.AreEqual(importResponse.DataSuccess.Count, 2);
            Assert.AreEqual(importResponse.DataSuccess["SimpleGenericProduct"].Count, 2);
            Assert.AreEqual(importResponse.DataError.Count, 2);
            Assert.AreEqual(importResponse.DataError["SimpleGenericProduct"].Dependency.Count, 0);
            Assert.AreEqual(importResponse.DataError["SimpleGenericProduct"].DuplicateRows.Count, 0);
            Assert.AreEqual(importResponse.DataError["SimpleGenericProduct"].RequiredFieldRows.Count, 0);

            Assert.AreEqual(importResponse.DataError["SimpleManufacturerProduct"].Dependency.Count, 0);
            Assert.AreEqual(importResponse.DataError["SimpleManufacturerProduct"].DuplicateRows.Count, 0);
            Assert.AreEqual(importResponse.DataError["SimpleManufacturerProduct"].RequiredFieldRows.Count, 0);
        }

        [TestMethod]
        public async Task PostFileEmptySheetTest()
        {
            FileStream content = File.OpenRead(Path.Combine("data", "TestDrugDataEmpty.xlsx"));
            IFormFile file = new FormFile(content, 0, content.Length, "ExcelUpload-2", content.Name);

            //Act
            ActionResult<ImportResponseModelV2> result = await drugController.PostFile(file).ConfigureAwait(true);

            //Assert
            Assert.IsNotNull(result.Result);
            CreatedAtActionResult? output = result.Result as CreatedAtActionResult;
            ImportResponseModelV2? importResponse = (ImportResponseModelV2)output.Value;
            Assert.IsNotNull(importResponse);
            Assert.AreEqual(importResponse.Type, "Drug");
            Assert.AreEqual(importResponse.DataSuccess.Count, 2);
            Assert.AreEqual(importResponse.DataSuccess["SimpleGenericProduct"].Count, 0);
            Assert.AreEqual(importResponse.DataError.Count, 2);
            Assert.IsNull(importResponse.DataError["SimpleGenericProduct"].Dependency);
            Assert.IsNull(importResponse.DataError["SimpleGenericProduct"].DuplicateRows);
            Assert.IsNull(importResponse.DataError["SimpleGenericProduct"].RequiredFieldRows);
            Assert.IsNotNull(importResponse.FileError);
            Assert.AreEqual(importResponse.FileError.Corrupt, "Spreadsheet is corrupt or empty");
            Assert.IsNull(importResponse.FileError.Template);
            Assert.IsNull(importResponse.FileError.Extension);
            Assert.IsNull(importResponse.FileError.Unhandled);
            //Spreadsheet is corrupt or empty
        }

        [TestMethod]
        public async Task PostFileExtensionFailedTest()
        {
            FileStream content = File.OpenRead(Path.Combine("data", "data.txt"));
            IFormFile file = new FormFile(content, 0, content.Length, "ExcelUpload-3", content.Name);

            //Act
            ActionResult<ImportResponseModelV2> result = await drugController.PostFile(file).ConfigureAwait(true);

            //Assert
            Assert.IsNotNull(result.Result);
            CreatedAtActionResult? output = result.Result as CreatedAtActionResult;
            ImportResponseModelV2? importResponse = (ImportResponseModelV2)output.Value;
            Assert.IsNotNull(importResponse);
            Assert.IsNull(importResponse.Type);
            Assert.IsNull(importResponse.DataSuccess);
            Assert.IsNull(importResponse.DataError);
            Assert.IsNotNull(importResponse.FileError);
            Assert.IsNull(importResponse.FileError.Corrupt);
            Assert.IsNull(importResponse.FileError.Template);
            Assert.AreEqual(importResponse.FileError.Extension, "Spreadsheet extension is invalid");
            Assert.IsNull(importResponse.FileError.Unhandled);
            //Spreadsheet is corrupt or empty
        }

        [TestMethod]
        public async Task PostDrugEnumFileTest()
        {
            FileStream content = File.OpenRead(Path.Combine("data", "Level_0.xlsx"));
            IFormFile file = new FormFile(content, 0, content.Length, "ExcelUpload", content.Name);

            //Act
            ActionResult<ImportResponseModelV2> result = await drugController.PostDrugEnumFile(file).ConfigureAwait(true);

            //Assert
            Assert.IsNotNull(result.Result);
            CreatedAtActionResult? output = result.Result as CreatedAtActionResult;
            ImportResponseModelV2? importResponse = (ImportResponseModelV2)output.Value;
            Assert.IsNotNull(importResponse);
            Assert.AreEqual(importResponse.Type, "DrugEnum");
            Assert.AreEqual(importResponse.DataSuccess.Count, 1);
            Assert.AreEqual(importResponse.DataSuccess["ConfigValueLov"].Count, 95);
            Assert.AreEqual(importResponse.DataError.Count, 1);
            Assert.AreEqual(importResponse.DataError["ConfigValueLov"].Dependency.Count, 0);
            Assert.AreEqual(importResponse.DataError["ConfigValueLov"].DuplicateRows.Count, 0);
            Assert.AreEqual(importResponse.DataError["ConfigValueLov"].RequiredFieldRows.Count, 0);
        }

        [TestMethod]
        public async Task PostDrugEnumFileEmptySheetTest()
        {
            FileStream content = File.OpenRead(Path.Combine("data", "Level_EmptySheet.xlsx"));
            IFormFile file = new FormFile(content, 0, content.Length, "ExcelUpload", content.Name);

            //Act
            ActionResult<ImportResponseModelV2> result = await drugController.PostDrugEnumFile(file).ConfigureAwait(true);

            //Assert
            Assert.IsNotNull(result.Result);
            CreatedAtActionResult? output = result.Result as CreatedAtActionResult;
            ImportResponseModelV2? importResponse = (ImportResponseModelV2)output.Value;
            Assert.IsNotNull(importResponse);
            Assert.AreEqual(importResponse.Type, "DrugEnum");
            Assert.AreEqual(importResponse.DataSuccess.Count, 1);
            Assert.AreEqual(importResponse.DataSuccess["ConfigValueLov"].Count, 0);
            Assert.AreEqual(importResponse.DataError.Count, 1);
            Assert.IsNull(importResponse.DataError["ConfigValueLov"].Dependency);
            Assert.IsNull(importResponse.DataError["ConfigValueLov"].DuplicateRows);
            Assert.IsNull(importResponse.DataError["ConfigValueLov"].RequiredFieldRows);
            Assert.IsNotNull(importResponse.FileError);
            Assert.AreEqual(importResponse.FileError.Corrupt, "Spreadsheet is corrupt or empty");
            Assert.IsNull(importResponse.FileError.Template);
            Assert.IsNull(importResponse.FileError.Extension);
            Assert.IsNull(importResponse.FileError.Unhandled);
            //Spreadsheet is corrupt or empty
        }

        [TestMethod]
        public async Task PostDrugEnumFileExtensionFailedTest()
        {
            FileStream content = File.OpenRead(Path.Combine("data", "data.txt"));
            IFormFile file = new FormFile(content, 0, content.Length, "ExcelUpload", content.Name);

            //Act
            ActionResult<ImportResponseModelV2> result = await drugController.PostDrugEnumFile(file).ConfigureAwait(true);

            //Assert
            Assert.IsNotNull(result.Result);
            CreatedAtActionResult? output = result.Result as CreatedAtActionResult;
            ImportResponseModelV2? importResponse = (ImportResponseModelV2)output.Value;
            Assert.IsNotNull(importResponse);
            Assert.IsNull(importResponse.Type);
            Assert.IsNull(importResponse.DataSuccess);
            Assert.IsNull(importResponse.DataError);
            Assert.IsNotNull(importResponse.FileError);
            Assert.IsNull(importResponse.FileError.Corrupt);
            Assert.IsNull(importResponse.FileError.Template);
            Assert.AreEqual(importResponse.FileError.Extension, "Spreadsheet extension is invalid");
            Assert.IsNull(importResponse.FileError.Unhandled);
            //Spreadsheet is corrupt or empty
        }

        [TestMethod]
        public void MigrateStatusWithInactiveTest()
        {
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleFormulary!);
            //Act
            Task<ActionResult> result = drugController?.MigrateStatusWithInactive();
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((OkResult)result.Result).StatusCode, 200);
        }

        [TestMethod]
        public void MigrateStatusWithInactiveMultipleUserConflictTest()
        {
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleMultipleUserConflict!);
            //Act
            Task<ActionResult> result = drugController?.MigrateStatusWithInactive();
            //Assert
            Assert.IsNotNull(result);
            ObjectResult? output = result.Result as ObjectResult;
            ProblemDetail? problem = (ProblemDetail)output.Value;
            Assert.AreEqual(problem.Title, "This record is being updated by another user");
            Assert.AreEqual(problem.Type, ProblemErrorCode.DRUG_MULTIPLE_USER_UPDATE.ToString());
            Assert.AreEqual(problem.Status, 409);
            Assert.AreEqual(problem.Instance, new Uri("http://drug2:8015/api/items/drug/migrateStatus"));
        }

        [TestMethod]
        public void MigrateStatusWithInactiveInternalServerErrorTest()
        {
            mockDrugCommand?.Setup(x => x.HandleAsync(It.IsAny<DrugSaveCommand>()).Result).Returns(tupleInternalServerError!);
            //Act
            Task<ActionResult> result = drugController?.MigrateStatusWithInactive();
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((ObjectResult)result.Result).StatusCode, 500);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            drugController = null;
        }
        #endregion
    }
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning restore CS8602 // Dereference of a possibly null reference.

    public static class TestData
    {
        public const string locationContent = @"[
                                        {
                                                ""name"": ""Swisslog HCS NA"",
                                                ""identifiers"": [
                                                        {
                                                                ""type"": ""ERP_ID"",
                                                                ""identifier"": """"
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_KEY"",
                                                                ""identifier"": ""1001""
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_ID"",
                                                                ""identifier"": ""root""
                                                        }
                                                ],
                                                ""shortName"": """",
                                                ""locationId"": ""root"",
                                                ""links"": [],
                                                ""created"": ""2021-12-06T09:16:22.393Z"",
                                                ""lastModified"": ""2021-12-06T09:16:22.393Z""
                                        },
                                        {
                                                ""name"": ""TC Hospital"",
                                                ""identifiers"": [
                                                        {
                                                                ""type"": ""ERP_ID"",
                                                                ""identifier"": """"
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_KEY"",
                                                                ""identifier"": ""1002""
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_ID"",
                                                                ""identifier"": ""SWISSLOG-NA-TC""
                                                        }
                                                ],
                                                ""shortName"": """",
                                                ""locationId"": ""hospital/SWISSLOG-NA-TC"",
                                                ""parentId"": ""root"",
                                                ""links"": [],
                                                ""created"": ""2021-12-06T09:16:22.393Z"",
                                                ""lastModified"": ""2021-12-06T09:16:22.393Z""
                                        },
                                        {
                                                ""name"": ""HQ Hospital"",
                                                ""identifiers"": [
                                                        {
                                                                ""type"": ""ERP_ID"",
                                                                ""identifier"": """"
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_KEY"",
                                                                ""identifier"": ""1003""
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_ID"",
                                                                ""identifier"": ""SWISSLOG-NA-HQ""
                                                        }
                                                ],
                                                ""shortName"": """",
                                                ""locationId"": ""hospital/SWISSLOG-NA-HQ"",
                                                ""parentId"": ""root"",
                                                ""links"": [],
                                                ""created"": ""2021-12-06T09:16:22.393Z"",
                                                ""lastModified"": ""2021-12-06T09:16:22.393Z""
                                        },
                                        {
                                                ""name"": ""East Pharmacy"",
                                                ""identifiers"": [
                                                        {
                                                                ""type"": ""ERP_ID"",
                                                                ""identifier"": """"
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_KEY"",
                                                                ""identifier"": ""1006""
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_ID"",
                                                                ""identifier"": ""PHARMACY-EAST""
                                                        }
                                                ],
                                                ""shortName"": """",
                                                ""locationId"": ""facility/SWISSLOG-NA-HQ/PHARMACY-EAST"",
                                                ""parentId"": ""hospital/SWISSLOG-NA-HQ"",
                                                ""links"": [],
                                                ""created"": ""2021-12-06T09:16:22.393Z"",
                                                ""lastModified"": ""2021-12-06T09:16:22.393Z""
                                        },
                                        {
                                                ""name"": ""West Pharmacy"",
                                                ""identifiers"": [
                                                        {
                                                                ""type"": ""ERP_ID"",
                                                                ""identifier"": """"
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_KEY"",
                                                                ""identifier"": ""1007""
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_ID"",
                                                                ""identifier"": ""PHARMACY-WEST""
                                                        }
                                                ],
                                                ""shortName"": """",
                                                ""locationId"": ""facility/SWISSLOG-NA-HQ/PHARMACY-WEST"",
                                                ""parentId"": ""hospital/SWISSLOG-NA-HQ"",
                                                ""links"": [],
                                                ""created"": ""2021-12-06T09:16:22.393Z"",
                                                ""lastModified"": ""2021-12-06T09:16:22.393Z""
                                        },
                                        {
                                                ""name"": ""Remote Pharmacy"",
                                                ""identifiers"": [
                                                        {
                                                                ""type"": ""ERP_ID"",
                                                                ""identifier"": """"
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_KEY"",
                                                                ""identifier"": ""1008""
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_ID"",
                                                                ""identifier"": ""PHARMACY-REMOTE""
                                                        }
                                                ],
                                                ""shortName"": """",
                                                ""locationId"": ""facility/SWISSLOG-NA-HQ/PHARMACY-REMOTE"",
                                                ""parentId"": ""hospital/SWISSLOG-NA-HQ"",
                                                ""links"": [],
                                                ""created"": ""2021-12-06T09:16:22.393Z"",
                                                ""lastModified"": ""2021-12-06T09:16:22.393Z""
                                        },
                                        {
                                                ""name"": ""North Pharmacy"",
                                                ""identifiers"": [
                                                        {
                                                                ""type"": ""ERP_ID"",
                                                                ""identifier"": """"
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_KEY"",
                                                                ""identifier"": ""1004""
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_ID"",
                                                                ""identifier"": ""PHARMACY-NORTH""
                                                        }
                                                ],
                                                ""shortName"": """",
                                                ""locationId"": ""facility/SWISSLOG-NA-TC/PHARMACY-NORTH"",
                                                ""parentId"": ""hospital/SWISSLOG-NA-TC"",
                                                ""links"": [],
                                                ""created"": ""2021-12-06T09:16:22.393Z"",
                                                ""lastModified"": ""2021-12-06T09:16:22.393Z""
                                        },
                                        {
                                                ""name"": ""South Pharmacy"",
                                                ""identifiers"": [
                                                        {
                                                                ""type"": ""ERP_ID"",
                                                                ""identifier"": """"
                                                        },
                                                        {
                                                                ""type"": ""WM6_LOCATION_KEY"",
                                                                ""identifier"": ""1005""
                                                       },
                                                        {
                                                                ""type"": ""WM6_LOCATION_ID"",
                                                                ""identifier"": ""PHARMACY-SOUTH""
                                                        }
                                                ],
                                                ""shortName"": """",
                                                ""locationId"": ""facility/SWISSLOG-NA-TC/PHARMACY-SOUTH"",
                                                ""parentId"": ""hospital/SWISSLOG-NA-TC"",
                                                ""links"": [],
                                                ""created"": ""2021-12-06T09:16:22.393Z"",
                                                ""lastModified"": ""2021-12-06T09:16:22.393Z""
                                        }
                                ]";
        public const string drugQuantityInfo = @"[
	                                {
		                                ""itemId"": ""drug/drug1"",
		                                ""quantities"": {
			                                ""location1"": {
				                                ""quantityOnHand"": 50,
				                                ""quantityAvailable"": 50,
				                                ""children"": []
                                    }
                                }
	                                },
	                                {
                                    ""itemId"": ""drug/drug2"",
		                                ""quantities"": {
                                        ""location1"": {
                                            ""quantityOnHand"": 60,
				                                ""quantityAvailable"": 60,
				                                ""children"": []

                                            }
                                    }
                                }
                             ]";
    }
}
